import React from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import { ToastProvider } from "./components/common/Modal";

import Landing from "./pages/Landing";
import Login from "./pages/Login";
import VerifyOtp from "./pages/VerifyOtp";
import AccountSettings from "./pages/AccountSettings";

import GovDashboard from "./pages/government/Dashboard";
import GovTrainees from "./pages/government/Trainees";
import GovTraineeProfile from "./pages/government/TraineeProfile";
import GovFollowups from "./pages/government/Followups";
import GovEmployers from "./pages/government/Employers";
import GovSkillGaps from "./pages/government/SkillGaps";
import GovAnalytics from "./pages/government/Analytics";
import GovReports from "./pages/government/Reports";
import GovSettings from "./pages/government/Settings";

import ProviderDashboard from "./pages/provider/Dashboard";
import ProviderTrainees from "./pages/provider/Trainees";
import ProviderOutcomes from "./pages/provider/Outcomes";
import ProviderSkillGaps from "./pages/provider/SkillGaps";

import TraineeDashboard from "./pages/trainee/Dashboard";
import TraineeProfilePage from "./pages/trainee/Profile";
import TraineeFollowupForm from "./pages/trainee/FollowupForm";
import TraineePrivacy from "./pages/trainee/Privacy";

import EmployerDashboard from "./pages/employer/Dashboard";
import EmployerVerifications from "./pages/employer/Verifications";
import EmployerHistory from "./pages/employer/History";

export default function App() {
  return (
    <ToastProvider>
      <Routes>
        <Route path="/" element={<Landing />} />
        <Route path="/login" element={<Login />} />
        <Route path="/verify-otp" element={<VerifyOtp />} />

        {/* Shared account settings — one component, works for every role */}
        <Route path="/government/account-settings" element={<AccountSettings />} />
        <Route path="/provider/account-settings" element={<AccountSettings />} />
        <Route path="/trainee/account-settings" element={<AccountSettings />} />
        <Route path="/employer/account-settings" element={<AccountSettings />} />

        {/* Government */}
        <Route path="/government/dashboard" element={<GovDashboard />} />
        <Route path="/government/trainees" element={<GovTrainees />} />
        <Route path="/government/trainees/:id" element={<GovTraineeProfile />} />
        <Route path="/government/followups" element={<GovFollowups />} />
        <Route path="/government/employers" element={<GovEmployers />} />
        <Route path="/government/skill-gaps" element={<GovSkillGaps />} />
        <Route path="/government/analytics" element={<GovAnalytics />} />
        <Route path="/government/reports" element={<GovReports />} />
        <Route path="/government/settings" element={<GovSettings />} />

        {/* Training Provider */}
        <Route path="/provider/dashboard" element={<ProviderDashboard />} />
        <Route path="/provider/trainees" element={<ProviderTrainees />} />
        <Route path="/provider/outcomes" element={<ProviderOutcomes />} />
        <Route path="/provider/skill-gaps" element={<ProviderSkillGaps />} />

        {/* Trainee */}
        <Route path="/trainee/dashboard" element={<TraineeDashboard />} />
        <Route path="/trainee/profile" element={<TraineeProfilePage />} />
        <Route path="/trainee/followup" element={<TraineeFollowupForm />} />
        <Route path="/trainee/privacy" element={<TraineePrivacy />} />

        {/* Employer */}
        <Route path="/employer/dashboard" element={<EmployerDashboard />} />
        <Route path="/employer/verifications" element={<EmployerVerifications />} />
        <Route path="/employer/history" element={<EmployerHistory />} />

        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </ToastProvider>
  );
}
