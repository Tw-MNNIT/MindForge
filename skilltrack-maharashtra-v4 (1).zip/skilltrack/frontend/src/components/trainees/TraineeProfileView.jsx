import React, { useEffect, useState } from "react";
import { MapPin, GraduationCap, Briefcase, TrendingUp, FileText, ExternalLink } from "lucide-react";
import StatusBadge from "../common/StatusBadge";
import { SimpleLineChart } from "../charts/Charts";
import api from "../../api/client";

function fmtDate(d) {
  if (!d) return "—";
  return new Date(d).toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" });
}
function fmtMoney(n) {
  if (!n && n !== 0) return "—";
  return `₹${Number(n).toLocaleString("en-IN")}`;
}

/**
 * sections controls which blocks render, so the trainee Profile page (the
 * "upper" half — header + training/outcome info) and trainee Dashboard
 * page (the "lower" half — wage graph + follow-up checkpoints) can each
 * show only their part, while government/provider views can show it all.
 * The old "Longitudinal Outcome Timeline" list has been removed entirely.
 */
export default function TraineeProfileView({
  traineeId,
  sections = ["header", "training", "outcome", "wage", "followups"],
  traineeView = false,
}) {
  const [data, setData] = useState(null);
  const [reports, setReports] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      setLoading(true);
      const { data } = await api.get(`/trainees/${traineeId}`);
      setData(data);
      if (traineeView || sections.includes("training")) {
        try {
          const { data: r } = await api.get(`/reports-ai/trainee/${traineeId}`);
          setReports(r);
        } catch {
          setReports([]);
        }
      }
      setLoading(false);
    }
    if (traineeId) load();
  }, [traineeId]);

  if (loading || !data) return <div className="text-sm text-slate-500">Loading…</div>;

  const { trainee, outcomes, followUps, consent } = data;
  const currentOutcome = outcomes.find((o) => o.isCurrent);
  const employedOutcomes = outcomes.filter((o) => o.outcomeType === "employed");

  const salaryChartData = [];
  employedOutcomes.forEach((o) => {
    (o.salaryHistory || []).forEach((s) => {
      salaryChartData.push({ date: fmtDate(s.recordedAt), salary: s.monthlySalary });
    });
  });
  const firstSalary = salaryChartData[0]?.salary;
  const lastSalary = salaryChartData[salaryChartData.length - 1]?.salary;
  const salaryGrowthPct =
    firstSalary && lastSalary ? Math.round(((lastSalary - firstSalary) / firstSalary) * 1000) / 10 : null;

  const latestTraining = trainee.trainingHistory?.[trainee.trainingHistory.length - 1];
  const latestReport = reports[0];
  const show = (s) => sections.includes(s);

  return (
    <div className="space-y-5">
      {show("header") && (
        <div className="card p-5 flex flex-col md:flex-row md:items-center gap-4">
          <div className="w-16 h-16 rounded-full bg-brand-500/15 text-brand-200 flex items-center justify-center text-xl font-semibold shrink-0">
            {trainee.name?.[0]}
          </div>
          <div className="flex-1">
            <div className="flex flex-wrap items-center gap-2">
              <h2 className="text-lg font-semibold text-white">{trainee.name}</h2>
              <StatusBadge status={trainee.currentOutcomeStatus} />
            </div>
            <div className="flex flex-wrap items-center gap-4 text-sm text-slate-500 mt-1">
              <span>{trainee.traineeCode}</span>
              <span className="flex items-center gap-1"><MapPin size={14} /> {trainee.districtId?.name}</span>
              <span>{trainee.age} yrs, {trainee.gender}</span>
            </div>
          </div>
          <div className="flex flex-col items-start md:items-end gap-1">
            <StatusBadge status={consent?.status} prefix="Consent" />
            {currentOutcome?.outcomeType === "employed" && <StatusBadge status={currentOutcome.verification?.status} />}
          </div>
        </div>
      )}

      {(show("training") || show("outcome")) && (
        <div className="grid md:grid-cols-2 gap-5">
          {show("training") && (
            <div className="card p-5">
              <h3 className="font-semibold text-white mb-3 flex items-center gap-2"><GraduationCap size={16} /> Training</h3>
              {latestTraining ? (
                <dl className="text-sm space-y-2">
                  <Row label="Course" value={latestTraining.programId?.name} />
                  <Row label="Provider" value={latestTraining.providerId?.name} />
                  <Row label="Start Date" value={fmtDate(latestTraining.startDate)} />
                  <Row label="Completion Date" value={fmtDate(latestTraining.completionDate)} />
                  {!traineeView && <Row label="Attendance" value={`${latestTraining.attendancePct ?? "—"}%`} />}
                  {!traineeView && <Row label="Assessment Score" value={`${latestTraining.assessmentScore ?? "—"}%`} />}
                  <Row label="Certified" value={latestTraining.certified ? "Yes" : "No"} />
                  {traineeView && (
                    <div className="pt-2">
                      <dt className="text-slate-500 mb-1.5">Provider Report</dt>
                      {latestReport ? (
                        latestReport.fileUrl ? (
                          <a href={latestReport.fileUrl} target="_blank" rel="noreferrer"
                            className="inline-flex items-center gap-1.5 text-brand-300 hover:text-brand-200 text-sm font-medium">
                            <ExternalLink size={14} /> View Report
                          </a>
                        ) : (
                          <ReportPreviewLink report={latestReport} />
                        )
                      ) : (
                        <span className="text-slate-500 text-sm">Not published yet</span>
                      )}
                    </div>
                  )}
                </dl>
              ) : (
                <p className="text-sm text-slate-500">No training record.</p>
              )}
            </div>
          )}

          {show("outcome") && (
            <div className="card p-5">
              <h3 className="font-semibold text-white mb-3 flex items-center gap-2"><Briefcase size={16} /> Current Outcome</h3>
              {currentOutcome ? (
                <dl className="text-sm space-y-2">
                  <Row label="Status" value={<StatusBadge status={trainee.currentOutcomeStatus} />} />
                  {currentOutcome.outcomeType === "employed" && (
                    <>
                      <Row label="Employer" value={currentOutcome.employerId?.name} />
                      <Row label="Role" value={currentOutcome.jobTitle} />
                      <Row label="Employment Type" value={currentOutcome.employmentType} />
                      <Row label="Work Location" value={currentOutcome.workLocation} />
                      <Row label="Current Salary" value={fmtMoney(currentOutcome.salaryHistory?.[currentOutcome.salaryHistory.length - 1]?.monthlySalary)} />
                      <Row label="Verification" value={<StatusBadge status={currentOutcome.verification?.status} />} />
                      <Row label="Confidence" value={<StatusBadge status={currentOutcome.confidence} />} />
                    </>
                  )}
                  {currentOutcome.outcomeType === "self_employed" && (
                    <>
                      <Row label="Business Type" value={currentOutcome.selfEmployment?.businessType} />
                      <Row label="Monthly Income" value={fmtMoney(currentOutcome.selfEmployment?.monthlyIncome)} />
                      <Row label="Duration" value={`${currentOutcome.selfEmployment?.businessDurationMonths ?? "—"} months`} />
                    </>
                  )}
                  {currentOutcome.outcomeType === "apprenticeship" && (
                    <>
                      <Row label="Organization" value={currentOutcome.apprenticeship?.organization} />
                      <Row label="Stipend" value={fmtMoney(currentOutcome.apprenticeship?.stipend)} />
                      <Row label="Duration" value={`${currentOutcome.apprenticeship?.durationMonths ?? "—"} months`} />
                    </>
                  )}
                  {currentOutcome.outcomeType === "unemployed" && (
                    <>
                      <Row label="Reason" value={currentOutcome.unemployment?.reason} />
                      <Row label="Looking for Employment" value={currentOutcome.unemployment?.lookingForEmployment ? "Yes" : "No"} />
                    </>
                  )}
                </dl>
              ) : (
                <p className="text-sm text-slate-500">No outcome reported yet — awaiting first follow-up.</p>
              )}
            </div>
          )}
        </div>
      )}

      {show("wage") && salaryChartData.length > 1 && (
        <div className="card p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-white flex items-center gap-2"><TrendingUp size={16} /> Wage Progression</h3>
            {salaryGrowthPct !== null && (
              <span className={`text-sm font-semibold ${salaryGrowthPct >= 0 ? "text-emerald-400" : "text-red-400"}`}>
                Salary Growth: {salaryGrowthPct >= 0 ? "+" : ""}{salaryGrowthPct}%
              </span>
            )}
          </div>
          <SimpleLineChart data={salaryChartData} xKey="date" lines={[{ key: "salary", label: "Monthly Salary (₹)", color: "#34d399" }]} height={220} />
        </div>
      )}

      {show("followups") && (
        <div className="card p-5">
          <h3 className="font-semibold text-white mb-3">Follow-up Checkpoints</h3>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
            {followUps.map((f) => (
              <div key={f._id} className="border border-white/10 rounded-lg p-3 text-center">
                <p className="text-xs text-slate-500 mb-1">{f.checkpoint.replace("_", " ")}</p>
                <StatusBadge status={f.status} />
              </div>
            ))}
            {followUps.length === 0 && <p className="text-sm text-slate-500 col-span-full">No follow-ups scheduled yet.</p>}
          </div>
        </div>
      )}
    </div>
  );
}

function ReportPreviewLink({ report }) {
  const [open, setOpen] = useState(false);
  return (
    <div>
      <button onClick={() => setOpen((o) => !o)} className="inline-flex items-center gap-1.5 text-brand-300 hover:text-brand-200 text-sm font-medium">
        <FileText size={14} /> View Report
      </button>
      {open && (
        <div className="mt-2 text-xs text-slate-400 whitespace-pre-wrap bg-white/5 border border-white/10 rounded-lg p-3 max-h-64 overflow-y-auto">
          {report.aiContent}
        </div>
      )}
    </div>
  );
}

function Row({ label, value }) {
  return (
    <div className="flex items-center justify-between">
      <dt className="text-slate-500">{label}</dt>
      <dd className="font-medium text-slate-200">{value ?? "—"}</dd>
    </div>
  );
}
