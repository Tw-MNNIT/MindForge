import React from "react";

const STYLES = {
  // verification
  verified: "bg-emerald-100 text-emerald-700",
  pending: "bg-amber-100 text-amber-700",
  failed: "bg-red-100 text-red-700",
  not_applicable: "bg-gray-100 text-gray-600",

  // follow-up
  Completed: "bg-emerald-100 text-emerald-700",
  Pending: "bg-amber-100 text-amber-700",
  Overdue: "bg-red-100 text-red-700",
  "Not Reachable": "bg-gray-200 text-gray-700",

  // outcome / consent
  Employed: "bg-emerald-100 text-emerald-700",
  "Self-Employed": "bg-blue-100 text-blue-700",
  Apprenticeship: "bg-indigo-100 text-indigo-700",
  Unemployed: "bg-red-100 text-red-700",
  "Further Education": "bg-purple-100 text-purple-700",
  Given: "bg-emerald-100 text-emerald-700",
  Revoked: "bg-red-100 text-red-700",

  // confidence
  high: "bg-emerald-100 text-emerald-700",
  medium: "bg-amber-100 text-amber-700",
  low: "bg-red-100 text-red-700",
};

const LABELS = {
  verified: "Verified",
  pending: "Pending",
  failed: "Failed",
  not_applicable: "N/A",
  high: "High Confidence",
  medium: "Medium Confidence",
  low: "Low Confidence",
};

export default function StatusBadge({ status, prefix }) {
  const cls = STYLES[status] || "bg-gray-100 text-gray-600";
  const label = LABELS[status] || status;
  return <span className={`badge ${cls}`}>{prefix ? `${prefix}: ` : ""}{label}</span>;
}
