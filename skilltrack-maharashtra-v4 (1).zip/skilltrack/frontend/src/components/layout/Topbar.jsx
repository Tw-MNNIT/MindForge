import React, { useState } from "react";
import { Menu, LogOut, ShieldCheck } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";
import { Modal } from "../common/Modal";

const ROLE_LABELS = {
  government: "Government Administrator",
  provider: "Training Provider",
  trainee: "Trainee",
  employer: "Employer",
};

export default function Topbar({ onToggleSidebar }) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [confirmOpen, setConfirmOpen] = useState(false);

  function doLogout() {
    logout();
    navigate("/login");
  }

  return (
    <header className="h-16 border-b border-white/10 flex items-center gap-4 px-4 shrink-0" style={{ background: "rgba(255,255,255,0.02)" }}>
      <button onClick={onToggleSidebar} className="text-slate-500 hover:text-slate-200">
        <Menu size={20} />
      </button>
      <div className="flex items-center gap-2 text-sm text-slate-500">
        <ShieldCheck size={16} className="text-brand-300" />
        <span className="hidden sm:inline">Demo Data — Fictional Prototype Dataset</span>
      </div>
      <div className="ml-auto flex items-center gap-3">
        <div className="text-right hidden sm:block">
          <div className="text-sm font-medium text-white">{user?.name}</div>
          <div className="text-xs text-slate-500">{ROLE_LABELS[user?.role]}</div>
        </div>
        <div className="w-9 h-9 rounded-full bg-brand-500/20 text-brand-200 flex items-center justify-center font-semibold text-sm">
          {user?.name?.[0] || "?"}
        </div>
        <button onClick={() => setConfirmOpen(true)} className="text-slate-500 hover:text-red-400" title="Log out">
          <LogOut size={18} />
        </button>
      </div>

      <Modal
        open={confirmOpen}
        onClose={() => setConfirmOpen(false)}
        title="Log out?"
        footer={
          <>
            <button onClick={() => setConfirmOpen(false)} className="px-4 py-2 text-sm rounded-lg text-slate-400 hover:text-slate-200">Cancel</button>
            <button onClick={doLogout} className="px-4 py-2 text-sm rounded-lg bg-red-600 hover:bg-red-500 text-white font-medium">Log Out</button>
          </>
        }
      >
        <p className="text-sm text-slate-400">Are you sure you want to log out of your SkillTrack account?</p>
      </Modal>
    </header>
  );
}
