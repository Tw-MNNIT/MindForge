import React from "react";
import { NavLink } from "react-router-dom";
import {
  LayoutDashboard, Users, Briefcase, ClipboardList, Building2,
  TrendingDown, BarChart3, FileText, Settings, UserCircle, History, Shield, ListChecks, SlidersHorizontal,
} from "lucide-react";

const NAV = {
  government: [
    { to: "/government/dashboard", label: "Dashboard", icon: LayoutDashboard },
    { to: "/government/trainees", label: "Trainees", icon: Users },
    { to: "/government/followups", label: "Follow-ups", icon: ClipboardList },
    { to: "/government/employers", label: "Employers", icon: Building2 },
    { to: "/government/skill-gaps", label: "Skill Gaps", icon: TrendingDown },
    { to: "/government/analytics", label: "Analytics", icon: BarChart3 },
    { to: "/government/reports", label: "Reports", icon: FileText },
    { to: "/government/settings", label: "Privacy & Audit", icon: Settings },
  ],
  provider: [
    { to: "/provider/dashboard", label: "Dashboard", icon: LayoutDashboard },
    { to: "/provider/trainees", label: "My Trainees", icon: Users },
    { to: "/provider/outcomes", label: "Outcomes", icon: Briefcase },
    { to: "/provider/skill-gaps", label: "Skill Gaps", icon: TrendingDown },
  ],
  trainee: [
    { to: "/trainee/dashboard", label: "My Dashboard", icon: LayoutDashboard },
    { to: "/trainee/profile", label: "My Profile", icon: UserCircle },
    { to: "/trainee/followup", label: "Follow-up Form", icon: ListChecks },
    { to: "/trainee/privacy", label: "Privacy", icon: Shield },
  ],
  employer: [
    { to: "/employer/dashboard", label: "Dashboard", icon: LayoutDashboard },
    { to: "/employer/verifications", label: "Verification Requests", icon: ClipboardList },
    { to: "/employer/history", label: "History", icon: History },
  ],
};

export default function Sidebar({ role, open }) {
  const items = [...(NAV[role] || []), { to: `/${role}/account-settings`, label: "Account Settings", icon: SlidersHorizontal }];
  return (
    <aside className={`border-r border-white/10 flex flex-col transition-all duration-200 ${open ? "w-64" : "w-0 md:w-16"} overflow-hidden shrink-0 h-full`} style={{ background: "rgba(255,255,255,0.02)" }}>
      <div className="h-16 flex items-center gap-2 px-4 border-b border-white/10 shrink-0">
        <div className="w-8 h-8 rounded-lg bg-brand-500/20 border border-brand-400/40 flex items-center justify-center font-bold text-sm text-brand-300 shrink-0">ST</div>
        {open && <span className="font-semibold text-white whitespace-nowrap">SkillTrack MH</span>}
      </div>
      <nav className="flex-1 py-3 px-2 space-y-1 overflow-y-auto">
        {items.map((item) => (
          <NavLink key={item.to} to={item.to}
            className={({ isActive }) =>
              `flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                isActive ? "bg-brand-500/15 text-brand-200 border border-brand-500/30" : "text-slate-400 hover:bg-white/5 hover:text-slate-200 border border-transparent"
              }`
            }
          >
            <item.icon size={18} className="shrink-0" />
            {open && <span className="whitespace-nowrap">{item.label}</span>}
          </NavLink>
        ))}
      </nav>
    </aside>
  );
}
