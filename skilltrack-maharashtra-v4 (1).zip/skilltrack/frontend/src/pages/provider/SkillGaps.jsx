import React, { useEffect, useState } from "react";
import DashboardLayout from "../../components/layout/DashboardLayout";
import DataTable from "../../components/common/DataTable";
import { useAuth } from "../../context/AuthContext";
import api from "../../api/client";

export default function ProviderSkillGaps() {
  const { user } = useAuth();
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      const { data } = await api.get("/analytics/skill-gaps");
      const mine = data.filter(
        (g) => String(g.programId?.providerId) === String(user?.linkedId)
      );
      setRows(
        mine.map((g) => ({
          id: g._id,
          course: g.programId?.name,
          skill: g.skill,
          industryDemand: g.industryDemand,
          currentLevel: g.currentLevel,
          gap: g.gap,
        }))
      );
      setLoading(false);
    }
    if (user) load();
  }, [user]);

  const columns = [
    { key: "course", label: "Course" },
    { key: "skill", label: "Skill" },
    { key: "industryDemand", label: "Industry Demand", render: (r) => `${r.industryDemand}%` },
    { key: "currentLevel", label: "Current Level", render: (r) => `${r.currentLevel}%` },
    { key: "gap", label: "Gap", render: (r) => `${r.gap}%` },
  ];

  return (
    <DashboardLayout role="provider">
      <div className="mb-5">
        <h1 className="text-xl font-semibold text-gray-900">Skill Gaps — Your Courses</h1>
        <p className="text-sm text-gray-500">Industry demand vs measured skill level for trainees you trained.</p>
      </div>
      {loading ? (
        <div className="text-sm text-gray-400">Loading…</div>
      ) : rows.length ? (
        <DataTable columns={columns} rows={rows} pageSize={12} searchable={false} />
      ) : (
        <p className="text-sm text-gray-400">No skill-gap data available for your courses yet.</p>
      )}
    </DashboardLayout>
  );
}
