import React, { useEffect, useState } from "react";
import { Sparkles, Upload, Loader2, FileText, KeyRound, Copy, Download } from "lucide-react";
import DashboardLayout from "../../components/layout/DashboardLayout";
import DataTable from "../../components/common/DataTable";
import StatusBadge from "../../components/common/StatusBadge";
import { Modal, useToast } from "../../components/common/Modal";
import { useAuth } from "../../context/AuthContext";
import api from "../../api/client";

export default function ProviderTrainees() {
  const { user } = useAuth();
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [reportTarget, setReportTarget] = useState(null);
  const [showCredentials, setShowCredentials] = useState(false);

  async function load() {
    const { data } = await api.get("/trainees", { params: { providerId: user?.linkedId, limit: 200 } });
    setRows(
      data.items.map((t) => {
        const th = t.trainingHistory?.[t.trainingHistory.length - 1];
        return {
          id: t._id,
          traineeCode: t.traineeCode,
          name: t.name,
          district: t.districtId?.name,
          course: th?.programId?.name,
          certified: th?.certified ? "Yes" : "No",
          status: t.currentOutcomeStatus,
        };
      })
    );
    setLoading(false);
  }

  useEffect(() => {
    if (user) load();
  }, [user]);

  const columns = [
    { key: "traineeCode", label: "Trainee ID" },
    { key: "name", label: "Name" },
    { key: "district", label: "District" },
    { key: "course", label: "Course" },
    { key: "certified", label: "Certified" },
    { key: "status", label: "Outcome", render: (r) => <StatusBadge status={r.status} /> },
    {
      key: "actions",
      label: "Report",
      render: (r) => (
        <button
          onClick={() => setReportTarget(r)}
          className="inline-flex items-center gap-1.5 text-xs font-medium text-brand-300 hover:text-brand-200 bg-brand-500/10 px-2.5 py-1.5 rounded-md"
        >
          <FileText size={13} /> Manage
        </button>
      ),
    },
  ];

  return (
    <DashboardLayout role="provider">
      <div className="mb-5 flex items-start justify-between gap-4">
        <div>
          <h1 className="text-xl font-semibold text-white">My Trainees</h1>
          <p className="text-sm text-slate-500">
            Trainees enrolled through your organization. Generate or upload their progress report —
            trainees see this instead of a raw assessment score.
          </p>
        </div>
        <button
          onClick={() => setShowCredentials(true)}
          className="shrink-0 flex items-center gap-1.5 text-xs font-medium text-brand-300 hover:text-brand-200 bg-brand-500/10 px-3 py-2 rounded-lg"
        >
          <KeyRound size={14} /> Login Credentials
        </button>
      </div>
      {loading ? <div className="text-sm text-slate-500">Loading…</div> : <DataTable columns={columns} rows={rows} pageSize={12} />}

      <ReportModal target={reportTarget} onClose={() => setReportTarget(null)} providerId={user?.linkedId} />
      <CredentialsModal open={showCredentials} onClose={() => setShowCredentials(false)} providerId={user?.linkedId} />
    </DashboardLayout>
  );
}

// One consolidated list — Name / Login ID / Password — for every trainee
// under this provider. Lets the provider view it any time and copy or
// download a row to forward to that trainee, instead of a PDF per trainee.
function CredentialsModal({ open, onClose, providerId }) {
  const toast = useToast();
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!open) return;
    setLoading(true);
    api
      .get("/trainees/credentials", { params: { providerId } })
      .then(({ data }) => setRows(data))
      .catch(() => toast?.push("Could not load credentials", "error"))
      .finally(() => setLoading(false));
  }, [open, providerId]);

  function copyRow(r) {
    navigator.clipboard.writeText(`Name: ${r.name}\nLogin ID: ${r.uniqueId}\nPassword: ${r.password}`);
    toast?.push(`Copied ${r.name}'s login — ready to send`);
  }

  function downloadPdf() {
    const base = api.defaults.baseURL;
    window.open(`${base}/trainees/credentials/pdf?providerId=${providerId || ""}`, "_blank");
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="Trainee Login Credentials"
      footer={
        <button
          onClick={downloadPdf}
          className="flex items-center gap-1.5 bg-brand-600 hover:bg-brand-500 text-white text-sm font-medium px-4 py-2 rounded-lg"
        >
          <Download size={14} /> Download PDF (all)
        </button>
      }
    >
      <p className="text-xs text-slate-500 mb-3">
        Copy a trainee's row to send it to them directly, or download the full list as a PDF.
      </p>
      {loading ? (
        <div className="text-sm text-slate-500">Loading…</div>
      ) : rows.length === 0 ? (
        <div className="text-sm text-slate-500">No trainees yet.</div>
      ) : (
        <div className="divide-y divide-white/10 max-h-96 overflow-y-auto">
          {rows.map((r) => (
            <div key={r.id} className="flex items-center justify-between gap-3 py-2.5">
              <div className="min-w-0">
                <p className="text-sm text-white truncate">{r.name}</p>
                <p className="text-xs text-slate-500">
                  {r.uniqueId} &middot; {r.password}
                </p>
              </div>
              <button
                onClick={() => copyRow(r)}
                className="shrink-0 flex items-center gap-1 text-xs text-brand-300 hover:text-brand-200 bg-brand-500/10 px-2.5 py-1.5 rounded-md"
              >
                <Copy size={12} /> Copy
              </button>
            </div>
          ))}
        </div>
      )}
    </Modal>
  );
}

function ReportModal({ target, onClose, providerId }) {
  const toast = useToast();
  const [generating, setGenerating] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [content, setContent] = useState("");
  const [file, setFile] = useState(null);

  async function generate() {
    setGenerating(true);
    try {
      const { data } = await api.post("/reports-ai/generate", { traineeId: target.id, providerId });
      setContent(data.aiContent);
      toast?.push("AI report generated");
    } catch (err) {
      toast?.push(err?.response?.data?.message || "Could not generate report", "error");
    } finally {
      setGenerating(false);
    }
  }

  async function upload() {
    if (!file) return;
    setUploading(true);
    try {
      const form = new FormData();
      form.append("file", file);
      form.append("traineeId", target.id);
      form.append("providerId", providerId);
      await api.post("/reports-ai/upload", form, { headers: { "Content-Type": "multipart/form-data" } });
      toast?.push("Report file uploaded");
      setFile(null);
    } catch (err) {
      toast?.push(err?.response?.data?.message || "Upload failed", "error");
    } finally {
      setUploading(false);
    }
  }

  return (
    <Modal open={!!target} onClose={onClose} title={target ? `Report — ${target.name}` : ""}>
      {target && (
        <div className="space-y-5">
          <div>
            <p className="text-xs font-medium text-slate-400 mb-2">Generate with AI (Gemini)</p>
            <button onClick={generate} disabled={generating}
              className="flex items-center gap-2 bg-brand-600 hover:bg-brand-500 text-white text-sm font-medium px-4 py-2 rounded-lg">
              {generating ? <Loader2 size={15} className="animate-spin" /> : <Sparkles size={15} />} Generate AI Report
            </button>
            {content && (
              <div className="mt-3 text-xs text-slate-400 whitespace-pre-wrap bg-white/5 border border-white/10 rounded-lg p-3 max-h-56 overflow-y-auto">
                {content}
              </div>
            )}
          </div>

          <div className="pt-4 border-t border-white/10">
            <p className="text-xs font-medium text-slate-400 mb-2">Or upload a document</p>
            <div className="flex items-center gap-2">
              <input type="file" onChange={(e) => setFile(e.target.files?.[0] || null)}
                className="text-xs text-slate-400 file:mr-3 file:py-1.5 file:px-3 file:rounded-md file:border-0 file:bg-white/10 file:text-slate-300 file:text-xs" />
              <button onClick={upload} disabled={!file || uploading}
                className="flex items-center gap-1.5 bg-white/10 hover:bg-white/20 text-slate-200 text-xs font-medium px-3 py-1.5 rounded-md disabled:opacity-50">
                {uploading ? <Loader2 size={13} className="animate-spin" /> : <Upload size={13} />} Upload
              </button>
            </div>
            <p className="text-[11px] text-slate-600 mt-2">PDF/DOC, stored on Cloudinary. Trainee sees a "View Report" link.</p>
          </div>
        </div>
      )}
    </Modal>
  );
}
