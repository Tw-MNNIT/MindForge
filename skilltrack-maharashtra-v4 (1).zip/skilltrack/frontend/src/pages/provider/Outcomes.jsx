import React, { useEffect, useState } from "react";
import DashboardLayout from "../../components/layout/DashboardLayout";
import DataTable from "../../components/common/DataTable";
import { useAuth } from "../../context/AuthContext";
import api from "../../api/client";

export default function ProviderOutcomes() {
  const { user } = useAuth();
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      const [coursesRes, programsRes] = await Promise.all([
        api.get("/analytics/courses"),
        api.get("/catalog/programs"),
      ]);
      const myProgramIds = new Set(
        programsRes.data.filter((p) => String(p.providerId?._id || p.providerId) === String(user?.linkedId)).map((p) => p._id)
      );
      const mine = coursesRes.data.filter((c) => myProgramIds.has(String(c.programId)));
      setRows(mine.map((c) => ({ id: c.programId, ...c })));
      setLoading(false);
    }
    if (user) load();
  }, [user]);

  const columns = [
    { key: "course", label: "Course" },
    { key: "enrollment", label: "Enrollment" },
    { key: "completion", label: "Completion" },
    { key: "dropout", label: "Dropout" },
    { key: "placementRate", label: "Placement Rate", render: (r) => `${r.placementRate}%` },
    { key: "retentionRate", label: "Retention Rate", render: (r) => `${r.retentionRate}%` },
    { key: "avgSalary", label: "Avg Salary", render: (r) => `₹${r.avgSalary.toLocaleString("en-IN")}` },
  ];

  return (
    <DashboardLayout role="provider">
      <div className="mb-5">
        <h1 className="text-xl font-semibold text-gray-900">Outcomes by Course</h1>
        <p className="text-sm text-gray-500">Placement, retention and salary outcomes for courses run at your centres.</p>
      </div>
      {loading ? (
        <div className="text-sm text-gray-400">Loading…</div>
      ) : rows.length ? (
        <DataTable columns={columns} rows={rows} pageSize={12} searchable={false} />
      ) : (
        <p className="text-sm text-gray-400">No courses are currently associated with your provider account.</p>
      )}
    </DashboardLayout>
  );
}
