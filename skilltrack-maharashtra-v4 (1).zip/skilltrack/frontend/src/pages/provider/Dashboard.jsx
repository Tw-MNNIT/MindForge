import React, { useEffect, useState } from "react";
import { Users, GraduationCap, Briefcase, ShieldCheck, Wallet, ClipboardCheck } from "lucide-react";
import DashboardLayout from "../../components/layout/DashboardLayout";
import KpiCard from "../../components/common/KpiCard";
import { useAuth } from "../../context/AuthContext";
import api from "../../api/client";

export default function ProviderDashboard() {
  const { user } = useAuth();
  const [row, setRow] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      const { data } = await api.get("/analytics/providers");
      const mine = data.find((p) => String(p.providerId) === String(user?.linkedId));
      setRow(mine || null);
      setLoading(false);
    }
    if (user) load();
  }, [user]);

  return (
    <DashboardLayout role="provider">
      <div className="mb-6">
        <h1 className="text-2xl font-semibold text-gray-900">{user?.name}</h1>
        <p className="text-gray-500 text-sm mt-1">How are our trainees performing after training?</p>
      </div>

      {loading ? (
        <div className="text-sm text-gray-400">Loading…</div>
      ) : row ? (
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          <KpiCard label="Trainees" value={row.trainees} icon={Users} />
          <KpiCard label="Completion Rate" value={`${row.completionRate}%`} icon={GraduationCap} accent="green" />
          <KpiCard label="Placement Rate" value={`${row.placementRate}%`} icon={Briefcase} accent="brand" />
          <KpiCard label="Employer Verification" value={`${row.verificationRate}%`} icon={ShieldCheck} accent="green" />
          <KpiCard label="Follow-up Response" value={`${row.followUpResponseRate}%`} icon={ClipboardCheck} accent="brand" />
          <KpiCard label="Average Salary" value={`₹${row.avgSalary.toLocaleString("en-IN")}/mo`} icon={Wallet} accent="amber" />
        </div>
      ) : (
        <p className="text-sm text-gray-400">No performance data available for this provider yet.</p>
      )}

      <p className="text-xs text-gray-400 mt-6">Demo Data — Fictional Prototype Dataset.</p>
    </DashboardLayout>
  );
}
