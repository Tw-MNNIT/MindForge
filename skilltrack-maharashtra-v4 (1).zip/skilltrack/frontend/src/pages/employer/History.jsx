import React, { useEffect, useState } from "react";
import DashboardLayout from "../../components/layout/DashboardLayout";
import DataTable from "../../components/common/DataTable";
import StatusBadge from "../../components/common/StatusBadge";
import { useAuth } from "../../context/AuthContext";
import api from "../../api/client";

function fmtDate(d) {
  if (!d) return "—";
  return new Date(d).toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" });
}
function fmtMoney(n) {
  if (!n && n !== 0) return "—";
  return `₹${Number(n).toLocaleString("en-IN")}`;
}

export default function EmployerHistory() {
  const { user } = useAuth();
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      const { data } = await api.get("/employers/verifications/resolved", {
        params: { employerId: user?.linkedId },
      });
      setRows(
        data.map((o) => ({
          id: o._id,
          trainee: o.traineeId?.name,
          traineeCode: o.traineeId?.traineeCode,
          jobTitle: o.jobTitle,
          salary: fmtMoney(o.salaryHistory?.[o.salaryHistory.length - 1]?.monthlySalary),
          respondedAt: fmtDate(o.verification?.respondedAt),
          status: o.verification?.status,
          notes: o.verification?.employerNotes,
        }))
      );
      setLoading(false);
    }
    if (user) load();
  }, [user]);

  const columns = [
    { key: "traineeCode", label: "Trainee ID" },
    { key: "trainee", label: "Trainee" },
    { key: "jobTitle", label: "Job Title" },
    { key: "salary", label: "Salary" },
    { key: "respondedAt", label: "Responded On" },
    { key: "status", label: "Decision", render: (r) => <StatusBadge status={r.status} /> },
    { key: "notes", label: "Notes" },
  ];

  return (
    <DashboardLayout role="employer">
      <div className="mb-5">
        <h1 className="text-xl font-semibold text-gray-900">Verification History</h1>
        <p className="text-sm text-gray-500">Every employment claim you've previously confirmed or rejected.</p>
      </div>
      {loading ? (
        <div className="text-sm text-gray-400">Loading…</div>
      ) : (
        <DataTable columns={columns} rows={rows} pageSize={12} />
      )}
    </DashboardLayout>
  );
}
