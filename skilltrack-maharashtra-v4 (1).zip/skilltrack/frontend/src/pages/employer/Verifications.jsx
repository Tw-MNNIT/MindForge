import React, { useEffect, useState } from "react";
import { CheckCircle2, XCircle } from "lucide-react";
import DashboardLayout from "../../components/layout/DashboardLayout";
import StatusBadge from "../../components/common/StatusBadge";
import { Modal, useToast } from "../../components/common/Modal";
import { useAuth } from "../../context/AuthContext";
import api from "../../api/client";

function fmtDate(d) {
  if (!d) return "—";
  return new Date(d).toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" });
}
function fmtMoney(n) {
  if (!n && n !== 0) return "—";
  return `₹${Number(n).toLocaleString("en-IN")}`;
}

export default function EmployerVerifications() {
  const { user } = useAuth();
  const toast = useToast();
  const [pending, setPending] = useState([]);
  const [loading, setLoading] = useState(true);
  const [reviewing, setReviewing] = useState(null);
  const [notes, setNotes] = useState("");
  const [saving, setSaving] = useState(false);

  async function load() {
    setLoading(true);
    const { data } = await api.get("/employers/verifications/pending", {
      params: { employerId: user?.linkedId },
    });
    setPending(data);
    setLoading(false);
  }

  useEffect(() => {
    if (user) load();
  }, [user]);

  async function respond(outcomeId, decision) {
    setSaving(true);
    try {
      await api.put(`/employers/verifications/${outcomeId}`, {
        decision,
        employerNotes: notes,
        actorLabel: user?.name,
      });
      toast?.push(decision === "confirm" ? "Employment confirmed." : "Employment rejected.");
      setReviewing(null);
      setNotes("");
      load();
    } catch (err) {
      toast?.push(err?.response?.data?.message || "Could not submit response.", "error");
    } finally {
      setSaving(false);
    }
  }

  return (
    <DashboardLayout role="employer">
      <div className="mb-5">
        <h1 className="text-xl font-semibold text-gray-900">Verification Requests</h1>
        <p className="text-sm text-gray-500">
          Trainees have reported employment with your organization. Please confirm or reject each claim.
        </p>
      </div>

      {loading ? (
        <div className="text-sm text-gray-400">Loading…</div>
      ) : pending.length === 0 ? (
        <div className="card p-8 text-center text-sm text-gray-400">No pending verification requests.</div>
      ) : (
        <div className="grid md:grid-cols-2 gap-4">
          {pending.map((o) => (
            <div key={o._id} className="card p-5 flex flex-col gap-3">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold text-gray-900">{o.traineeId?.name}</h3>
                <StatusBadge status="pending" />
              </div>
              <dl className="text-sm space-y-1.5">
                <Row label="Trainee ID" value={o.traineeId?.traineeCode} />
                <Row label="Job Title" value={o.jobTitle} />
                <Row label="Employment Type" value={o.employmentType} />
                <Row label="Joining Date" value={fmtDate(o.joiningDate)} />
                <Row label="Work Location" value={o.workLocation} />
                <Row label="Reported Salary" value={fmtMoney(o.salaryHistory?.[o.salaryHistory.length - 1]?.monthlySalary)} />
              </dl>
              <button
                onClick={() => setReviewing(o)}
                className="mt-2 w-full bg-brand-600 hover:bg-brand-700 text-white text-sm font-medium py-2 rounded-lg"
              >
                Review &amp; Respond
              </button>
            </div>
          ))}
        </div>
      )}

      <Modal
        open={!!reviewing}
        onClose={() => {
          setReviewing(null);
          setNotes("");
        }}
        title={`Verify: ${reviewing?.traineeId?.name || ""}`}
        footer={
          <>
            <button
              disabled={saving}
              onClick={() => respond(reviewing._id, "reject")}
              className="flex items-center gap-1.5 text-sm font-medium px-3 py-1.5 rounded-lg border border-red-200 text-red-600 hover:bg-red-50"
            >
              <XCircle size={14} /> Reject
            </button>
            <button
              disabled={saving}
              onClick={() => respond(reviewing._id, "confirm")}
              className="flex items-center gap-1.5 text-sm font-medium px-3 py-1.5 rounded-lg bg-emerald-600 text-white hover:bg-emerald-700"
            >
              <CheckCircle2 size={14} /> Confirm
            </button>
          </>
        }
      >
        {reviewing && (
          <div className="space-y-3">
            <dl className="text-sm space-y-1.5">
              <Row label="Job Title" value={reviewing.jobTitle} />
              <Row label="Joining Date" value={fmtDate(reviewing.joiningDate)} />
              <Row label="Employment Type" value={reviewing.employmentType} />
              <Row label="Salary Claimed" value={fmtMoney(reviewing.salaryHistory?.[reviewing.salaryHistory.length - 1]?.monthlySalary)} />
            </dl>
            <div>
              <label className="text-xs font-medium text-gray-500">Notes (optional)</label>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                rows={3}
                placeholder="e.g. Confirmed by HR records"
                className="mt-1 w-full border border-gray-200 rounded-lg px-3 py-2 text-sm"
              />
            </div>
          </div>
        )}
      </Modal>
    </DashboardLayout>
  );
}

function Row({ label, value }) {
  return (
    <div className="flex items-center justify-between">
      <dt className="text-gray-500">{label}</dt>
      <dd className="font-medium text-gray-800">{value ?? "—"}</dd>
    </div>
  );
}
