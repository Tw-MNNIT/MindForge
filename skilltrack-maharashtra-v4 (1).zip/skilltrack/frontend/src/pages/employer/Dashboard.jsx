import React, { useEffect, useState } from "react";
import { ClipboardCheck, CheckCircle2, History as HistoryIcon } from "lucide-react";
import DashboardLayout from "../../components/layout/DashboardLayout";
import KpiCard from "../../components/common/KpiCard";
import { useAuth } from "../../context/AuthContext";
import api from "../../api/client";

export default function EmployerDashboard() {
  const { user } = useAuth();
  const [pending, setPending] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      const { data } = await api.get("/employers/verifications/pending", {
        params: { employerId: user?.linkedId },
      });
      setPending(data);
      setLoading(false);
    }
    if (user) load();
  }, [user]);

  return (
    <DashboardLayout role="employer">
      <div className="mb-6">
        <h1 className="text-2xl font-semibold text-gray-900">{user?.name}</h1>
        <p className="text-gray-500 text-sm mt-1">Can we verify this employment outcome?</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-6">
        <KpiCard label="Pending Verification Requests" value={loading ? "…" : pending.length} icon={ClipboardCheck} accent="amber" />
      </div>

      <div className="card p-5">
        <h3 className="font-semibold text-gray-900 mb-4">Recent Requests Awaiting Your Response</h3>
        {loading ? (
          <p className="text-sm text-gray-400">Loading…</p>
        ) : pending.length === 0 ? (
          <p className="text-sm text-gray-400">No pending verification requests right now.</p>
        ) : (
          <ul className="divide-y divide-gray-100">
            {pending.slice(0, 5).map((o) => (
              <li key={o._id} className="py-3 flex items-center justify-between text-sm">
                <div>
                  <p className="font-medium text-gray-800">{o.traineeId?.name}</p>
                  <p className="text-gray-500">{o.jobTitle} · joined {o.joiningDate ? new Date(o.joiningDate).toLocaleDateString("en-IN") : "—"}</p>
                </div>
                <a href="/employer/verifications" className="text-brand-600 font-medium">Review →</a>
              </li>
            ))}
          </ul>
        )}
      </div>

      <div className="grid md:grid-cols-2 gap-4 mt-6">
        <a href="/employer/verifications" className="card p-5 hover:border-brand-300 transition-colors flex items-start gap-3">
          <CheckCircle2 size={18} className="text-emerald-600 mt-0.5" />
          <div>
            <h3 className="font-semibold text-gray-900">Verification Requests</h3>
            <p className="text-sm text-gray-500 mt-1">Confirm or reject employment claims from trainees.</p>
          </div>
        </a>
        <a href="/employer/history" className="card p-5 hover:border-brand-300 transition-colors flex items-start gap-3">
          <HistoryIcon size={18} className="text-brand-600 mt-0.5" />
          <div>
            <h3 className="font-semibold text-gray-900">Verification History</h3>
            <p className="text-sm text-gray-500 mt-1">See everything you've previously confirmed or rejected.</p>
          </div>
        </a>
      </div>
    </DashboardLayout>
  );
}
