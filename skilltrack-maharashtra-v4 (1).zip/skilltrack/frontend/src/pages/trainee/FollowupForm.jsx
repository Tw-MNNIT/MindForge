import React, { useEffect, useState } from "react";
import { CheckCircle2, Clock } from "lucide-react";
import DashboardLayout from "../../components/layout/DashboardLayout";
import { Modal, useToast } from "../../components/common/Modal";

const LOCKED_CHECKPOINTS = ["18_month", "24_month"];
import { useAuth } from "../../context/AuthContext";
import api from "../../api/client";

const REASONS = [
  "Technical Skill Gap", "Communication Gap", "Lack of Local Opportunities", "Salary Mismatch",
  "Relocation/Mobility Constraint", "Lack of Experience", "Further Education", "Personal Reasons", "Other",
];

export default function TraineeFollowupForm() {
  const { user } = useAuth();
  const toast = useToast();
  const [pending, setPending] = useState([]);
  const [selectedId, setSelectedId] = useState("");
  const [employers, setEmployers] = useState([]);
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [timesUp, setTimesUp] = useState(false);

  const [form, setForm] = useState({
    currentStatus: "Employed",
    notes: "",
    // employed
    employerId: "",
    jobTitle: "",
    employmentType: "Full-time",
    workLocation: "",
    joiningDate: "",
    monthlySalary: "",
    // self-employed
    businessType: "",
    monthlyIncome: "",
    businessDurationMonths: "",
    // apprenticeship
    organization: "",
    stipend: "",
    durationMonths: "",
    // unemployed
    reason: REASONS[0],
    lookingForEmployment: true,
    skillsNeeded: "",
  });

  useEffect(() => {
    async function load() {
      if (!user?.linkedId) {
        setLoading(false);
        return;
      }
      const [followUpsRes, employersRes] = await Promise.all([
        api.get(`/trainees/${user.linkedId}/followups`, { params: { status: "Pending" } }),
        api.get("/employers"),
      ]);
      const items = followUpsRes.data.items || [];
      const fillable = items.filter((f) => !LOCKED_CHECKPOINTS.includes(f.checkpoint));
      setPending(fillable);
      setEmployers(employersRes.data);
      if (fillable[0]) setSelectedId(fillable[0]._id);
      if (fillable.length === 0 && items.length > 0) setTimesUp(true);
      setLoading(false);
    }
    load();
  }, [user]);

  function update(field, value) {
    setForm((f) => ({ ...f, [field]: value }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setSaving(true);
    try {
      const payload = { currentStatus: form.currentStatus, notes: form.notes };
      if (form.currentStatus === "Employed") {
        Object.assign(payload, {
          employerId: form.employerId,
          jobTitle: form.jobTitle,
          employmentType: form.employmentType,
          workLocation: form.workLocation,
          joiningDate: form.joiningDate || undefined,
          monthlySalary: form.monthlySalary,
        });
      } else if (form.currentStatus === "Self-Employed") {
        Object.assign(payload, {
          businessType: form.businessType,
          monthlyIncome: form.monthlyIncome,
          businessDurationMonths: form.businessDurationMonths,
        });
      } else if (form.currentStatus === "Apprenticeship") {
        Object.assign(payload, {
          organization: form.organization,
          stipend: form.stipend,
          durationMonths: form.durationMonths,
        });
      } else if (form.currentStatus === "Unemployed") {
        Object.assign(payload, {
          reason: form.reason,
          lookingForEmployment: form.lookingForEmployment,
          skillsNeeded: form.skillsNeeded ? form.skillsNeeded.split(",").map((s) => s.trim()) : [],
        });
      }

      await api.put(`/followups/${selectedId}/submit`, payload);
      setSubmitted(true);
      toast?.push("Outcome submitted — thank you!");
    } catch (err) {
      toast?.push(err?.response?.data?.message || "Could not submit outcome.", "error");
    } finally {
      setSaving(false);
    }
  }

  return (
    <DashboardLayout role="trainee">
      <Modal open={timesUp} onClose={() => setTimesUp(false)} title="Follow-up Window Closed">
        <div className="text-center py-2">
          <Clock size={36} className="text-amber-400 mx-auto mb-3" />
          <p className="text-white font-semibold mb-1">Your time is over</p>
          <p className="text-sm text-slate-400">
            Follow-ups can only be submitted up to the 12-month checkpoint. This trainee's window
            (18 months+) has closed.
          </p>
        </div>
      </Modal>

      <div className="mb-5">
        <h1 className="text-xl font-semibold text-gray-900">Follow-up Form</h1>
        <p className="text-sm text-gray-500">A short, structured update — this should take under a minute.</p>
      </div>

      {loading ? (
        <div className="text-sm text-gray-400">Loading…</div>
      ) : submitted ? (
        <div className="card p-8 text-center">
          <CheckCircle2 size={40} className="text-emerald-500 mx-auto mb-3" />
          <h3 className="font-semibold text-gray-900 text-lg">Thank you!</h3>
          <p className="text-sm text-gray-500 mt-1">Your outcome update has been recorded.</p>
        </div>
      ) : timesUp ? (
        <div className="card p-8 text-center">
          <Clock size={40} className="text-amber-400 mx-auto mb-3" />
          <h3 className="font-semibold text-white text-lg">Your Time Is Over</h3>
          <p className="text-sm text-slate-500 mt-1 max-w-sm mx-auto">
            The follow-up window for this checkpoint (18 months and beyond) has closed. No further
            outcome updates can be submitted through this form.
          </p>
        </div>
      ) : pending.length === 0 ? (
        <div className="card p-8 text-center text-sm text-gray-400">
          No follow-up is currently due. Check back closer to your next checkpoint.
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="card p-6 max-w-xl space-y-5">
          {pending.length > 1 && (
            <div>
              <label className="text-xs font-medium text-gray-500">Which follow-up?</label>
              <select
                value={selectedId}
                onChange={(e) => setSelectedId(e.target.value)}
                className="mt-1 w-full border border-gray-200 rounded-lg px-3 py-2 text-sm"
              >
                {pending.map((f) => (
                  <option key={f._id} value={f._id}>
                    {f.checkpoint.replace("_", " ")} follow-up
                  </option>
                ))}
              </select>
            </div>
          )}

          <div>
            <label className="text-xs font-medium text-gray-500">Your current status</label>
            <select
              value={form.currentStatus}
              onChange={(e) => update("currentStatus", e.target.value)}
              className="mt-1 w-full border border-gray-200 rounded-lg px-3 py-2 text-sm"
            >
              <option>Employed</option>
              <option>Self-Employed</option>
              <option>Apprenticeship</option>
              <option>Unemployed</option>
              <option>Further Education</option>
            </select>
          </div>

          {form.currentStatus === "Employed" && (
            <div className="grid grid-cols-2 gap-3">
              <Field label="Employer" full>
                <select
                  value={form.employerId}
                  onChange={(e) => update("employerId", e.target.value)}
                  required
                  className="mt-1 w-full border border-gray-200 rounded-lg px-3 py-2 text-sm"
                >
                  <option value="">Select employer…</option>
                  {employers.map((e) => (
                    <option key={e._id} value={e._id}>{e.name}</option>
                  ))}
                </select>
              </Field>
              <Field label="Job Title">
                <input value={form.jobTitle} onChange={(e) => update("jobTitle", e.target.value)} required className="input" />
              </Field>
              <Field label="Employment Type">
                <select value={form.employmentType} onChange={(e) => update("employmentType", e.target.value)} className="input">
                  <option>Full-time</option>
                  <option>Part-time</option>
                  <option>Contract</option>
                  <option>Daily Wage</option>
                </select>
              </Field>
              <Field label="Joining Date">
                <input type="date" value={form.joiningDate} onChange={(e) => update("joiningDate", e.target.value)} className="input" />
              </Field>
              <Field label="Monthly Salary (₹)">
                <input type="number" value={form.monthlySalary} onChange={(e) => update("monthlySalary", e.target.value)} required className="input" />
              </Field>
              <Field label="Work Location" full>
                <input value={form.workLocation} onChange={(e) => update("workLocation", e.target.value)} className="input" />
              </Field>
            </div>
          )}

          {form.currentStatus === "Self-Employed" && (
            <div className="grid grid-cols-2 gap-3">
              <Field label="Business Type" full>
                <input value={form.businessType} onChange={(e) => update("businessType", e.target.value)} required className="input" />
              </Field>
              <Field label="Monthly Income (₹)">
                <input type="number" value={form.monthlyIncome} onChange={(e) => update("monthlyIncome", e.target.value)} required className="input" />
              </Field>
              <Field label="Business Duration (months)">
                <input type="number" value={form.businessDurationMonths} onChange={(e) => update("businessDurationMonths", e.target.value)} className="input" />
              </Field>
            </div>
          )}

          {form.currentStatus === "Apprenticeship" && (
            <div className="grid grid-cols-2 gap-3">
              <Field label="Organization" full>
                <input value={form.organization} onChange={(e) => update("organization", e.target.value)} required className="input" />
              </Field>
              <Field label="Stipend (₹)">
                <input type="number" value={form.stipend} onChange={(e) => update("stipend", e.target.value)} className="input" />
              </Field>
              <Field label="Duration (months)">
                <input type="number" value={form.durationMonths} onChange={(e) => update("durationMonths", e.target.value)} className="input" />
              </Field>
            </div>
          )}

          {form.currentStatus === "Unemployed" && (
            <div className="space-y-3">
              <Field label="Reason" full>
                <select value={form.reason} onChange={(e) => update("reason", e.target.value)} className="input">
                  {REASONS.map((r) => <option key={r}>{r}</option>)}
                </select>
              </Field>
              <label className="flex items-center gap-2 text-sm text-gray-700">
                <input
                  type="checkbox"
                  checked={form.lookingForEmployment}
                  onChange={(e) => update("lookingForEmployment", e.target.checked)}
                />
                Currently looking for employment
              </label>
              <Field label="Skills that need improvement (comma-separated)" full>
                <input value={form.skillsNeeded} onChange={(e) => update("skillsNeeded", e.target.value)} className="input" />
              </Field>
            </div>
          )}

          <Field label="Anything else you'd like to add? (optional)" full>
            <textarea value={form.notes} onChange={(e) => update("notes", e.target.value)} rows={3} className="input" />
          </Field>

          <button
            type="submit"
            disabled={saving}
            className="w-full bg-brand-600 hover:bg-brand-700 text-white font-medium py-2.5 rounded-lg text-sm"
          >
            {saving ? "Submitting…" : "Submit Outcome"}
          </button>
        </form>
      )}

      <style>{`.input { margin-top: 0.25rem; width: 100%; border: 1px solid #e5e7eb; border-radius: 0.5rem; padding: 0.5rem 0.75rem; font-size: 0.875rem; }`}</style>
    </DashboardLayout>
  );
}

function Field({ label, children, full }) {
  return (
    <div className={full ? "col-span-2" : ""}>
      <label className="text-xs font-medium text-gray-500">{label}</label>
      {children}
    </div>
  );
}
