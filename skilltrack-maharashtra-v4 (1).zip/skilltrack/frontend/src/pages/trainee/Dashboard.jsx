import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { ListChecks, ShieldCheck, ArrowRight } from "lucide-react";
import DashboardLayout from "../../components/layout/DashboardLayout";
import StatusBadge from "../../components/common/StatusBadge";
import TraineeProfileView from "../../components/trainees/TraineeProfileView";
import { useAuth } from "../../context/AuthContext";
import api from "../../api/client";

export default function TraineeDashboard() {
  const { user } = useAuth();
  const [profile, setProfile] = useState(null);
  const [pendingFollowUps, setPendingFollowUps] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      if (!user?.linkedId) {
        setLoading(false);
        return;
      }
      const [profileRes, followUpsRes] = await Promise.all([
        api.get(`/trainees/${user.linkedId}`),
        api.get(`/trainees/${user.linkedId}/followups`, { params: { status: "Pending" } }),
      ]);
      setProfile(profileRes.data);
      setPendingFollowUps(followUpsRes.data.items || []);
      setLoading(false);
    }
    load();
  }, [user]);

  return (
    <DashboardLayout role="trainee">
      <div className="mb-6">
        <h1 className="text-2xl font-semibold text-white">Welcome, {user?.name}</h1>
        <p className="text-slate-500 text-sm mt-1">Here&apos;s where your career journey stands today.</p>
      </div>

      {loading ? (
        <div className="text-sm text-slate-500">Loading…</div>
      ) : !profile ? (
        <p className="text-sm text-slate-500">No linked trainee record found for this login.</p>
      ) : (
        <div className="space-y-5">
          <div className="card p-5 flex flex-wrap items-center gap-4">
            <div>
              <p className="text-sm text-slate-500">Current Status</p>
              <div className="mt-1"><StatusBadge status={profile.trainee.currentOutcomeStatus} /></div>
            </div>
            <div>
              <p className="text-sm text-slate-500">Consent Status</p>
              <div className="mt-1"><StatusBadge status={profile.consent?.status} /></div>
            </div>
            <Link to="/trainee/profile" className="ml-auto text-sm font-medium text-brand-300 flex items-center gap-1">
              View Full Profile <ArrowRight size={14} />
            </Link>
          </div>

          {pendingFollowUps.length > 0 && (
            <div className="card p-5 border-l-4 border-l-amber-500">
              <div className="flex items-center gap-2 text-amber-400 font-medium mb-2">
                <ListChecks size={16} /> You have a follow-up due
              </div>
              <p className="text-sm text-slate-400 mb-3">
                Your {pendingFollowUps[0].checkpoint.replace("_", " ")} check-in is ready. It only
                takes a minute to complete.
              </p>
              <Link to="/trainee/followup" className="inline-flex items-center gap-1.5 bg-brand-600 hover:bg-brand-500 text-white text-sm font-medium px-4 py-2 rounded-lg">
                Complete Follow-up <ArrowRight size={14} />
              </Link>
            </div>
          )}

          {/* Wage progression + follow-up checkpoints — moved here from the
              old Outcome Timeline page, which has been removed. */}
          <TraineeProfileView traineeId={user.linkedId} sections={["wage", "followups"]} traineeView />

          <Link to="/trainee/privacy" className="card p-5 flex items-center gap-3 hover:border-brand-400/40 transition-colors">
            <ShieldCheck size={18} className="text-brand-300" />
            <div>
              <h3 className="font-semibold text-white">Privacy &amp; Consent</h3>
              <p className="text-sm text-slate-500 mt-0.5">Control how your outcome data is used.</p>
            </div>
          </Link>
        </div>
      )}
    </DashboardLayout>
  );
}
