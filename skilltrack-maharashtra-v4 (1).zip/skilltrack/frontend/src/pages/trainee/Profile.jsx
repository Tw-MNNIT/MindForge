import React from "react";
import DashboardLayout from "../../components/layout/DashboardLayout";
import TraineeProfileView from "../../components/trainees/TraineeProfileView";
import { useAuth } from "../../context/AuthContext";

export default function TraineeProfilePage() {
  const { user } = useAuth();
  return (
    <DashboardLayout role="trainee">
      <div className="mb-5">
        <h1 className="text-xl font-semibold text-white">My Profile</h1>
        <p className="text-sm text-slate-500">Your training history, current outcome and verification status.</p>
      </div>
      {user?.linkedId ? (
        <TraineeProfileView traineeId={user.linkedId} sections={["header", "training", "outcome"]} traineeView />
      ) : (
        <p className="text-sm text-slate-500">No linked trainee record for this login.</p>
      )}
    </DashboardLayout>
  );
}
