import React, { useEffect, useState } from "react";
import { ShieldCheck, Lock, ShieldOff } from "lucide-react";
import DashboardLayout from "../../components/layout/DashboardLayout";
import StatusBadge from "../../components/common/StatusBadge";
import { useToast } from "../../components/common/Modal";
import { useAuth } from "../../context/AuthContext";
import api from "../../api/client";

export default function TraineePrivacy() {
  const { user } = useAuth();
  const toast = useToast();
  const [consent, setConsent] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  async function load() {
    if (!user?.linkedId) {
      setLoading(false);
      return;
    }
    const { data } = await api.get(`/trainees/${user.linkedId}`);
    setConsent(data.consent);
    setLoading(false);
  }

  useEffect(() => {
    load();
  }, [user]);

  async function updateConsent(status) {
    setSaving(true);
    try {
      await api.put(`/trainees/${user.linkedId}/consent`, { status });
      toast?.push(`Consent status updated to "${status}".`);
      load();
    } catch (err) {
      toast?.push("Could not update consent.", "error");
    } finally {
      setSaving(false);
    }
  }

  return (
    <DashboardLayout role="trainee">
      <div className="mb-5">
        <h1 className="text-xl font-semibold text-gray-900">Privacy &amp; Consent</h1>
        <p className="text-sm text-gray-500">Control how your training and employment outcome data is used.</p>
      </div>

      {loading ? (
        <div className="text-sm text-gray-400">Loading…</div>
      ) : (
        <div className="grid lg:grid-cols-2 gap-5">
          <div className="card p-5">
            <h3 className="font-semibold text-gray-900 mb-3">Your Consent Status</h3>
            <div className="mb-4">
              <StatusBadge status={consent?.status} />
            </div>
            <div className="flex flex-wrap gap-2">
              <button
                disabled={saving || consent?.status === "Given"}
                onClick={() => updateConsent("Given")}
                className="flex items-center gap-1.5 text-sm font-medium px-3 py-2 rounded-lg bg-emerald-600 text-white hover:bg-emerald-700 disabled:opacity-40"
              >
                <ShieldCheck size={14} /> Give Consent
              </button>
              <button
                disabled={saving || consent?.status === "Revoked"}
                onClick={() => updateConsent("Revoked")}
                className="flex items-center gap-1.5 text-sm font-medium px-3 py-2 rounded-lg border border-red-200 text-red-600 hover:bg-red-50 disabled:opacity-40"
              >
                <ShieldOff size={14} /> Revoke Consent
              </button>
            </div>
            <p className="text-xs text-gray-400 mt-4">
              Revoking consent stops future follow-up collection and employer verification requests
              for your record. It does not delete outcome data already recorded.
            </p>
          </div>

          <div className="card p-5">
            <h3 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
              <Lock size={16} /> What We Collect and Why
            </h3>
            <ul className="text-sm text-gray-600 space-y-2.5 list-disc list-inside">
              <li>Only the training, employment and follow-up data needed to measure outcomes.</li>
              <li>Your employer sees only the specific claim they're asked to verify — not your
                full profile.</li>
              <li>Government analytics only ever show aggregated, non-identifiable numbers.</li>
              <li>Every change made to your record is logged in an audit trail.</li>
            </ul>
          </div>
        </div>
      )}
    </DashboardLayout>
  );
}
