import React, { useState } from "react";
import { Moon, Sun, Save, Loader2 } from "lucide-react";
import DashboardLayout from "../components/layout/DashboardLayout";
import { useAuth } from "../context/AuthContext";
import { useToast } from "../components/common/Modal";

export default function AccountSettings() {
  const { user, updateProfile } = useAuth();
  const toast = useToast();
  const [name, setName] = useState(user?.name || "");
  const [theme, setTheme] = useState(user?.themePreference || "dark");
  const [saving, setSaving] = useState(false);

  async function save() {
    setSaving(true);
    try {
      await updateProfile({ name, themePreference: theme });
      toast?.push("Settings saved");
    } catch (err) {
      toast?.push(err?.response?.data?.message || "Could not save settings", "error");
    } finally {
      setSaving(false);
    }
  }

  return (
    <DashboardLayout role={user?.role}>
      <div className="mb-5">
        <h1 className="text-xl font-semibold text-white">Account Settings</h1>
        <p className="text-sm text-slate-500">Update your display name and appearance preference.</p>
      </div>

      <div className="card p-6 max-w-lg space-y-6">
        <div>
          <label className="text-xs font-medium text-slate-400">Display Name</label>
          <input value={name} onChange={(e) => setName(e.target.value)}
            className="mt-1 w-full border border-white/10 bg-white/5 rounded-lg px-3 py-2.5 text-sm" />
        </div>

        <div>
          <label className="text-xs font-medium text-slate-400 mb-2 block">Theme</label>
          <div className="grid grid-cols-2 gap-3">
            <button onClick={() => setTheme("dark")}
              className={`flex items-center justify-center gap-2 py-3 rounded-lg border text-sm font-medium ${theme === "dark" ? "border-brand-400/50 bg-brand-500/15 text-brand-200" : "border-white/10 text-slate-400"}`}>
              <Moon size={16} /> Dark
            </button>
            <button onClick={() => setTheme("light")}
              className={`flex items-center justify-center gap-2 py-3 rounded-lg border text-sm font-medium ${theme === "light" ? "border-brand-400/50 bg-brand-500/15 text-brand-200" : "border-white/10 text-slate-400"}`}>
              <Sun size={16} /> Light
            </button>
          </div>
        </div>

        <button onClick={save} disabled={saving}
          className="flex items-center gap-2 bg-brand-600 hover:bg-brand-500 text-white font-medium px-4 py-2.5 rounded-lg text-sm">
          {saving ? <Loader2 size={16} className="animate-spin" /> : <Save size={16} />} Save Changes
        </button>
      </div>
    </DashboardLayout>
  );
}
