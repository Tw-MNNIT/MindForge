import React, { useRef, useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { MailCheck, Loader2 } from "lucide-react";
import { useAuth } from "../context/AuthContext";

export default function VerifyOtp() {
  const { state } = useLocation();
  const navigate = useNavigate();
  const { verifyOtp, resendOtp } = useAuth();
  const [otp, setOtp] = useState(Array(6).fill(""));
  const [error, setError] = useState("");
  const [info, setInfo] = useState(state?.devOtp ? `Demo mode: your OTP is ${state.devOtp}` : "");
  const [loading, setLoading] = useState(false);
  const [resending, setResending] = useState(false);
  const refs = useRef([]);

  if (!state?.userId) {
    return (
      <div className="min-h-screen flex items-center justify-center text-center px-4">
        <div>
          <p className="text-slate-400 mb-4">No pending verification found.</p>
          <Link to="/login?role=government" className="text-brand-300 hover:underline">Back to Login</Link>
        </div>
      </div>
    );
  }

  function handleChange(i, val) {
    if (!/^[0-9]?$/.test(val)) return;
    const next = [...otp];
    next[i] = val;
    setOtp(next);
    if (val && i < 5) refs.current[i + 1]?.focus();
  }

  async function submit(e) {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      await verifyOtp(state.userId, otp.join(""));
      navigate("/government/dashboard");
    } catch (err) {
      setError(err?.response?.data?.message || "Verification failed.");
    } finally {
      setLoading(false);
    }
  }

  async function resend() {
    setResending(true);
    setError("");
    try {
      const res = await resendOtp(state.userId);
      setInfo(res.devOtp ? `Demo mode: your OTP is ${res.devOtp}` : "A new OTP has been sent to your email.");
    } catch (err) {
      setError(err?.response?.data?.message || "Could not resend OTP.");
    } finally {
      setResending(false);
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-4">
      <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-md">
        <div className="glass-card rounded-2xl p-8 text-center">
          <div className="w-14 h-14 rounded-full bg-brand-500/15 flex items-center justify-center mx-auto mb-4">
            <MailCheck size={24} className="text-brand-300" />
          </div>
          <h1 className="text-lg font-semibold text-white mb-1">Verify your email</h1>
          <p className="text-sm text-slate-500 mb-6">Enter the 6-digit code sent to <span className="text-slate-300">{state.email}</span></p>

          {info && <div className="mb-4 text-xs text-brand-200 bg-brand-500/10 border border-brand-500/30 rounded-lg px-3 py-2">{info}</div>}
          {error && <div className="mb-4 text-sm text-red-400 bg-red-500/10 border border-red-500/30 rounded-lg px-3 py-2">{error}</div>}

          <form onSubmit={submit}>
            <div className="flex justify-center gap-2 mb-6">
              {otp.map((d, i) => (
                <input key={i} ref={(el) => (refs.current[i] = el)} value={d} maxLength={1} inputMode="numeric"
                  onChange={(e) => handleChange(i, e.target.value)}
                  className="w-11 h-12 text-center text-lg font-semibold bg-white/5 border border-white/10 rounded-lg focus:border-brand-400 outline-none" />
              ))}
            </div>
            <button type="submit" disabled={loading || otp.join("").length !== 6}
              className="w-full bg-brand-600 hover:bg-brand-500 text-white font-medium py-2.5 rounded-lg text-sm flex items-center justify-center gap-2 shadow-glow disabled:opacity-60">
              {loading ? <Loader2 size={16} className="animate-spin" /> : "Verify & Continue"}
            </button>
          </form>
          <button onClick={resend} disabled={resending} className="text-xs text-slate-500 hover:text-brand-300 mt-5">
            {resending ? "Resending…" : "Didn't get the code? Resend OTP"}
          </button>
        </div>
      </motion.div>
    </div>
  );
}
