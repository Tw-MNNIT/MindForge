import React from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import {
  ArrowRight, LineChart, ShieldCheck, TrendingUp, MapPinned, ClipboardCheck, Sparkles,
  Landmark, Building2, UserRound, Briefcase,
} from "lucide-react";

const FEATURES = [
  { icon: LineChart, title: "Longitudinal Tracking", desc: "Follow every trainee from certification through 24 months of employment checkpoints." },
  { icon: ShieldCheck, title: "Verified Employment Outcomes", desc: "Employer confirmation turns self-reported claims into evidence with a confidence level." },
  { icon: TrendingUp, title: "Outcome Analytics", desc: "Employment, retention and wage-progression trends across the entire ecosystem." },
  { icon: Sparkles, title: "Skill-Gap Intelligence", desc: "Compare industry demand against measured trainee proficiency, course by course." },
  { icon: MapPinned, title: "District Insights", desc: "Compare placement, retention and salary outcomes across Maharashtra's districts." },
  { icon: ClipboardCheck, title: "Evidence-Based Monitoring", desc: "Every dashboard number traces back to a verifiable underlying record." },
];

const ROLES = [
  { role: "trainee", label: "Trainee", icon: UserRound, desc: "View your journey & submit follow-ups" },
  { role: "provider", label: "Training Provider", icon: Building2, desc: "Govt-issued ID login" },
  { role: "employer", label: "Employer", icon: Briefcase, desc: "Verify employment outcomes" },
  { role: "government", label: "Administrator", icon: Landmark, desc: "Login or register (OTP)" },
];

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: (i = 0) => ({ opacity: 1, y: 0, transition: { delay: i * 0.1, duration: 0.6, ease: "easeOut" } }),
};

export default function Landing() {
  return (
    <div className="min-h-screen overflow-x-hidden">
      <header className="max-w-6xl mx-auto px-6 py-5 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-9 h-9 rounded-lg bg-brand-600/20 border border-brand-500/40 flex items-center justify-center font-bold text-sm text-brand-300 animate-pulseGlow">ST</div>
          <span className="font-semibold text-white">SkillTrack Maharashtra</span>
        </div>
        <Link to="/login" className="text-sm font-medium text-brand-300 hover:text-brand-200">Sign in</Link>
      </header>

      <section className="max-w-4xl mx-auto text-center px-6 pt-14 pb-10">
        <motion.p initial="hidden" animate="visible" custom={0} variants={fadeUp}
          className="inline-block text-xs font-semibold tracking-wide text-brand-300 bg-brand-500/10 border border-brand-500/30 px-3 py-1 rounded-full mb-5">
          Prototype — not an official Government of Maharashtra system
        </motion.p>
        <motion.h1 initial="hidden" animate="visible" custom={1} variants={fadeUp}
          className="text-4xl md:text-5xl font-bold text-white leading-tight">
          Measure Skills. Track Outcomes. <br className="hidden md:block" />
          <span className="text-gradient">Build Better Futures.</span>
        </motion.h1>
        <motion.p initial="hidden" animate="visible" custom={2} variants={fadeUp}
          className="mt-5 text-lg text-slate-400 max-w-2xl mx-auto">
          An intelligent longitudinal platform for monitoring skilling, employment and workforce
          outcomes across Maharashtra.
        </motion.p>
      </section>

      {/* Role picker */}
      <section className="max-w-4xl mx-auto px-6 pb-16">
        <motion.p initial="hidden" animate="visible" custom={3} variants={fadeUp}
          className="text-center text-sm text-slate-500 mb-5">Continue as</motion.p>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {ROLES.map((r, i) => (
            <motion.div key={r.role} initial="hidden" animate="visible" custom={4 + i} variants={fadeUp}>
              <Link
                to={`/login?role=${r.role}`}
                className="glass-card rounded-2xl p-5 flex flex-col items-center text-center gap-2 hover:border-brand-400/50 hover:-translate-y-1 transition-all duration-300 h-full"
              >
                <div className="w-11 h-11 rounded-xl bg-brand-500/15 flex items-center justify-center">
                  <r.icon size={20} className="text-brand-300" />
                </div>
                <h3 className="font-semibold text-white text-sm">{r.label}</h3>
                <p className="text-xs text-slate-500">{r.desc}</p>
              </Link>
            </motion.div>
          ))}
        </div>
      </section>

      <section className="max-w-6xl mx-auto px-6 py-14">
        <h2 className="text-2xl font-semibold text-white text-center mb-2">Why SkillTrack?</h2>
        <p className="text-slate-500 text-center mb-10">Traditional measurement stops at certification. This doesn't.</p>
        <div className="grid md:grid-cols-3 gap-5">
          {FEATURES.map((f, i) => (
            <motion.div key={f.title} initial="hidden" whileInView="visible" viewport={{ once: true }} custom={i} variants={fadeUp}
              className="glass-card p-5 rounded-xl hover:border-brand-400/40 transition-colors">
              <div className="w-10 h-10 rounded-lg bg-brand-500/15 text-brand-300 flex items-center justify-center mb-3">
                <f.icon size={20} />
              </div>
              <h3 className="font-semibold text-white mb-1">{f.title}</h3>
              <p className="text-sm text-slate-500">{f.desc}</p>
            </motion.div>
          ))}
        </div>
      </section>

      <footer className="border-t border-white/5 py-8 text-center text-sm text-slate-600">
        SkillTrack Maharashtra is a hackathon prototype demonstrating a longitudinal outcomes platform.
        It is not affiliated with, and does not represent, an official Government of Maharashtra system.
      </footer>
    </div>
  );
}
