import React, { useState } from "react";
import { useNavigate, useSearchParams, Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Landmark, Building2, UserRound, Briefcase, Loader2, CreditCard, Lock, Mail, User as UserIcon } from "lucide-react";
import { useAuth } from "../context/AuthContext";

const ROLE_META = {
  trainee: { label: "Trainee", icon: UserRound, idLabel: "Trainee Unique ID", hint: "Your ID was issued when you enrolled (e.g. MH-TR-100001)." },
  employer: { label: "Employer", icon: Briefcase, idLabel: "Employer Unique ID", hint: "Your ID was issued when your organisation was onboarded (e.g. MH-EM-000001)." },
  provider: { label: "Training Provider", icon: Building2, idLabel: "Provider Unique ID", hint: "Issued by the Government of Maharashtra when your organisation was empanelled (e.g. MH-PR-000001)." },
  government: { label: "Government Administrator", icon: Landmark },
};

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const initialRole = params.get("role") && ROLE_META[params.get("role")] ? params.get("role") : "trainee";
  const [role, setRole] = useState(initialRole);
  const [govMode, setGovMode] = useState("login"); // login | register

  const meta = ROLE_META[role];

  return (
    <div className="min-h-screen flex items-center justify-center px-4 py-10">
      <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }} className="w-full max-w-md">
        <Link to="/" className="flex items-center justify-center gap-2 mb-6">
          <div className="w-9 h-9 rounded-lg bg-brand-600/20 border border-brand-500/40 flex items-center justify-center font-bold text-sm text-brand-300">ST</div>
          <span className="font-semibold text-white">SkillTrack Maharashtra</span>
        </Link>

        {/* Role switcher */}
        <div className="grid grid-cols-4 gap-2 mb-5">
          {Object.entries(ROLE_META).map(([key, m]) => (
            <button
              key={key}
              onClick={() => setRole(key)}
              className={`flex flex-col items-center gap-1 py-2.5 rounded-lg text-[11px] font-medium border transition-colors ${
                role === key ? "bg-brand-500/15 border-brand-400/50 text-brand-200" : "border-white/10 text-slate-500 hover:text-slate-300"
              }`}
            >
              <m.icon size={16} />
              {m.label.split(" ")[0]}
            </button>
          ))}
        </div>

        <div className="glass-card rounded-2xl p-6">
          {role === "government" ? (
            <GovernmentAuth mode={govMode} setMode={setGovMode} />
          ) : (
            <IdLogin role={role} meta={meta} login={login} navigate={navigate} />
          )}
        </div>
      </motion.div>
    </div>
  );
}

function IdLogin({ role, meta, login, navigate }) {
  const [uniqueId, setUniqueId] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const user = await login(uniqueId.trim().toUpperCase(), password);
      navigate(`/${user.role}/dashboard`);
    } catch (err) {
      setError(err?.response?.data?.message || "Login failed.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      <div className="text-center mb-5">
        <div className="w-11 h-11 rounded-xl bg-brand-500/15 flex items-center justify-center mx-auto mb-2">
          <meta.icon size={20} className="text-brand-300" />
        </div>
        <h1 className="text-lg font-semibold text-white">{meta.label} Sign In</h1>
        {meta.hint && <p className="text-xs text-slate-500 mt-1">{meta.hint}</p>}
      </div>
      <form onSubmit={submit} className="space-y-3">
        <div>
          <label className="text-xs font-medium text-slate-400">{meta.idLabel}</label>
          <div className="mt-1 flex items-center gap-2 bg-white/5 border border-white/10 rounded-lg px-3 py-2.5 focus-within:border-brand-400">
            <CreditCard size={16} className="text-slate-500" />
            <input value={uniqueId} onChange={(e) => setUniqueId(e.target.value)} placeholder={`e.g. ${role === "trainee" ? "MH-TR-100001" : role === "provider" ? "MH-PR-000001" : "MH-EM-000001"}`}
              className="bg-transparent outline-none w-full text-sm placeholder:text-slate-600" />
          </div>
        </div>
        <div>
          <label className="text-xs font-medium text-slate-400">Password</label>
          <div className="mt-1 flex items-center gap-2 bg-white/5 border border-white/10 rounded-lg px-3 py-2.5 focus-within:border-brand-400">
            <Lock size={16} className="text-slate-500" />
            <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••"
              className="bg-transparent outline-none w-full text-sm placeholder:text-slate-600" />
          </div>
        </div>
        {error && <p className="text-sm text-red-400">{error}</p>}
        <button type="submit" disabled={loading}
          className="w-full bg-brand-600 hover:bg-brand-500 text-white font-medium py-2.5 rounded-lg text-sm flex items-center justify-center gap-2 shadow-glow">
          {loading && <Loader2 size={16} className="animate-spin" />} Sign In
        </button>
      </form>
      <p className="text-xs text-slate-600 text-center pt-4">Demo password: <code className="bg-white/5 px-1 rounded">demo1234</code></p>
    </>
  );
}

function GovernmentAuth({ mode, setMode }) {
  return (
    <>
      <div className="flex gap-2 mb-5">
        <button onClick={() => setMode("login")} className={`flex-1 text-sm py-2 rounded-lg font-medium ${mode === "login" ? "bg-brand-500/20 text-brand-200" : "text-slate-500"}`}>Login</button>
        <button onClick={() => setMode("register")} className={`flex-1 text-sm py-2 rounded-lg font-medium ${mode === "register" ? "bg-brand-500/20 text-brand-200" : "text-slate-500"}`}>Register</button>
      </div>
      {mode === "login" ? <GovLogin /> : <GovRegister />}
    </>
  );
}

function GovLogin() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const user = await login(email, password);
      navigate("/government/dashboard");
    } catch (err) {
      if (err?.response?.data?.needsVerification) {
        navigate("/verify-otp", { state: { userId: err.response.data.userId, email } });
        return;
      }
      setError(err?.response?.data?.message || "Login failed.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <form onSubmit={submit} className="space-y-3">
      <div>
        <label className="text-xs font-medium text-slate-400">Email</label>
        <div className="mt-1 flex items-center gap-2 bg-white/5 border border-white/10 rounded-lg px-3 py-2.5 focus-within:border-brand-400">
          <Mail size={16} className="text-slate-500" />
          <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com"
            className="bg-transparent outline-none w-full text-sm placeholder:text-slate-600" />
        </div>
      </div>
      <div>
        <label className="text-xs font-medium text-slate-400">Password</label>
        <div className="mt-1 flex items-center gap-2 bg-white/5 border border-white/10 rounded-lg px-3 py-2.5 focus-within:border-brand-400">
          <Lock size={16} className="text-slate-500" />
          <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••"
            className="bg-transparent outline-none w-full text-sm placeholder:text-slate-600" />
        </div>
      </div>
      {error && <p className="text-sm text-red-400">{error}</p>}
      <button type="submit" disabled={loading} className="w-full bg-brand-600 hover:bg-brand-500 text-white font-medium py-2.5 rounded-lg text-sm flex items-center justify-center gap-2 shadow-glow">
        {loading && <Loader2 size={16} className="animate-spin" />} Sign In
      </button>
      <p className="text-xs text-slate-600 text-center pt-2">Demo: admin@skilltrack-demo.example / demo1234</p>
    </form>
  );
}

function GovRegister() {
  const { registerGovernment } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: "", email: "", password: "" });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const res = await registerGovernment(form);
      navigate("/verify-otp", { state: { userId: res.userId, email: form.email, devOtp: res.devOtp } });
    } catch (err) {
      setError(err?.response?.data?.message || "Registration failed.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <form onSubmit={submit} className="space-y-3">
      <div>
        <label className="text-xs font-medium text-slate-400">Full Name</label>
        <div className="mt-1 flex items-center gap-2 bg-white/5 border border-white/10 rounded-lg px-3 py-2.5 focus-within:border-brand-400">
          <UserIcon size={16} className="text-slate-500" />
          <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Full name"
            className="bg-transparent outline-none w-full text-sm placeholder:text-slate-600" />
        </div>
      </div>
      <div>
        <label className="text-xs font-medium text-slate-400">Email</label>
        <div className="mt-1 flex items-center gap-2 bg-white/5 border border-white/10 rounded-lg px-3 py-2.5 focus-within:border-brand-400">
          <Mail size={16} className="text-slate-500" />
          <input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="you@example.com"
            className="bg-transparent outline-none w-full text-sm placeholder:text-slate-600" />
        </div>
      </div>
      <div>
        <label className="text-xs font-medium text-slate-400">Password</label>
        <div className="mt-1 flex items-center gap-2 bg-white/5 border border-white/10 rounded-lg px-3 py-2.5 focus-within:border-brand-400">
          <Lock size={16} className="text-slate-500" />
          <input type="password" minLength={6} value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} placeholder="At least 6 characters"
            className="bg-transparent outline-none w-full text-sm placeholder:text-slate-600" />
        </div>
      </div>
      {error && <p className="text-sm text-red-400">{error}</p>}
      <button type="submit" disabled={loading} className="w-full bg-brand-600 hover:bg-brand-500 text-white font-medium py-2.5 rounded-lg text-sm flex items-center justify-center gap-2 shadow-glow">
        {loading && <Loader2 size={16} className="animate-spin" />} Register & Send OTP
      </button>
    </form>
  );
}
