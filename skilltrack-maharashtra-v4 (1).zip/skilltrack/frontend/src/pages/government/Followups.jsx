import React, { useEffect, useState } from "react";
import { Bell, Eye } from "lucide-react";
import DashboardLayout from "../../components/layout/DashboardLayout";
import DataTable from "../../components/common/DataTable";
import StatusBadge from "../../components/common/StatusBadge";
import KpiCard from "../../components/common/KpiCard";
import { Modal, useToast } from "../../components/common/Modal";
import api from "../../api/client";

function fmtDate(d) {
  if (!d) return "—";
  return new Date(d).toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" });
}

export default function GovFollowups() {
  const [rows, setRows] = useState([]);
  const [summary, setSummary] = useState(null);
  const [loading, setLoading] = useState(true);
  const [viewing, setViewing] = useState(null);
  const toast = useToast();

  async function load() {
    setLoading(true);
    const [listRes, summaryRes] = await Promise.all([
      api.get("/followups", { params: { limit: 200 } }),
      api.get("/followups/summary"),
    ]);
    setRows(
      listRes.data.items.map((f) => ({
        id: f._id,
        trainee: f.traineeId?.name,
        traineeCode: f.traineeId?.traineeCode,
        checkpoint: f.checkpoint.replace("_", " "),
        dueDate: fmtDate(f.dueDate),
        status: f.status,
        raw: f,
      }))
    );
    setSummary(summaryRes.data);
    setLoading(false);
  }

  useEffect(() => {
    load();
  }, []);

  async function sendReminder(id) {
    await api.put(`/followups/${id}/remind`);
    toast?.push("Reminder sent to trainee.");
    load();
  }

  const columns = [
    { key: "traineeCode", label: "Trainee ID" },
    { key: "trainee", label: "Trainee" },
    { key: "checkpoint", label: "Follow-up" },
    { key: "dueDate", label: "Due Date" },
    { key: "status", label: "Status", render: (r) => <StatusBadge status={r.status} /> },
    {
      key: "actions",
      label: "Action",
      render: (r) => (
        <div className="flex items-center gap-3">
          {r.status !== "Completed" && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                sendReminder(r.id);
              }}
              className="text-brand-600 hover:text-brand-800 text-xs font-medium flex items-center gap-1"
            >
              <Bell size={13} /> Send Reminder
            </button>
          )}
          {r.status === "Completed" && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                setViewing(r.raw);
              }}
              className="text-gray-500 hover:text-gray-800 text-xs font-medium flex items-center gap-1"
            >
              <Eye size={13} /> View Response
            </button>
          )}
        </div>
      ),
    },
  ];

  return (
    <DashboardLayout role="government">
      <div className="mb-5">
        <h1 className="text-xl font-semibold text-gray-900">Follow-up Management</h1>
        <p className="text-sm text-gray-500">
          3 / 6 / 12 / 18 / 24-month checkpoints across the entire trainee cohort.
        </p>
      </div>

      {summary && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <KpiCard label="Completed" value={summary.Completed} accent="green" />
          <KpiCard label="Pending" value={summary.Pending} accent="amber" />
          <KpiCard label="Overdue" value={summary.Overdue} accent="red" />
          <KpiCard label="Not Reachable" value={summary["Not Reachable"]} accent="brand" />
        </div>
      )}

      {loading ? (
        <div className="text-sm text-gray-400">Loading follow-ups…</div>
      ) : (
        <DataTable columns={columns} rows={rows} pageSize={12} />
      )}

      <Modal open={!!viewing} onClose={() => setViewing(null)} title="Follow-up Response">
        {viewing && (
          <dl className="text-sm space-y-2">
            <div className="flex justify-between"><dt className="text-gray-500">Trainee</dt><dd className="font-medium">{viewing.traineeId?.name}</dd></div>
            <div className="flex justify-between"><dt className="text-gray-500">Checkpoint</dt><dd className="font-medium">{viewing.checkpoint.replace("_", " ")}</dd></div>
            <div className="flex justify-between"><dt className="text-gray-500">Reported Status</dt><dd className="font-medium">{viewing.response?.currentStatus || "—"}</dd></div>
            <div className="flex justify-between"><dt className="text-gray-500">Completed On</dt><dd className="font-medium">{fmtDate(viewing.completedAt)}</dd></div>
            {viewing.response?.notes && (
              <div>
                <dt className="text-gray-500 mb-1">Notes</dt>
                <dd className="font-medium bg-gray-50 rounded-lg p-2">{viewing.response.notes}</dd>
              </div>
            )}
          </dl>
        )}
      </Modal>
    </DashboardLayout>
  );
}
