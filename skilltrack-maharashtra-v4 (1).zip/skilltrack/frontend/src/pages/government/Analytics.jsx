import React, { useEffect, useState } from "react";
import DashboardLayout from "../../components/layout/DashboardLayout";
import DataTable from "../../components/common/DataTable";
import { SimpleBarChart, SimpleDonutChart } from "../../components/charts/Charts";
import api from "../../api/client";

const TABS = ["Districts", "Providers", "Courses", "Demographics", "Non-Placement Reasons"];

function PerformanceDot({ value, high = 70, mid = 50 }) {
  const color = value >= high ? "bg-emerald-500" : value >= mid ? "bg-amber-500" : "bg-red-500";
  return <span className={`inline-block w-2 h-2 rounded-full mr-2 ${color}`} />;
}

export default function GovAnalytics() {
  const [tab, setTab] = useState("Districts");
  const [districts, setDistricts] = useState([]);
  const [providers, setProviders] = useState([]);
  const [courses, setCourses] = useState([]);
  const [demographics, setDemographics] = useState(null);
  const [nonPlacement, setNonPlacement] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      const [d, p, c, demo, np] = await Promise.all([
        api.get("/analytics/districts"),
        api.get("/analytics/providers"),
        api.get("/analytics/courses"),
        api.get("/analytics/demographics"),
        api.get("/analytics/non-placement-reasons"),
      ]);
      setDistricts(d.data);
      setProviders(p.data);
      setCourses(c.data);
      setDemographics(demo.data);
      setNonPlacement(np.data);
      setLoading(false);
    }
    load();
  }, []);

  const districtColumns = [
    { key: "district", label: "District" },
    { key: "trainees", label: "Trainees" },
    { key: "completed", label: "Completed" },
    { key: "placementRate", label: "Placement", render: (r) => <span><PerformanceDot value={r.placementRate} />{r.placementRate}%</span> },
    { key: "retentionRate", label: "Retention", render: (r) => <span><PerformanceDot value={r.retentionRate} />{r.retentionRate}%</span> },
    { key: "avgSalary", label: "Avg Salary", render: (r) => `₹${r.avgSalary.toLocaleString("en-IN")}` },
  ];

  const providerColumns = [
    { key: "provider", label: "Provider" },
    { key: "district", label: "District" },
    { key: "trainees", label: "Trainees" },
    { key: "completionRate", label: "Completion", render: (r) => `${r.completionRate}%` },
    { key: "placementRate", label: "Placement", render: (r) => <span><PerformanceDot value={r.placementRate} />{r.placementRate}%</span> },
    { key: "verificationRate", label: "Employer Verified", render: (r) => `${r.verificationRate}%` },
    { key: "followUpResponseRate", label: "Follow-up Response", render: (r) => `${r.followUpResponseRate}%` },
    { key: "avgSalary", label: "Avg Salary", render: (r) => `₹${r.avgSalary.toLocaleString("en-IN")}` },
  ];

  const courseColumns = [
    { key: "course", label: "Course" },
    { key: "provider", label: "Provider" },
    { key: "enrollment", label: "Enrollment" },
    { key: "completion", label: "Completion" },
    { key: "dropout", label: "Dropout" },
    { key: "placementRate", label: "Placement", render: (r) => <span><PerformanceDot value={r.placementRate} />{r.placementRate}%</span> },
    { key: "retentionRate", label: "Retention", render: (r) => `${r.retentionRate}%` },
    { key: "avgSalary", label: "Avg Salary", render: (r) => `₹${r.avgSalary.toLocaleString("en-IN")}` },
  ];

  return (
    <DashboardLayout role="government">
      <div className="mb-5">
        <h1 className="text-xl font-semibold text-gray-900">Analytics</h1>
        <p className="text-sm text-gray-500">
          Compare outcomes across districts, providers, courses and demographic groups. Figures are
          associations/observed outcomes, not claims of causation.
        </p>
      </div>

      <div className="flex flex-wrap gap-2 mb-5">
        {TABS.map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`px-3.5 py-1.5 rounded-lg text-sm font-medium ${
              tab === t ? "bg-brand-600 text-white" : "bg-white border border-gray-200 text-gray-600 hover:border-gray-300"
            }`}
          >
            {t}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="text-sm text-gray-400">Loading analytics…</div>
      ) : (
        <>
          {tab === "Districts" && <DataTable columns={districtColumns} rows={districts.map((d) => ({ id: d.districtId, ...d }))} pageSize={10} />}
          {tab === "Providers" && <DataTable columns={providerColumns} rows={providers.map((p) => ({ id: p.providerId, ...p }))} pageSize={10} />}
          {tab === "Courses" && <DataTable columns={courseColumns} rows={courses.map((c) => ({ id: c.programId, ...c }))} pageSize={10} />}

          {tab === "Demographics" && demographics && (
            <div className="grid lg:grid-cols-2 gap-5">
              <div className="card p-5">
                <h3 className="font-semibold text-gray-900 mb-4">Employment Rate by Age</h3>
                <SimpleBarChart
                  data={demographics.ageBandStats.map((a) => ({ band: a.band, rate: a.employmentRate }))}
                  xKey="band"
                  bars={[{ key: "rate", label: "Employment Rate %", color: "#3b71f3" }]}
                />
              </div>
              <div className="card p-5">
                <h3 className="font-semibold text-gray-900 mb-4">Trainees by Gender</h3>
                <SimpleDonutChart data={demographics.byGender.map((g) => ({ name: g._id || "Unspecified", value: g.count }))} />
              </div>
              <div className="card p-5">
                <h3 className="font-semibold text-gray-900 mb-4">Trainees by Education Level</h3>
                <SimpleBarChart
                  data={demographics.byEducation.map((e) => ({ level: e._id || "Unspecified", count: e.count }))}
                  xKey="level"
                  bars={[{ key: "count", label: "Trainees", color: "#8b5cf6" }]}
                  layout="vertical"
                />
              </div>
              <div className="card p-5">
                <h3 className="font-semibold text-gray-900 mb-4">Urban vs Rural</h3>
                <SimpleDonutChart data={demographics.byUrbanRural.map((u) => ({ name: u._id || "Unspecified", value: u.count }))} />
              </div>
            </div>
          )}

          {tab === "Non-Placement Reasons" && (
            <div className="card p-5">
              <h3 className="font-semibold text-gray-900 mb-4">Why Are Outcomes Poor?</h3>
              {nonPlacement.length ? (
                <SimpleBarChart
                  data={nonPlacement.map((r) => ({ reason: r.reason, count: r.count }))}
                  xKey="reason"
                  bars={[{ key: "count", label: "Trainees", color: "#ef4444" }]}
                  layout="vertical"
                  height={340}
                />
              ) : (
                <p className="text-sm text-gray-400">No unemployment records yet.</p>
              )}
            </div>
          )}
        </>
      )}
    </DashboardLayout>
  );
}
