import React, { useEffect, useState } from "react";
import { ShieldCheck, Lock, Users2, ScrollText } from "lucide-react";
import DashboardLayout from "../../components/layout/DashboardLayout";
import KpiCard from "../../components/common/KpiCard";
import api from "../../api/client";

function timeAgo(date) {
  const diffMs = Date.now() - new Date(date).getTime();
  const mins = Math.round(diffMs / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins} minute${mins === 1 ? "" : "s"} ago`;
  const hrs = Math.round(mins / 60);
  if (hrs < 24) return `${hrs} hour${hrs === 1 ? "" : "s"} ago`;
  const days = Math.round(hrs / 24);
  return `${days} day${days === 1 ? "" : "s"} ago`;
}

export default function GovSettings() {
  const [consent, setConsent] = useState(null);
  const [logs, setLogs] = useState([]);

  useEffect(() => {
    async function load() {
      const [consentRes, logsRes] = await Promise.all([
        api.get("/analytics/consent-summary"),
        api.get("/audit-logs", { params: { limit: 30 } }),
      ]);
      setConsent(consentRes.data);
      setLogs(logsRes.data);
    }
    load();
  }, []);

  return (
    <DashboardLayout role="government">
      <div className="mb-5">
        <h1 className="text-xl font-semibold text-gray-900">Privacy, Consent &amp; Audit</h1>
        <p className="text-sm text-gray-500">
          How trainee data is collected, who can see it, and every action taken on it.
        </p>
      </div>

      {consent && (
        <div className="grid grid-cols-3 gap-4 mb-6">
          <KpiCard label="Consent Given" value={consent.Given} icon={ShieldCheck} accent="green" />
          <KpiCard label="Consent Pending" value={consent.Pending} icon={Lock} accent="amber" />
          <KpiCard label="Consent Revoked" value={consent.Revoked} icon={Users2} accent="red" />
        </div>
      )}

      <div className="grid lg:grid-cols-2 gap-5">
        <div className="card p-5">
          <h3 className="font-semibold text-gray-900 mb-3">How Trainee Data Is Handled</h3>
          <ul className="text-sm text-gray-600 space-y-2.5 list-disc list-inside">
            <li>Follow-up and verification data is collected only where the trainee has given consent.</li>
            <li>Each role sees only the minimum data necessary for its function — employers see only
              the employment claim they're asked to verify, not a trainee's full profile.</li>
            <li>Dashboards and reports are built from role-based access — trainee-identifiable data is
              not exposed on aggregate government analytics screens.</li>
            <li>Every material change to a trainee's record is written to an immutable audit log.</li>
            <li>This is a hackathon prototype: no formal security or compliance certification is
              claimed for this build.</li>
          </ul>
        </div>

        <div className="card p-5">
          <h3 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
            <ScrollText size={16} /> Recent Audit Trail
          </h3>
          <ul className="text-sm space-y-3 max-h-96 overflow-y-auto">
            {logs.map((l) => (
              <li key={l._id} className="border-b border-gray-50 pb-2 last:border-0">
                <p className="text-gray-800">
                  <span className="font-medium">{l.actorLabel || l.actorRole}</span> {l.action.toLowerCase().startsWith(l.actorLabel?.toLowerCase()) ? "" : ""}
                  {" "}
                  {l.action}
                </p>
                <p className="text-xs text-gray-400">{timeAgo(l.createdAt)}</p>
              </li>
            ))}
            {logs.length === 0 && <p className="text-sm text-gray-400">No audit events yet.</p>}
          </ul>
        </div>
      </div>
    </DashboardLayout>
  );
}
