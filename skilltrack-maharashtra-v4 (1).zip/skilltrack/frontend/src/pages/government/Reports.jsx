import React, { useEffect, useState } from "react";
import { FileText, Download, Printer, Eye } from "lucide-react";
import DashboardLayout from "../../components/layout/DashboardLayout";
import { Modal } from "../../components/common/Modal";
import api from "../../api/client";

export default function GovReports() {
  const [reports, setReports] = useState([]);
  const [previewing, setPreviewing] = useState(null);
  const [previewData, setPreviewData] = useState(null);

  useEffect(() => {
    api.get("/reports").then((res) => setReports(res.data));
  }, []);

  async function viewReport(report) {
    setPreviewing(report);
    const { data } = await api.get(`/reports/${report.id}`);
    setPreviewData(data);
  }

  async function exportCSV(report) {
    const res = await api.get(`/reports/${report.id}/export.csv`, { responseType: "blob" });
    const url = window.URL.createObjectURL(new Blob([res.data]));
    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download", `${report.id}.csv`);
    document.body.appendChild(link);
    link.click();
    link.remove();
  }

  function exportPDF(report, data) {
    const win = window.open("", "_blank");
    win.document.write(`
      <html><head><title>${report.name}</title>
      <style>body{font-family:sans-serif;padding:32px;color:#111} h1{font-size:20px} pre{white-space:pre-wrap;background:#f8fafc;padding:16px;border-radius:8px;font-size:12px}</style>
      </head><body>
      <h1>${report.name}</h1>
      <p style="color:#666;font-size:13px">${report.description}</p>
      <p style="color:#999;font-size:11px">Demo Data — Fictional Prototype Dataset. Generated ${new Date().toLocaleString("en-IN")}</p>
      <pre>${JSON.stringify(data, null, 2)}</pre>
      </body></html>
    `);
    win.document.close();
    win.focus();
    win.print();
  }

  return (
    <DashboardLayout role="government">
      <div className="mb-5">
        <h1 className="text-xl font-semibold text-gray-900">Reports</h1>
        <p className="text-sm text-gray-500">Evidence-based reports derived from live platform data.</p>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        {reports.map((r) => (
          <div key={r.id} className="card p-5 flex flex-col gap-3">
            <div className="flex items-start gap-3">
              <div className="p-2 rounded-lg bg-brand-50 text-brand-700 shrink-0">
                <FileText size={18} />
              </div>
              <div>
                <h3 className="font-semibold text-gray-900">{r.name}</h3>
                <p className="text-sm text-gray-500 mt-0.5">{r.description}</p>
              </div>
            </div>
            <div className="flex gap-2 mt-auto pt-2">
              <button
                onClick={() => viewReport(r)}
                className="flex items-center gap-1.5 text-sm font-medium px-3 py-1.5 rounded-lg border border-gray-200 hover:border-gray-300"
              >
                <Eye size={14} /> View Report
              </button>
              <button
                onClick={() => exportCSV(r)}
                className="flex items-center gap-1.5 text-sm font-medium px-3 py-1.5 rounded-lg border border-gray-200 hover:border-gray-300"
              >
                <Download size={14} /> Export CSV
              </button>
            </div>
          </div>
        ))}
      </div>

      <Modal
        open={!!previewing}
        onClose={() => {
          setPreviewing(null);
          setPreviewData(null);
        }}
        title={previewing?.name}
        footer={
          <>
            <button
              onClick={() => exportPDF(previewing, previewData)}
              className="flex items-center gap-1.5 text-sm font-medium px-3 py-1.5 rounded-lg border border-gray-200 hover:border-gray-300"
            >
              <Printer size={14} /> Export PDF
            </button>
            <button
              onClick={() => exportCSV(previewing)}
              className="flex items-center gap-1.5 text-sm font-medium px-3 py-1.5 rounded-lg bg-brand-600 text-white hover:bg-brand-700"
            >
              <Download size={14} /> Export CSV
            </button>
          </>
        }
      >
        {previewData ? (
          <pre className="text-xs bg-gray-50 rounded-lg p-3 max-h-96 overflow-auto">
            {JSON.stringify(previewData, null, 2)}
          </pre>
        ) : (
          <p className="text-sm text-gray-400">Loading report data…</p>
        )}
      </Modal>
    </DashboardLayout>
  );
}
