import React from "react";
import { useParams, useNavigate } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import DashboardLayout from "../../components/layout/DashboardLayout";
import TraineeProfileView from "../../components/trainees/TraineeProfileView";

export default function GovTraineeProfile() {
  const { id } = useParams();
  const navigate = useNavigate();

  return (
    <DashboardLayout role="government">
      <button
        onClick={() => navigate(-1)}
        className="flex items-center gap-1 text-sm text-gray-500 hover:text-gray-800 mb-4"
      >
        <ArrowLeft size={16} /> Back to Trainees
      </button>
      <TraineeProfileView traineeId={id} />
    </DashboardLayout>
  );
}
