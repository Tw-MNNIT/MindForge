import React, { useEffect, useMemo, useState } from "react";
import {
  Users, GraduationCap, Briefcase, ShieldCheck, TrendingUp, Wallet, ClipboardCheck, Store,
} from "lucide-react";
import DashboardLayout from "../../components/layout/DashboardLayout";
import KpiCard from "../../components/common/KpiCard";
import { SimpleLineChart, SimpleDonutChart } from "../../components/charts/Charts";
import api from "../../api/client";

const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
const OUTCOME_LABELS = {
  employed: "Employed",
  self_employed: "Self-Employed",
  apprenticeship: "Apprenticeship",
  unemployed: "Unemployed",
  further_education: "Further Education",
};

export default function GovDashboard() {
  const [overview, setOverview] = useState(null);
  const [trendRaw, setTrendRaw] = useState([]);
  const [distribution, setDistribution] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      const [ov, trend, dist] = await Promise.all([
        api.get("/analytics/overview"),
        api.get("/analytics/trend"),
        api.get("/analytics/distribution"),
      ]);
      setOverview(ov.data);
      setTrendRaw(trend.data);
      setDistribution(dist.data);
      setLoading(false);
    }
    load();
  }, []);

  const trendData = useMemo(() => {
    const byMonth = {};
    trendRaw.forEach((row) => {
      const key = `${MONTHS[row._id.month - 1]} ${row._id.year}`;
      if (!byMonth[key]) byMonth[key] = { month: key };
      byMonth[key][row._id.type] = row.count;
    });
    return Object.values(byMonth);
  }, [trendRaw]);

  const donutData = useMemo(
    () => distribution.map((d) => ({ name: OUTCOME_LABELS[d._id] || d._id, value: d.count })),
    [distribution]
  );

  if (loading || !overview) {
    return (
      <DashboardLayout role="government">
        <div className="text-gray-400 text-sm">Loading dashboard…</div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout role="government">
      <div className="mb-6">
        <h1 className="text-2xl font-semibold text-gray-900">Good Morning, Administrator</h1>
        <p className="text-gray-500 text-sm mt-1">
          Here&apos;s an overview of skilling outcomes across Maharashtra.
        </p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <KpiCard label="Total Trainees" value={overview.totalTrainees.toLocaleString("en-IN")} icon={Users} />
        <KpiCard label="Training Completed" value={overview.trainingCompleted.toLocaleString("en-IN")} icon={GraduationCap} accent="green" />
        <KpiCard label="Employment Rate" value={`${overview.employmentRate}%`} icon={Briefcase} accent="brand" />
        <KpiCard label="Verified Placements" value={overview.verifiedPlacements.toLocaleString("en-IN")} icon={ShieldCheck} accent="green" />
        <KpiCard label="Employment Retention (12m)" value={`${overview.employmentRetention}%`} icon={TrendingUp} accent="brand" />
        <KpiCard label="Average Salary" value={`₹${overview.averageSalary.toLocaleString("en-IN")}/mo`} icon={Wallet} accent="amber" />
        <KpiCard label="Follow-up Response Rate" value={`${overview.followUpResponseRate}%`} icon={ClipboardCheck} accent="brand" />
        <KpiCard label="Self Employment" value={overview.selfEmployment.toLocaleString("en-IN")} icon={Store} accent="green" />
      </div>

      <div className="grid lg:grid-cols-3 gap-4">
        <div className="card p-5 lg:col-span-2">
          <h3 className="font-semibold text-gray-900 mb-4">Employment Outcome Trend</h3>
          {trendData.length ? (
            <SimpleLineChart
              data={trendData}
              xKey="month"
              lines={[
                { key: "employed", label: "Employed" },
                { key: "self_employed", label: "Self-Employed" },
                { key: "apprenticeship", label: "Apprenticeship" },
                { key: "unemployed", label: "Unemployed" },
              ]}
            />
          ) : (
            <p className="text-sm text-gray-400">No outcome records yet in this window.</p>
          )}
        </div>
        <div className="card p-5">
          <h3 className="font-semibold text-gray-900 mb-4">Employment Status Distribution</h3>
          {donutData.length ? <SimpleDonutChart data={donutData} /> : <p className="text-sm text-gray-400">No data yet.</p>}
        </div>
      </div>

      <p className="text-xs text-gray-400 mt-6">
        Demo Data — Fictional Prototype Dataset. Figures illustrate how the platform would present
        real, consented, verified outcome data.
      </p>
    </DashboardLayout>
  );
}
