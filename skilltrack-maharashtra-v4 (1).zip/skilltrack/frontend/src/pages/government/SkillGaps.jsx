import React, { useEffect, useMemo, useState } from "react";
import DashboardLayout from "../../components/layout/DashboardLayout";
import { SimpleBarChart } from "../../components/charts/Charts";
import DataTable from "../../components/common/DataTable";
import api from "../../api/client";

export default function GovSkillGaps() {
  const [topGaps, setTopGaps] = useState([]);
  const [gaps, setGaps] = useState([]);
  const [courseFilter, setCourseFilter] = useState("all");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      const [topRes, gapsRes] = await Promise.all([
        api.get("/analytics/skill-gaps/top", { params: { limit: 5 } }),
        api.get("/analytics/skill-gaps"),
      ]);
      setTopGaps(topRes.data);
      setGaps(
        gapsRes.data.map((g) => ({
          id: g._id,
          course: g.programId?.name,
          skill: g.skill,
          industryDemand: g.industryDemand,
          currentLevel: g.currentLevel,
          gap: g.gap,
          sampleSize: g.sampleSize,
        }))
      );
      setLoading(false);
    }
    load();
  }, []);

  const courses = useMemo(() => ["all", ...new Set(gaps.map((g) => g.course).filter(Boolean))], [gaps]);
  const filteredGaps = courseFilter === "all" ? gaps : gaps.filter((g) => g.course === courseFilter);

  const columns = [
    { key: "course", label: "Course" },
    { key: "skill", label: "Skill" },
    { key: "industryDemand", label: "Industry Demand", render: (r) => `${r.industryDemand}%` },
    { key: "currentLevel", label: "Current Level", render: (r) => `${r.currentLevel}%` },
    {
      key: "gap",
      label: "Gap",
      render: (r) => (
        <span className={`font-medium ${r.gap >= 25 ? "text-red-600" : r.gap >= 12 ? "text-amber-600" : "text-emerald-600"}`}>
          {r.gap}%
        </span>
      ),
    },
    { key: "sampleSize", label: "Sample Size" },
  ];

  return (
    <DashboardLayout role="government">
      <div className="mb-5">
        <h1 className="text-xl font-semibold text-gray-900">Skill Gap Analytics</h1>
        <p className="text-sm text-gray-500">
          Industry demand vs measured trainee skill level — identification only, no automated
          remedial actions.
        </p>
      </div>

      <div className="card p-5 mb-6">
        <h3 className="font-semibold text-gray-900 mb-4">Top Skill Gaps (State-wide)</h3>
        {loading ? (
          <div className="text-sm text-gray-400">Loading…</div>
        ) : (
          <SimpleBarChart
            data={topGaps.map((g) => ({ skill: g.skill, gap: g.avgGapPct }))}
            xKey="skill"
            bars={[{ key: "gap", label: "Avg Gap %", color: "#ef4444" }]}
            layout="vertical"
            height={260}
          />
        )}
      </div>

      <div className="card p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold text-gray-900">Industry Demand vs Current Skill Level</h3>
          <select
            value={courseFilter}
            onChange={(e) => setCourseFilter(e.target.value)}
            className="text-sm border border-gray-200 rounded-lg px-3 py-1.5"
          >
            {courses.map((c) => (
              <option key={c} value={c}>
                {c === "all" ? "All Courses" : c}
              </option>
            ))}
          </select>
        </div>
        {loading ? (
          <div className="text-sm text-gray-400">Loading…</div>
        ) : (
          <DataTable columns={columns} rows={filteredGaps} searchable={false} pageSize={10} />
        )}
      </div>
    </DashboardLayout>
  );
}
