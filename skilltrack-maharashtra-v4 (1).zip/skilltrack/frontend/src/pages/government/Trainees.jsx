import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import DashboardLayout from "../../components/layout/DashboardLayout";
import DataTable from "../../components/common/DataTable";
import StatusBadge from "../../components/common/StatusBadge";
import api from "../../api/client";

export default function Trainees() {
  const [trainees, setTrainees] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    async function load() {
      const { data } = await api.get("/trainees", { params: { limit: 200 } });
      setTrainees(
        data.items.map((t) => {
          const latestTraining = t.trainingHistory?.[t.trainingHistory.length - 1];
          return {
            id: t._id,
            traineeCode: t.traineeCode,
            name: t.name,
            age: t.age,
            gender: t.gender,
            district: t.districtId?.name,
            course: latestTraining?.programId?.name,
            provider: latestTraining?.providerId?.name,
            status: t.currentOutcomeStatus,
            raw: t,
          };
        })
      );
      setLoading(false);
    }
    load();
  }, []);

  const columns = [
    { key: "traineeCode", label: "Trainee ID" },
    { key: "name", label: "Name" },
    { key: "age", label: "Age" },
    { key: "gender", label: "Gender" },
    { key: "district", label: "District" },
    { key: "course", label: "Course" },
    { key: "provider", label: "Provider" },
    { key: "status", label: "Outcome Status", render: (r) => <StatusBadge status={r.status} /> },
  ];

  return (
    <DashboardLayout role="government">
      <div className="mb-5">
        <h1 className="text-xl font-semibold text-gray-900">Trainee Management</h1>
        <p className="text-sm text-gray-500">Search, filter and open any trainee&apos;s longitudinal profile.</p>
      </div>
      {loading ? (
        <div className="text-sm text-gray-400">Loading trainees…</div>
      ) : (
        <DataTable columns={columns} rows={trainees} onRowClick={(r) => navigate(`/government/trainees/${r.id}`)} pageSize={12} />
      )}
    </DashboardLayout>
  );
}
