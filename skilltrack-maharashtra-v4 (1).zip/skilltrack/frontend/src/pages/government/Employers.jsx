import React, { useEffect, useState } from "react";
import DashboardLayout from "../../components/layout/DashboardLayout";
import DataTable from "../../components/common/DataTable";
import KpiCard from "../../components/common/KpiCard";
import { Building2, ClipboardCheck } from "lucide-react";
import api from "../../api/client";

export default function GovEmployers() {
  const [employers, setEmployers] = useState([]);
  const [pendingCount, setPendingCount] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      const [empRes, pendingRes] = await Promise.all([
        api.get("/employers"),
        api.get("/employers/verifications/pending"),
      ]);
      setEmployers(
        empRes.data.map((e) => ({
          id: e._id,
          name: e.name,
          sector: e.sector,
          district: e.districtId?.name,
          email: e.contactEmail,
          phone: e.contactPhone,
        }))
      );
      setPendingCount(pendingRes.data.length);
      setLoading(false);
    }
    load();
  }, []);

  const columns = [
    { key: "name", label: "Employer" },
    { key: "sector", label: "Sector" },
    { key: "district", label: "District" },
    { key: "email", label: "Contact Email" },
    { key: "phone", label: "Contact Phone" },
  ];

  return (
    <DashboardLayout role="government">
      <div className="mb-5">
        <h1 className="text-xl font-semibold text-gray-900">Employers</h1>
        <p className="text-sm text-gray-500">
          Employers who have received employment-verification requests from the platform.
        </p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <KpiCard label="Registered Employers" value={employers.length} icon={Building2} accent="brand" />
        <KpiCard label="Pending Verification Requests" value={pendingCount} icon={ClipboardCheck} accent="amber" />
      </div>

      {loading ? (
        <div className="text-sm text-gray-400">Loading employers…</div>
      ) : (
        <DataTable columns={columns} rows={employers} pageSize={12} />
      )}
      <p className="text-xs text-gray-400 mt-4">
        Employers confirm or reject employment claims from their own portal (Employer role). This
        screen gives government visibility into who those employers are.
      </p>
    </DashboardLayout>
  );
}
