import React, { createContext, useContext, useEffect, useState } from "react";
import api from "../api/client";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const stored = localStorage.getItem("skilltrack_user");
    if (stored) {
      const u = JSON.parse(stored);
      setUser(u);
      applyTheme(u.themePreference);
    }
    setLoading(false);
  }, []);

  function applyTheme(pref) {
    document.documentElement.classList.toggle("light", pref === "light");
  }

  function persist(data) {
    localStorage.setItem("skilltrack_token", data.token);
    localStorage.setItem("skilltrack_user", JSON.stringify(data.user));
    setUser(data.user);
    applyTheme(data.user.themePreference);
  }

  // identifier = email (government) or uniqueId (provider/trainee/employer)
  async function login(identifier, password) {
    const { data } = await api.post("/auth/login", { identifier, password });
    persist(data);
    return data.user;
  }

  async function registerGovernment(payload) {
    const { data } = await api.post("/auth/register", payload);
    return data; // { userId, emailSent, devOtp }
  }

  async function verifyOtp(userId, otp) {
    const { data } = await api.post("/auth/verify-otp", { userId, otp });
    persist(data);
    return data.user;
  }

  async function resendOtp(userId) {
    const { data } = await api.post("/auth/resend-otp", { userId });
    return data;
  }

  async function updateProfile({ name, themePreference }) {
    const { data } = await api.put("/auth/profile", { userId: user.id, name, themePreference });
    const merged = { ...user, name: data.name || user.name, themePreference: data.themePreference || user.themePreference };
    localStorage.setItem("skilltrack_user", JSON.stringify(merged));
    setUser(merged);
    applyTheme(merged.themePreference);
    return merged;
  }

  function logout() {
    localStorage.removeItem("skilltrack_token");
    localStorage.removeItem("skilltrack_user");
    setUser(null);
  }

  return (
    <AuthContext.Provider value={{ user, login, logout, loading, registerGovernment, verifyOtp, resendOtp, updateProfile }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}
