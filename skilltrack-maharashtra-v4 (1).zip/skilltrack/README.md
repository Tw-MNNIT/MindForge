# SkillTrack Maharashtra

**Longitudinal Skilling Outcomes & Impact Measurement Platform** — a Smart India Hackathon
prototype for Problem Statement 26135 (Government of Maharashtra, MSInS).

> This is a hackathon prototype demonstrating how a longitudinal outcomes platform could work.
> It is **not** an official Government of Maharashtra system, and all data in it is fictional
> demo data seeded for demonstration purposes.

## What this is

Most skilling programs stop measuring success at certification. SkillTrack extends the journey:

```
Enrollment → Training → Certification → Follow-up → Employment Outcome →
Employer Verification → Retention → Wage Progression → Skill Gap → Evidence-Based Analytics
```

Four roles, four different experiences:

- **Government Administrator** — state-wide dashboards, district/provider/course comparisons,
  skill-gap analytics, non-placement reasons, reports, privacy/audit.
- **Training Provider** — their own trainees, course-level outcomes, skill gaps.
- **Trainee** — their profile, longitudinal timeline, a short conditional follow-up form,
  consent controls.
- **Employer** — confirm or reject employment claims made about their organization.

## Tech stack

- **Frontend:** React (JSX, not TypeScript) + Vite + Tailwind CSS + React Router + Recharts + Lucide icons
- **Backend:** Node.js + Express, organized as routes → controllers → services → repositories
- **Database:** MongoDB (via Mongoose) — the actual primary datastore, not mock JSON or local state
- **ML layer:** a modular `services/mlService.js` with deterministic placeholder logic behind a
  stable interface (`/api/ml/*`), designed so a real custom model can be swapped in later without
  touching routes/controllers/frontend

## Project structure

```
skilltrack/
├── backend/
│   ├── config/          # MongoDB connection
│   ├── controllers/     # HTTP request handlers
│   ├── services/        # business logic (job-switch-aware outcomes, verification, analytics...)
│   ├── repositories/    # all Mongo-specific queries (swap-out point for future Postgres)
│   ├── models/          # Mongoose schemas
│   ├── routes/          # Express routers
│   ├── middleware/      # error handling
│   ├── seed/seed.js      # realistic demo data generator
│   └── server.js
└── frontend/
    └── src/
        ├── components/  # layout, common UI, charts, trainee profile view
        ├── pages/        # government/, provider/, trainee/, employer/
        ├── context/      # auth context (demo JWT login)
        └── api/client.js
```

## Prerequisites

- Node.js 18+
- npm
- A MongoDB instance — either:
  - a local MongoDB (`mongod` running on `localhost:27017`), or
  - a free [MongoDB Atlas](https://www.mongodb.com/atlas) cluster (recommended if you don't want
    to install MongoDB locally)

## Setup

### 1. Backend

```bash
cd backend
npm install
cp .env.example .env
```

Edit `.env` and set `MONGODB_URI` to your MongoDB connection string, e.g.:

```
MONGODB_URI=mongodb://127.0.0.1:27017/skilltrack
```

or, for Atlas:

```
MONGODB_URI=mongodb+srv://<user>:<password>@<cluster>.mongodb.net/skilltrack
```

Seed the database with realistic demo data (30+ trainees, 10 districts, 8 courses, 5 providers,
15 employers, and consistent longitudinal follow-up/outcome/verification records):

```bash
npm run seed
```

This prints four demo login accounts at the end (password `demo1234` for all of them):

```
Government : admin@skilltrack-demo.example
Provider   : provider@skilltrack-demo.example
Trainee    : trainee@skilltrack-demo.example
Employer   : employer@skilltrack-demo.example
```

Start the API:

```bash
npm run server        # or: npm run dev  (nodemon, auto-restart)
```

The API listens on `http://localhost:5000` by default. Check `http://localhost:5000/api/health`.

### 2. Frontend

In a second terminal:

```bash
cd frontend
npm install
npm run dev
```

Open `http://localhost:5173`. Sign in with any of the four demo accounts above, or use the
**Select Demo Role** buttons on the login screen (password is pre-filled as `demo1234`).

If your backend runs somewhere other than `http://localhost:5000/api`, set `VITE_API_URL` in a
`frontend/.env` file.

## Suggested demo walkthrough (2–3 minutes)

1. **Log in as Government Administrator** → see total trainees, completion, employment,
   verification, retention and salary KPIs immediately.
2. **Open Trainees → click a trainee** → see the longitudinal outcome timeline: training →
   certification → follow-ups → employment → verification → salary growth.
3. **Log out, log in as Employer** → open **Verification Requests** → confirm or reject a claim.
4. **Log back in as Government** → the verified outcome now reflects in analytics/verification counts.
5. **Open Skill Gap Analytics** → Industry Demand vs Current Skill Level.
6. **Open Analytics → Providers / Courses / Districts tabs** → compare outcomes.
7. Close with: *"The system doesn't stop at certification. It measures what happens afterward."*

## Notes on scope

- **No remedial-action recommendation system** and **no resource-allocation system** are
  implemented — the spec explicitly scopes these out of the MVP; they're mentioned only as
  Future Scope on the landing page.
- **Authentication is demo-only** (email + password against a seeded `User` collection, signed
  with a JWT). It is *not* production-grade auth — there's no OTP/SSO/email verification. The
  architecture (a dedicated `authService.js`) leaves room to swap in a real identity provider.
- **ML is a placeholder layer.** `services/mlService.js` implements deterministic/heuristic logic
  behind the exact endpoint shapes described in the problem statement
  (`/api/ml/skill-gap`, `/api/ml/non-placement-reason`, `/api/ml/outcome-prediction`,
  `/api/ml/attrition-risk`), so a real custom model can replace the function bodies later without
  any other code changing.
- **Database is MongoDB only for now.** The repository layer isolates every Mongo-specific query
  so a future PostgreSQL migration would only require rewriting `backend/repositories/*.js`.
- **All data is fictional.** Names, districts, providers, employers and outcome numbers are
  synthetic and internally consistent, generated by `backend/seed/seed.js` — none of it reflects
  real Government of Maharashtra statistics.

## Common issues

- **"Invalid email or password" on login / empty dashboards:** you likely haven't run
  `npm run seed` yet, or `MONGODB_URI` in `backend/.env` doesn't match where you seeded.
- **CORS errors in the browser console:** make sure `CORS_ORIGIN` in `backend/.env` includes your
  frontend's origin (defaults to `http://localhost:5173`).
- **Charts render empty:** the skill-gap dashboard depends on `SkillGap` aggregates computed
  during seeding (`skillGapService.recomputeSkillGaps()`, run automatically at the end of
  `npm run seed`). Re-run the seed script if this collection looks empty.
