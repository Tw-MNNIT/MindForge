const PDFDocument = require("pdfkit");

/**
 * Streams a single PDF containing a table of Name / Login ID / Password
 * for every trainee passed in — one consolidated list a provider can
 * download and forward, instead of a separate slip per trainee.
 */
function streamCredentialsListPdf(rows, res, { title } = {}) {
  const doc = new PDFDocument({ size: "A4", margin: 48 });
  doc.pipe(res);

  doc
    .fontSize(18)
    .fillColor("#1f2937")
    .text("SkillTrack Maharashtra", { align: "center" })
    .moveDown(0.15)
    .fontSize(11)
    .fillColor("#6b7280")
    .text(title || "Trainee Login Credentials", { align: "center" })
    .moveDown(1.2);

  const colX = { name: 48, id: 250, pass: 400 };
  const pageBottom = 780;

  function drawHeader() {
    doc.font("Helvetica-Bold").fontSize(10).fillColor("#111827");
    const headerY = doc.y;
    doc.text("Name", colX.name, headerY);
    doc.text("Login ID", colX.id, headerY);
    doc.text("Password", colX.pass, headerY);
    doc.moveDown(0.6);
    doc.moveTo(48, doc.y).lineTo(547, doc.y).strokeColor("#d1d5db").stroke();
    doc.moveDown(0.3);
  }

  drawHeader();
  doc.font("Helvetica").fontSize(10).fillColor("#111827");

  rows.forEach((r, idx) => {
    if (doc.y > pageBottom) {
      doc.addPage();
      drawHeader();
      doc.font("Helvetica").fontSize(10).fillColor("#111827");
    }
    const y = doc.y;
    doc.text(r.name, colX.name, y, { width: 190 });
    doc.text(r.uniqueId, colX.id, y, { width: 140 });
    doc.text(r.password, colX.pass, y, { width: 140 });
    doc.moveDown(0.9);
    if (idx < rows.length - 1) {
      doc.moveTo(48, doc.y - 4).lineTo(547, doc.y - 4).strokeColor("#f3f4f6").stroke();
    }
  });

  doc.moveDown(1.5);
  doc
    .fontSize(9)
    .fillColor("#9ca3af")
    .text(
      `Total: ${rows.length} trainee login${rows.length === 1 ? "" : "s"}. Keep this list confidential — forward each trainee only their own row.`,
      { width: 499 }
    );

  doc.end();
}

module.exports = { streamCredentialsListPdf };
