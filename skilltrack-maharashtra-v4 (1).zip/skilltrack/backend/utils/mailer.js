const nodemailer = require("nodemailer");

let transporter = null;
if (process.env.SMTP_USER && process.env.SMTP_PASS) {
  transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST || "smtp.gmail.com",
    port: Number(process.env.SMTP_PORT) || 587,
    secure: false,
    auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS },
  });
}

const sendOTPEmail = async (toEmail, otp, name = "") => {
  if (!transporter) return false; // not configured — caller falls back to devOtp
  const html = `
    <div style="font-family:Arial,sans-serif;max-width:480px;margin:auto;border:1px solid #eee;border-radius:12px;overflow:hidden;">
      <div style="background:#0f172a;padding:20px;text-align:center;">
        <h2 style="color:#fff;margin:0;">SkillTrack Maharashtra</h2>
      </div>
      <div style="padding:24px;color:#1e293b;">
        <p>Hi ${name || "there"},</p>
        <p>Your OTP for Government Administrator account verification is:</p>
        <div style="font-size:32px;font-weight:bold;letter-spacing:8px;text-align:center;color:#4f46e5;margin:16px 0;">${otp}</div>
        <p>This OTP is valid for 10 minutes.</p>
      </div>
    </div>`;
  try {
    await transporter.sendMail({
      from: `"SkillTrack Maharashtra" <${process.env.SMTP_USER}>`,
      to: toEmail,
      subject: "Your SkillTrack Verification OTP",
      html,
    });
    return true;
  } catch (err) {
    console.error("Email send failed:", err.message);
    return false;
  }
};

module.exports = { sendOTPEmail };
