// Generates human-readable unique login IDs per role, e.g. MH-TR-000123.
// These double as the trainee/employer "traineeCode"-style identifiers
// used across the UI, and as the login username for that role.
const PREFIX = {
  trainee: "MH-TR",
  provider: "MH-PR",
  employer: "MH-EM",
  government: "MH-GA",
};

function pad(n, len = 6) {
  return String(n).padStart(len, "0");
}

// seq should be a stable, incrementing number (e.g. a Mongo count + 1).
function generateUniqueId(role, seq) {
  const prefix = PREFIX[role] || "MH-US";
  return `${prefix}-${pad(seq)}`;
}

// Turns a person's name into a compact, lowercase, alphanumeric-only
// slug (e.g. "Priya Deshmukh" -> "priyadeshmukh"), used as the second
// half of the auto-generated "id.username" password below.
function usernameSlug(name) {
  const slug = String(name || "")
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "");
  return slug.slice(0, 20) || "user";
}

// Deterministic default password of the form "<uniqueId>.<usernameSlug>",
// e.g. "MH-TR-000123.priyadeshmukh". Deterministic on purpose: it can be
// re-derived any time (e.g. for a reprinted credentials PDF) from just the
// uniqueId + name, without ever storing the plaintext password.
function defaultPassword(uniqueId, name) {
  return `${uniqueId}.${usernameSlug(name)}`;
}

module.exports = { generateUniqueId, usernameSlug, defaultPassword };
