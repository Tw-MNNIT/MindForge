const { GoogleGenerativeAI } = require("@google/generative-ai");

let genAI = null;
if (process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== "your_gemini_api_key") {
  genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
}

const isConfigured = () => !!genAI;

// Generic short-text generation helper used for dashboard insights.
const generateText = async (prompt, fallback = "Insight unavailable — AI not configured.") => {
  if (!genAI) return fallback;
  try {
    const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
    const result = await model.generateContent(prompt);
    return result.response.text().trim() || fallback;
  } catch (err) {
    console.error("Gemini error:", err.message);
    return fallback;
  }
};

// Generates a structured trainee progress/skilling report as markdown text.
// Used by providers to auto-draft a report a trainee can then view/download.
const generateTraineeReport = async (trainee) => {
  const fallback = `# Training Report — ${trainee.name}\n\nCourse: ${trainee.course || "—"}\nStatus: ${trainee.status || "—"}\n\n(AI report generation is not configured. Set GEMINI_API_KEY in the backend .env to enable AI-drafted reports.)`;
  if (!genAI) return fallback;
  const prompt = `You are a training provider writing a short official progress report for a government skilling
outcomes platform called SkillTrack Maharashtra. Write a concise report (150-250 words) in markdown for this trainee,
covering: training summary, key strengths, areas for improvement, and an overall recommendation. Keep it professional
and factual, no exaggeration.

Trainee data: ${JSON.stringify(trainee)}`;
  return generateText(prompt, fallback);
};

module.exports = { isConfigured, generateText, generateTraineeReport };
