/**
 * Replaceable ML layer (spec sections 9 & 39).
 *
 * None of these functions call any third-party AI provider. They are
 * deterministic, rule-based placeholders that produce the SAME response
 * shape the team's own custom model is expected to return once it's
 * deployed behind ML_SERVICE_URL. When that happens, only the bodies of
 * these functions change (to an HTTP call to ML_SERVICE_URL) — routes,
 * controllers and the frontend contract do not need to change.
 */

const NON_PLACEMENT_KEYWORDS = [
  { reason: "Lack of Local Opportunities", keywords: ["no company", "no companies", "no job near", "not available in my", "no opportunities near"] },
  { reason: "Salary Mismatch", keywords: ["low salary", "pay is low", "salary is not enough", "underpaid"] },
  { reason: "Technical Skill Gap", keywords: ["failed interview", "technical round", "coding test", "skill test"] },
  { reason: "Communication Gap", keywords: ["english", "communication", "interview round"] },
  { reason: "Relocation/Mobility Constraint", keywords: ["cannot relocate", "family reasons to stay", "cannot move", "travel far"] },
  { reason: "Lack of Experience", keywords: ["no experience", "fresher", "experience required"] },
];

const mlService = {
  /**
   * POST /api/ml/skill-gap
   * Delegates to the deterministic skillGapService for now.
   */
  async skillGap({ programId, districtId } = {}) {
    const skillGapService = require("./skillGapService");
    const gaps = await skillGapService.getGaps({ programId, districtId });
    return {
      model: "rule-based-placeholder-v0",
      gaps,
    };
  },

  /**
   * POST /api/ml/non-placement-reason
   * Naive keyword classification of trainee free-text feedback.
   * A real NLP model would replace only this function body.
   */
  async nonPlacementReason({ text = "" }) {
    const lower = text.toLowerCase();
    for (const entry of NON_PLACEMENT_KEYWORDS) {
      if (entry.keywords.some((k) => lower.includes(k))) {
        return { model: "keyword-placeholder-v0", predictedReason: entry.reason, confidence: 0.6 };
      }
    }
    return { model: "keyword-placeholder-v0", predictedReason: "Other", confidence: 0.3 };
  },

  /**
   * POST /api/ml/outcome-prediction
   * Simple heuristic based on attendance + assessment score, purely for
   * demo purposes — explicitly NOT a validated predictive model.
   */
  async outcomePrediction({ attendancePct = 0, assessmentScore = 0 } = {}) {
    const score = attendancePct * 0.4 + assessmentScore * 0.6;
    const probability = Math.min(0.95, Math.max(0.05, score / 100));
    return {
      model: "heuristic-placeholder-v0",
      probabilityEmployedWithin6Months: Math.round(probability * 100) / 100,
      disclaimer: "Demo heuristic only — not a validated predictive model.",
    };
  },

  /**
   * POST /api/ml/attrition-risk
   * Flags risk when salary hasn't moved and tenure is long, as a stand-in
   * for a real attrition model.
   */
  async attritionRisk({ monthsInRole = 0, salaryGrowthPct = 0 } = {}) {
    let risk = "Low";
    if (monthsInRole > 12 && salaryGrowthPct <= 0) risk = "High";
    else if (monthsInRole > 6 && salaryGrowthPct < 5) risk = "Medium";
    return { model: "heuristic-placeholder-v0", riskLevel: risk };
  },

  /**
   * Outcome anomaly detection (spec 39.5): flags providers whose
   * self-reported placement rate diverges sharply from verified rate.
   */
  async outcomeAnomalies() {
    const analyticsService = require("./analyticsService");
    const providers = await analyticsService.providers();
    return providers
      .filter((p) => p.placementRate - p.verificationRate > 25)
      .map((p) => ({
        provider: p.provider,
        placementRate: p.placementRate,
        verificationRate: p.verificationRate,
        flag: "Outcome data discrepancy detected",
      }));
  },
};

module.exports = mlService;
