const followUpRepository = require("../repositories/followUpRepository");
const outcomeService = require("./outcomeService");
const auditService = require("./auditService");

const OUTCOME_TYPE_MAP = {
  Employed: "employed",
  "Self-Employed": "self_employed",
  Apprenticeship: "apprenticeship",
  Unemployed: "unemployed",
  "Further Education": "further_education",
};

const followUpService = {
  async list(filters) {
    return followUpRepository.list(filters);
  },

  async sendReminder(id) {
    const followUp = await followUpRepository.markReminderSent(id);
    await auditService.log({
      actorRole: "government",
      actorLabel: "Admin",
      action: "Sent follow-up reminder",
      entityType: "FollowUp",
      entityId: id,
    });
    return followUp;
  },

  /**
   * Handles the conditional follow-up form (spec section 34): takes the
   * short structured answer, creates the matching EmploymentOutcome, and
   * marks the follow-up checkpoint completed - all in one call so the
   * frontend only needs one request per submission.
   */
  async submitResponse(followUpId, { currentStatus, notes, ...outcomePayload }) {
    const followUp = await followUpRepository.findById(followUpId);
    if (!followUp) {
      const err = new Error("Follow-up not found");
      err.statusCode = 404;
      throw err;
    }

    const outcomeType = OUTCOME_TYPE_MAP[currentStatus];
    const outcome = await outcomeService.reportOutcome({
      traineeId: followUp.traineeId,
      outcomeType,
      source: "trainee",
      payload: outcomePayload,
    });

    const updated = await followUpRepository.submitResponse(followUpId, {
      currentStatus,
      notes,
      resultingOutcomeId: outcome._id,
    });

    await auditService.log({
      actorRole: "trainee",
      actorLabel: "Trainee",
      action: `Submitted ${followUp.checkpoint.replace("_", " ")} follow-up`,
      entityType: "FollowUp",
      entityId: followUpId,
    });

    return { followUp: updated, outcome };
  },

  async summary() {
    const rows = await followUpRepository.countByStatus();
    return rows.reduce((acc, r) => ({ ...acc, [r._id]: r.count }), {
      Pending: 0,
      Completed: 0,
      Overdue: 0,
      "Not Reachable": 0,
    });
  },
};

module.exports = followUpService;
