const employmentOutcomeRepository = require("../repositories/employmentOutcomeRepository");
const traineeService = require("./traineeService");
const auditService = require("./auditService");

/**
 * Records a new employment outcome for a trainee. Because a trainee's
 * work history is longitudinal (they can switch jobs, lose a job, start a
 * business, etc.), reporting a new outcome closes out whatever the
 * trainee's previous "current" spell was rather than overwriting it —
 * that's what keeps the wage-progression chart and timeline accurate.
 */
async function reportOutcome({ traineeId, outcomeType, source = "trainee", payload = {} }) {
  await employmentOutcomeRepository.endPreviousCurrent(traineeId);

  const doc = {
    traineeId,
    outcomeType,
    source,
    isCurrent: true,
    verification: {
      status: outcomeType === "employed" ? "pending" : "not_applicable",
      requestedAt: outcomeType === "employed" ? new Date() : undefined,
    },
    confidence: source === "employer" ? "high" : "medium",
  };

  if (outcomeType === "employed") {
    Object.assign(doc, {
      employerId: payload.employerId,
      jobTitle: payload.jobTitle,
      employmentType: payload.employmentType,
      workLocation: payload.workLocation,
      joiningDate: payload.joiningDate,
      salaryHistory: payload.monthlySalary
        ? [{ monthlySalary: Number(payload.monthlySalary), recordedAt: new Date() }]
        : [],
    });
  } else if (outcomeType === "self_employed") {
    doc.selfEmployment = {
      businessType: payload.businessType,
      monthlyIncome: Number(payload.monthlyIncome) || 0,
      businessDurationMonths: Number(payload.businessDurationMonths) || 0,
    };
  } else if (outcomeType === "apprenticeship") {
    doc.apprenticeship = {
      organization: payload.organization,
      stipend: Number(payload.stipend) || 0,
      durationMonths: Number(payload.durationMonths) || 0,
    };
  } else if (outcomeType === "unemployed") {
    doc.unemployment = {
      reason: payload.reason,
      lookingForEmployment: payload.lookingForEmployment !== false,
      skillsNeeded: payload.skillsNeeded || [],
    };
  }

  const outcome = await employmentOutcomeRepository.create(doc);
  await traineeService.syncOutcomeStatus(traineeId, outcomeType);

  await auditService.log({
    actorRole: source === "employer" ? "employer" : "trainee",
    actorLabel: source === "employer" ? "Employer" : "Trainee",
    action: `Reported outcome: ${outcomeType.replace("_", " ")}`,
    entityType: "EmploymentOutcome",
    entityId: outcome._id,
  });

  return outcome;
}

async function addSalaryRecord(outcomeId, monthlySalary, actorLabel = "Admin") {
  const updated = await employmentOutcomeRepository.addSalaryRecord(outcomeId, Number(monthlySalary));
  await auditService.log({
    actorRole: "government",
    actorLabel,
    action: `Updated salary record to ₹${Number(monthlySalary).toLocaleString("en-IN")}`,
    entityType: "EmploymentOutcome",
    entityId: outcomeId,
  });
  return updated;
}

async function getByTrainee(traineeId) {
  return employmentOutcomeRepository.findByTrainee(traineeId);
}

module.exports = { reportOutcome, addSalaryRecord, getByTrainee };
