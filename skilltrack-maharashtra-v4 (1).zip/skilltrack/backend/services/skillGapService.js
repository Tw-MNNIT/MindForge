const skillRepository = require("../repositories/skillRepository");
const programRepository = require("../repositories/programRepository");

/**
 * Deterministic skill-gap calculation for the prototype (spec section 22
 * / 39.1): averages each trainee's assessed skill level per course and
 * compares it against the course's declared industry-demand figure.
 *
 * This is intentionally NOT machine learning - it's the kind of thing a
 * SQL/aggregation query could do - which is exactly why it's a good
 * placeholder to swap out later: POST /api/ml/skill-gap can eventually
 * call the team's real model and this function's output shape
 * ({ skill, industryDemand, currentLevel, gap }) stays the same.
 */
async function recomputeSkillGaps() {
  await skillRepository.clearGaps();
  const [programs, assessments] = await Promise.all([
    programRepository.list(),
    skillRepository.findAllAssessments(),
  ]);

  const results = [];

  for (const program of programs) {
    const programAssessments = assessments.filter(
      (a) => String(a.programId) === String(program._id)
    );

    for (const req of program.requiredSkills) {
      const levels = [];
      programAssessments.forEach((a) => {
        const match = a.skills.find((s) => s.skill === req.skill);
        if (match) levels.push(match.currentLevel);
      });

      const currentLevel = levels.length
        ? Math.round(levels.reduce((a, b) => a + b, 0) / levels.length)
        : Math.max(0, req.industryDemand - 25); // fallback demo estimate

      const gap = Math.max(0, req.industryDemand - currentLevel);

      const saved = await skillRepository.upsertGap(
        { programId: program._id, skill: req.skill },
        {
          programId: program._id,
          skill: req.skill,
          industryDemand: req.industryDemand,
          currentLevel,
          gap,
          sampleSize: levels.length,
          computedAt: new Date(),
        }
      );
      results.push(saved);
    }
  }

  return results;
}

async function getGaps(filters) {
  return skillRepository.listGaps(filters);
}

async function topGaps(limit = 5) {
  const gaps = await skillRepository.listGaps();
  const bySkill = {};
  gaps.forEach((g) => {
    if (!bySkill[g.skill]) bySkill[g.skill] = { skill: g.skill, gapSum: 0, count: 0 };
    bySkill[g.skill].gapSum += g.gap;
    bySkill[g.skill].count += 1;
  });
  return Object.values(bySkill)
    .map((s) => ({ skill: s.skill, avgGapPct: Math.round(s.gapSum / s.count) }))
    .sort((a, b) => b.avgGapPct - a.avgGapPct)
    .slice(0, limit);
}

module.exports = { recomputeSkillGaps, getGaps, topGaps };
