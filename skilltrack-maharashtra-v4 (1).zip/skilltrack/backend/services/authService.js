const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const userRepository = require("../repositories/userRepository");
const providerRepository = require("../repositories/providerRepository");
const auditService = require("./auditService");
const { generateUniqueId } = require("../utils/uniqueId");
const { generateOTP, otpExpiryDate } = require("../utils/otp");
const { sendOTPEmail } = require("../utils/mailer");

function sign(user) {
  return jwt.sign(
    { userId: user._id, role: user.role, linkedId: user.linkedId },
    process.env.JWT_SECRET || "dev_secret",
    { expiresIn: "12h" }
  );
}

function toSafeUser(user) {
  return {
    id: user._id,
    name: user.name,
    email: user.email,
    uniqueId: user.uniqueId,
    role: user.role,
    linkedId: user.linkedId,
    themePreference: user.themePreference,
  };
}

const authService = {
  /**
   * Single login endpoint for all four roles. Government accounts sign in
   * with email; provider/trainee/employer accounts sign in with the
   * uniqueId issued when their profile was created.
   */
  async login(identifier, password) {
    const user = await userRepository.findByIdentifier(identifier);
    if (!user) {
      const err = new Error("Invalid ID/email or password");
      err.statusCode = 401;
      throw err;
    }
    const valid = await bcrypt.compare(password, user.passwordHash);
    if (!valid) {
      const err = new Error("Invalid ID/email or password");
      err.statusCode = 401;
      throw err;
    }
    if (user.role === "government" && !user.isVerified) {
      const err = new Error("Account not verified. Please complete OTP verification.");
      err.statusCode = 403;
      err.userId = user._id;
      err.needsVerification = true;
      throw err;
    }
    return { token: sign(user), user: toSafeUser(user) };
  },

  /**
   * Government administrators are the only role that self-registers, and
   * they must verify via a 6-digit email OTP before they can log in.
   */
  async registerGovernment({ name, email, password }) {
    const existing = await userRepository.findByEmail(email);
    if (existing && existing.isVerified) {
      const err = new Error("An account with this email already exists");
      err.statusCode = 409;
      throw err;
    }

    const passwordHash = await bcrypt.hash(password, 10);
    const otp = generateOTP();
    const otpExpiry = otpExpiryDate(10);

    let user;
    if (existing && !existing.isVerified) {
      existing.name = name;
      existing.passwordHash = passwordHash;
      existing.otp = otp;
      existing.otpExpiry = otpExpiry;
      user = await existing.save();
    } else {
      user = await userRepository.create({
        name,
        email,
        passwordHash,
        role: "government",
        isVerified: false,
        otp,
        otpExpiry,
      });
    }

    const emailSent = await sendOTPEmail(email, otp, name);
    return { userId: user._id, emailSent, devOtp: emailSent ? undefined : otp };
  },

  async verifyOtp(userId, otp) {
    const user = await userRepository.findById(userId);
    if (!user) {
      const err = new Error("User not found");
      err.statusCode = 404;
      throw err;
    }
    if (user.isVerified) {
      const err = new Error("Already verified");
      err.statusCode = 400;
      throw err;
    }
    if (!user.otp || user.otp !== otp || user.otpExpiry < new Date()) {
      const err = new Error("Invalid or expired OTP");
      err.statusCode = 400;
      throw err;
    }
    user.isVerified = true;
    user.otp = undefined;
    user.otpExpiry = undefined;
    await user.save();

    await auditService.log({
      actorRole: "government",
      actorLabel: user.name,
      action: "Government account verified via OTP",
      entityType: "User",
      entityId: user._id,
    });

    return { token: sign(user), user: toSafeUser(user) };
  },

  async resendOtp(userId) {
    const user = await userRepository.findById(userId);
    if (!user) {
      const err = new Error("User not found");
      err.statusCode = 404;
      throw err;
    }
    if (user.isVerified) {
      const err = new Error("Already verified");
      err.statusCode = 400;
      throw err;
    }
    const otp = generateOTP();
    user.otp = otp;
    user.otpExpiry = otpExpiryDate(10);
    await user.save();
    const emailSent = await sendOTPEmail(user.email, otp, user.name);
    return { emailSent, devOtp: emailSent ? undefined : otp };
  },

  /**
   * Called by a verified government admin to onboard a new Training
   * Provider: creates the Provider profile AND its login credentials in
   * one step, returning the generated uniqueId + a temp password so the
   * admin can hand them to the provider.
   */
  async issueProviderCredentials({ name, districtId, contactEmail, contactPhone, empanelmentId }) {
    const provider = await providerRepository.create({
      name,
      districtId,
      contactEmail,
      contactPhone,
      empanelmentId,
      active: true,
    });

    const seq = (await userRepository.countByRole("provider")) + 1;
    const uniqueId = generateUniqueId("provider", seq);
    const tempPassword = Math.random().toString(36).slice(-8);
    const passwordHash = await bcrypt.hash(tempPassword, 10);

    const user = await userRepository.create({
      name: `${name} Coordinator`,
      uniqueId,
      passwordHash,
      role: "provider",
      linkedId: provider._id,
      linkedModel: "Provider",
    });

    await auditService.log({
      actorRole: "government",
      actorLabel: "Government Administrator",
      action: `Issued provider credentials (${uniqueId}) for ${name}`,
      entityType: "Provider",
      entityId: provider._id,
    });

    return { provider, credentials: { uniqueId: user.uniqueId, tempPassword } };
  },

  async updateProfile(userId, { name, themePreference }) {
    return userRepository.updateProfile(userId, { name, themePreference });
  },
};

module.exports = authService;
