const analyticsRepository = require("../repositories/analyticsRepository");
const consentRepository = require("../repositories/consentRepository");

const analyticsService = {
  async overview() {
    const [
      totalTrainees,
      totalCertified,
      outcomeStatusCounts,
      verifiedPlacements,
      avgSalary,
      selfEmployment,
      followUpResponseRate,
      retention12Month,
    ] = await Promise.all([
      analyticsRepository.totalTrainees(),
      analyticsRepository.totalCertified(),
      analyticsRepository.currentOutcomeCounts(),
      analyticsRepository.verifiedPlacementCount(),
      analyticsRepository.averageCurrentSalary(),
      analyticsRepository.selfEmploymentCount(),
      analyticsRepository.followUpResponseRate(),
      analyticsRepository.retentionRate(12),
    ]);

    const employedLike =
      (outcomeStatusCounts["Employed"] || 0) +
      (outcomeStatusCounts["Self-Employed"] || 0) +
      (outcomeStatusCounts["Apprenticeship"] || 0);

    const employmentRate = totalCertified
      ? Math.round((employedLike / totalCertified) * 1000) / 10
      : 0;

    return {
      totalTrainees,
      trainingCompleted: totalCertified,
      employmentRate,
      verifiedPlacements,
      employmentRetention: retention12Month,
      averageSalary: avgSalary,
      followUpResponseRate,
      selfEmployment,
      outcomeStatusCounts,
    };
  },

  async employmentOutcomeTrend() {
    return analyticsRepository.employmentTrendByMonth(12);
  },

  async employmentStatusDistribution() {
    return analyticsRepository.outcomeDistribution();
  },

  async districts() {
    return analyticsRepository.districtPerformance();
  },

  async providers() {
    return analyticsRepository.providerPerformance();
  },

  async courses() {
    return analyticsRepository.coursePerformance();
  },

  async demographics() {
    return analyticsRepository.demographics();
  },

  async nonPlacementReasons() {
    return analyticsRepository.nonPlacementReasons();
  },

  async consentSummary() {
    const rows = await consentRepository.countByStatus();
    return rows.reduce((acc, r) => ({ ...acc, [r._id]: r.count }), { Given: 0, Pending: 0, Revoked: 0 });
  },
};

module.exports = analyticsService;
