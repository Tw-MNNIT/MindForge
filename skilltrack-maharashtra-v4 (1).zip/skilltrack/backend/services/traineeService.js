const bcrypt = require("bcryptjs");
const traineeRepository = require("../repositories/traineeRepository");
const employmentOutcomeRepository = require("../repositories/employmentOutcomeRepository");
const followUpRepository = require("../repositories/followUpRepository");
const consentRepository = require("../repositories/consentRepository");
const userRepository = require("../repositories/userRepository");
const auditService = require("./auditService");
const { generateUniqueId, defaultPassword } = require("../utils/uniqueId");
const { streamCredentialsListPdf: renderCredentialsListPdf } = require("../utils/credentialPdf");

const OUTCOME_TYPE_TO_STATUS = {
  employed: "Employed",
  self_employed: "Self-Employed",
  apprenticeship: "Apprenticeship",
  unemployed: "Unemployed",
  further_education: "Further Education",
};

const traineeService = {
  /**
   * Registers a trainee AND issues their login in the same step — mirrors
   * authService.issueProviderCredentials(), which is what providers get.
   * Without this second half, a trainee record existed but no User
   * document (uniqueId/password) was ever created for them, so they had
   * no way to log in.
   *
   * uniqueId: auto-generated if the caller didn't supply one (MH-TR-000123 style).
   * password: deterministic "<uniqueId>.<usernameSlug>" (e.g.
   *   "MH-TR-000123.priyadeshmukh") — chosen so it never has to be stored
   *   in plaintext or handed off separately; it can always be re-derived
   *   from the trainee's own record for a reprinted credentials PDF.
   */
  async createTrainee(payload) {
    let traineeCode = payload.traineeCode;
    if (!traineeCode) {
      const seq = (await traineeRepository.countAll()) + 1;
      traineeCode = generateUniqueId("trainee", seq);
    }

    const trainee = await traineeRepository.create({ ...payload, traineeCode });
    await consentRepository.create({ traineeId: trainee._id, status: "Pending" });

    const password = defaultPassword(trainee.traineeCode, trainee.name);
    const passwordHash = await bcrypt.hash(password, 10);
    await userRepository.create({
      name: trainee.name,
      uniqueId: trainee.traineeCode,
      passwordHash,
      role: "trainee",
      linkedId: trainee._id,
      linkedModel: "Trainee",
    });

    await auditService.log({
      actorRole: "government",
      actorLabel: "Admin",
      action: `Registered new trainee ${trainee.traineeCode} and issued login credentials`,
      entityType: "Trainee",
      entityId: trainee._id,
    });

    return { trainee, credentials: { uniqueId: trainee.traineeCode, password } };
  },

  async list(filters) {
    return traineeRepository.list(filters);
  },

  /**
   * The consolidated login list a provider (or government admin) can pull
   * up any time: every trainee's Name / Login ID / Password in one place,
   * so they can view it on screen or forward a row to a trainee — no
   * separate PDF per trainee. Optionally scoped to one provider's own
   * trainees. Password is re-derived deterministically (see createTrainee
   * above), never read from the DB, since only the bcrypt hash is stored.
   */
  async getCredentialsList(providerId) {
    const trainees = await traineeRepository.listForCredentials(providerId);
    return trainees.map((t) => ({
      id: t._id,
      name: t.name,
      uniqueId: t.traineeCode,
      password: defaultPassword(t.traineeCode, t.name),
    }));
  },

  async streamCredentialsListPdf(providerId, res) {
    const rows = await this.getCredentialsList(providerId);
    res.setHeader("Content-Type", "application/pdf");
    res.setHeader("Content-Disposition", 'attachment; filename="trainee-login-credentials.pdf"');
    renderCredentialsListPdf(rows, res);
  },
  /**
   * Builds the full profile a judge sees on the Trainee Profile screen:
   * base record + longitudinal outcome history + follow-up schedule +
   * consent status, all derived from live collections (not cached copies).
   */
  async getFullProfile(id) {
    const [trainee, outcomes, followUps, consent] = await Promise.all([
      traineeRepository.findById(id),
      employmentOutcomeRepository.findByTrainee(id),
      followUpRepository.findByTrainee(id),
      consentRepository.findByTrainee(id),
    ]);
    if (!trainee) return null;

    const timeline = buildTimeline(trainee, outcomes, followUps);

    return { trainee, outcomes, followUps, consent, timeline };
  },

  async syncOutcomeStatus(traineeId, outcomeType) {
    const status = OUTCOME_TYPE_TO_STATUS[outcomeType] || "Certified - Awaiting Follow-up";
    return traineeRepository.updateOutcomeStatus(traineeId, status);
  },
};

/**
 * Converts a trainee's raw training/outcome/follow-up records into the
 * ordered timeline shown on the profile page (section 15 of the spec).
 */
function buildTimeline(trainee, outcomes, followUps) {
  const events = [];

  (trainee.trainingHistory || []).forEach((th) => {
    if (th.startDate) events.push({ date: th.startDate, label: "Training Started", type: "training" });
    if (th.completionDate) events.push({ date: th.completionDate, label: "Training Completed", type: "training" });
    if (th.certified && th.certificationDate) {
      events.push({ date: th.certificationDate, label: "Certified", type: "certification" });
    }
  });

  followUps.forEach((f) => {
    if (f.status === "Completed" && f.completedAt) {
      events.push({
        date: f.completedAt,
        label: `${f.checkpoint.replace("_", " ")} Follow-up Completed`,
        type: "followup",
      });
    }
  });

  outcomes.forEach((o) => {
    events.push({ date: o.createdAt, label: outcomeLabel(o), type: "outcome" });
    if (o.verification?.status === "verified" && o.verification.respondedAt) {
      events.push({ date: o.verification.respondedAt, label: "Employer Verified Outcome", type: "verification" });
    }
    (o.salaryHistory || []).forEach((s, idx) => {
      if (idx === 0) return; // first entry is the joining salary, not a "raise"
      events.push({ date: s.recordedAt, label: `Salary Updated to ₹${s.monthlySalary.toLocaleString("en-IN")}`, type: "salary" });
    });
  });

  return events.sort((a, b) => new Date(a.date) - new Date(b.date));
}

function outcomeLabel(o) {
  switch (o.outcomeType) {
    case "employed":
      return `Employment Reported (${o.jobTitle || "role"})`;
    case "self_employed":
      return "Self-Employment Reported";
    case "apprenticeship":
      return "Apprenticeship Reported";
    case "unemployed":
      return "Unemployment Reported";
    case "further_education":
      return "Further Education Reported";
    default:
      return "Outcome Reported";
  }
}

module.exports = traineeService;
