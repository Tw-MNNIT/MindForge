const auditLogRepository = require("../repositories/auditLogRepository");

const auditService = {
  async log({ actorRole, actorLabel, action, entityType, entityId }) {
    return auditLogRepository.create({ actorRole, actorLabel, action, entityType, entityId });
  },

  async recent(limit) {
    return auditLogRepository.list(limit);
  },
};

module.exports = auditService;
