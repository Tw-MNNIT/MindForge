const reportRepository = require("../repositories/reportRepository");
const traineeRepository = require("../repositories/traineeRepository");
const { generateTraineeReport } = require("../utils/gemini");
const auditService = require("./auditService");

const reportService = {
  async generate({ traineeId, providerId }) {
    const trainee = await traineeRepository.findById(traineeId);
    if (!trainee) {
      const err = new Error("Trainee not found");
      err.statusCode = 404;
      throw err;
    }
    const latestTraining = trainee.trainingHistory?.[trainee.trainingHistory.length - 1];

    const aiContent = await generateTraineeReport({
      name: trainee.name,
      course: latestTraining?.programId?.name,
      status: trainee.currentOutcomeStatus,
      certified: latestTraining?.certified,
      completionDate: latestTraining?.completionDate,
    });

    const report = await reportRepository.create({
      traineeId,
      providerId,
      title: `Training Report — ${trainee.name}`,
      aiContent,
    });

    await auditService.log({
      actorRole: "provider",
      actorLabel: "Training Provider",
      action: `Generated AI training report for ${trainee.name}`,
      entityType: "Report",
      entityId: report._id,
    });

    return report;
  },

  async attachFile({ traineeId, providerId, fileUrl, fileName }) {
    const report = await reportRepository.create({
      traineeId,
      providerId,
      title: `Training Report — Uploaded Document`,
      fileUrl,
      fileName,
    });
    await auditService.log({
      actorRole: "provider",
      actorLabel: "Training Provider",
      action: `Uploaded a training report document (${fileName})`,
      entityType: "Report",
      entityId: report._id,
    });
    return report;
  },

  async getForTrainee(traineeId) {
    return reportRepository.findByTrainee(traineeId);
  },
};

module.exports = reportService;
