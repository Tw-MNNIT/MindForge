const employmentOutcomeRepository = require("../repositories/employmentOutcomeRepository");
const auditService = require("./auditService");

/**
 * Implements the workflow from spec section 18:
 *   trainee reports employment -> verification request -> employer
 *   reviews -> confirm/reject -> Verified / Failed / Pending
 * Confidence is re-derived here rather than left to the caller, so it
 * always reflects the actual verification outcome (section 19).
 */
const verificationService = {
  async listPending(employerId) {
    return employmentOutcomeRepository.findPendingVerifications(employerId);
  },

  async listResolved(employerId) {
    return employmentOutcomeRepository.findResolvedVerifications(employerId);
  },

  async respond(outcomeId, { decision, employerNotes, actorLabel = "Employer" }) {
    const status = decision === "confirm" ? "verified" : "failed";
    const updated = await employmentOutcomeRepository.updateVerification(outcomeId, {
      status,
      respondedAt: new Date(),
      employerNotes,
    });

    // Confidence reflects agreement between sources (section 19):
    // verified -> high confidence; failed -> low confidence (conflicting).
    updated.confidence = status === "verified" ? "high" : "low";
    await updated.save();

    await auditService.log({
      actorRole: "employer",
      actorLabel,
      action: `Employer verification ${status === "verified" ? "confirmed" : "rejected"} for outcome`,
      entityType: "EmploymentOutcome",
      entityId: updated._id,
    });

    return updated;
  },
};

module.exports = verificationService;
