require("dotenv").config();
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");

const User = require("../models/User");
const District = require("../models/District");
const Provider = require("../models/Provider");
const TrainingProgram = require("../models/TrainingProgram");
const Employer = require("../models/Employer");
const Trainee = require("../models/Trainee");
const EmploymentOutcome = require("../models/EmploymentOutcome");
const FollowUp = require("../models/FollowUp");
const SkillAssessment = require("../models/SkillAssessment");
const Consent = require("../models/Consent");
const AuditLog = require("../models/AuditLog");
const SkillGap = require("../models/SkillGap");

const skillGapService = require("../services/skillGapService");
const { generateUniqueId } = require("../utils/uniqueId");

// ---------- deterministic-ish random helpers (seeded for repeatability) ----------
let seedCounter = 42;
function rand() {
  seedCounter = (seedCounter * 9301 + 49297) % 233280;
  return seedCounter / 233280;
}
function pick(arr) {
  return arr[Math.floor(rand() * arr.length)];
}
function randInt(min, max) {
  return Math.floor(rand() * (max - min + 1)) + min;
}
function daysAgo(n) {
  const d = new Date();
  d.setDate(d.getDate() - n);
  return d;
}
function monthsAgo(n) {
  const d = new Date();
  d.setMonth(d.getMonth() - n);
  return d;
}

const FIRST_NAMES_M = ["Rohan", "Aditya", "Vikram", "Sanjay", "Amit", "Rahul", "Suresh", "Ganesh", "Prakash", "Nikhil", "Omkar", "Yash", "Abhishek", "Manoj", "Sachin"];
const FIRST_NAMES_F = ["Priya", "Sneha", "Anjali", "Pooja", "Kavita", "Neha", "Swati", "Rupali", "Manisha", "Divya", "Shraddha", "Komal", "Asha", "Vaishnavi", "Rutuja"];
const LAST_NAMES = ["Patil", "Deshmukh", "Kulkarni", "Shinde", "Jadhav", "More", "Gaikwad", "Pawar", "Sawant", "Chavan", "Kadam", "Bhosale", "Salunkhe", "Wagh", "Joshi"];

async function run() {
  const uri = process.env.MONGODB_URI;
  if (!uri) {
    console.error("MONGODB_URI is not set. Copy .env.example to .env first.");
    process.exit(1);
  }
  await mongoose.connect(uri);
  console.log("Connected. Wiping existing collections...");

  await Promise.all([
    User.deleteMany({}),
    District.deleteMany({}),
    Provider.deleteMany({}),
    TrainingProgram.deleteMany({}),
    Employer.deleteMany({}),
    Trainee.deleteMany({}),
    EmploymentOutcome.deleteMany({}),
    FollowUp.deleteMany({}),
    SkillAssessment.deleteMany({}),
    Consent.deleteMany({}),
    AuditLog.deleteMany({}),
    SkillGap.deleteMany({}),
  ]);

  // ---------------- Districts ----------------
  const districtDefs = [
    { name: "Pune", region: "Western Maharashtra", urbanRuralMix: { urbanPct: 70, ruralPct: 30 } },
    { name: "Mumbai", region: "Konkan", urbanRuralMix: { urbanPct: 95, ruralPct: 5 } },
    { name: "Nagpur", region: "Vidarbha", urbanRuralMix: { urbanPct: 60, ruralPct: 40 } },
    { name: "Nashik", region: "North Maharashtra", urbanRuralMix: { urbanPct: 55, ruralPct: 45 } },
    { name: "Thane", region: "Konkan", urbanRuralMix: { urbanPct: 80, ruralPct: 20 } },
    { name: "Kolhapur", region: "Western Maharashtra", urbanRuralMix: { urbanPct: 45, ruralPct: 55 } },
    { name: "Solapur", region: "Western Maharashtra", urbanRuralMix: { urbanPct: 40, ruralPct: 60 } },
    { name: "Chhatrapati Sambhajinagar", region: "Marathwada", urbanRuralMix: { urbanPct: 50, ruralPct: 50 } },
    { name: "Amravati", region: "Vidarbha", urbanRuralMix: { urbanPct: 42, ruralPct: 58 } },
    { name: "Latur", region: "Marathwada", urbanRuralMix: { urbanPct: 38, ruralPct: 62 } },
  ];
  const districts = await District.insertMany(districtDefs);
  const dByName = Object.fromEntries(districts.map((d) => [d.name, d]));
  console.log(`Seeded ${districts.length} districts`);

  // ---------------- Providers ----------------
  const providerDefs = [
    { name: "Maharashtra Skill Development Centre", district: "Pune", email: "contact@msdc-demo.example" },
    { name: "TechSkill Academy", district: "Mumbai", email: "info@techskillacademy-demo.example" },
    { name: "FutureSkills Institute", district: "Nagpur", email: "hello@futureskills-demo.example" },
    { name: "Digital Maharashtra Training", district: "Nashik", email: "contact@digitalmh-demo.example" },
    { name: "Industry Skill Hub", district: "Chhatrapati Sambhajinagar", email: "info@industryskillhub-demo.example" },
  ];
  const providers = await Provider.insertMany(
    providerDefs.map((p, idx) => ({
      name: p.name,
      districtId: dByName[p.district]._id,
      empanelmentId: `MH-EMP-${1000 + idx}`,
      contactEmail: p.email,
      contactPhone: `98${randInt(10000000, 99999999)}`,
      active: true,
    }))
  );
  console.log(`Seeded ${providers.length} providers`);

  // ---------------- Training Programs (courses) ----------------
  const courseDefs = [
    { name: "Full Stack Development", sector: "IT", weeks: 16, skills: [{ skill: "SQL", d: 88 }, { skill: "JavaScript", d: 85 }, { skill: "Communication", d: 82 }, { skill: "Problem Solving", d: 78 }] },
    { name: "Data Analytics", sector: "IT", weeks: 12, skills: [{ skill: "SQL", d: 90 }, { skill: "Advanced Excel", d: 84 }, { skill: "Communication", d: 75 }, { skill: "Problem Solving", d: 80 }] },
    { name: "Electrician", sector: "Core Trade", weeks: 10, skills: [{ skill: "Digital Tools", d: 60 }, { skill: "Safety Compliance", d: 88 }, { skill: "Problem Solving", d: 70 }] },
    { name: "CNC Operator", sector: "Manufacturing", weeks: 14, skills: [{ skill: "Digital Tools", d: 72 }, { skill: "Precision Measurement", d: 85 }, { skill: "Safety Compliance", d: 80 }] },
    { name: "Digital Marketing", sector: "IT/Services", weeks: 8, skills: [{ skill: "Communication", d: 85 }, { skill: "Digital Tools", d: 80 }, { skill: "Advanced Excel", d: 60 }] },
    { name: "Welding", sector: "Manufacturing", weeks: 10, skills: [{ skill: "Safety Compliance", d: 90 }, { skill: "Precision Measurement", d: 78 }] },
    { name: "Healthcare Assistant", sector: "Healthcare", weeks: 12, skills: [{ skill: "Communication", d: 88 }, { skill: "Patient Care Protocol", d: 85 }, { skill: "Safety Compliance", d: 75 }] },
    { name: "Automotive Technician", sector: "Manufacturing", weeks: 14, skills: [{ skill: "Digital Tools", d: 68 }, { skill: "Precision Measurement", d: 76 }, { skill: "Problem Solving", d: 74 }] },
  ];
  const programs = [];
  for (let i = 0; i < courseDefs.length; i++) {
    const c = courseDefs[i];
    const provider = providers[i % providers.length];
    const program = await TrainingProgram.create({
      name: c.name,
      sector: c.sector,
      durationWeeks: c.weeks,
      providerId: provider._id,
      requiredSkills: c.skills.map((s) => ({ skill: s.skill, industryDemand: s.d })),
    });
    programs.push(program);
  }
  console.log(`Seeded ${programs.length} training programs`);

  // ---------------- Employers ----------------
  const employerDefs = [
    "ABC Pvt Ltd", "XYZ Ltd", "Bharat Manufacturing Co", "Deccan Softworks", "Konkan Healthcare Services",
    "Maratha Auto Components", "Sahyadri Retail Group", "Vidarbha Textiles", "Pune Data Systems",
    "Nagpur Engineering Works", "Nashik AgroTech", "Thane Logistics Pvt Ltd", "Kolhapur Sugar Mills",
    "Solapur Weaving Co", "Sambhaji Digital Solutions",
  ];
  const employers = await Employer.insertMany(
    employerDefs.map((name, idx) => ({
      name,
      sector: pick(["IT", "Manufacturing", "Healthcare", "Retail", "Textiles", "Logistics"]),
      districtId: pick(districts)._id,
      contactEmail: `hr@${name.toLowerCase().replace(/[^a-z]/g, "")}-demo.example`,
      contactPhone: `97${randInt(10000000, 99999999)}`,
    }))
  );
  console.log(`Seeded ${employers.length} employers`);

  // ---------------- Government administrator login (email + password) ----------------
  const passwordHash = await bcrypt.hash("demo1234", 10);
  await User.insertMany([
    { name: "State Administrator", email: "admin@skilltrack-demo.example", passwordHash, role: "government", isVerified: true },
  ]);
  console.log("Seeded government administrator login (password: demo1234, no OTP needed for this pre-verified demo account)");

  // ---------------- Provider & Employer logins (govt-issued unique IDs) ----------------
  // In real usage a government admin issues these one at a time via
  // POST /api/auth/providers/issue. Here we bulk-generate one login per
  // seeded provider/employer so every record in the database is reachable.
  await Promise.all(
    providers.map((p, idx) =>
      User.create({
        name: `${p.name} Coordinator`,
        uniqueId: generateUniqueId("provider", idx + 1),
        passwordHash,
        role: "provider",
        linkedId: p._id,
        linkedModel: "Provider",
      })
    )
  );
  await Promise.all(
    employers.map((e, idx) =>
      User.create({
        name: `${e.name} HR`,
        uniqueId: generateUniqueId("employer", idx + 1),
        passwordHash,
        role: "employer",
        linkedId: e._id,
        linkedModel: "Employer",
      })
    )
  );
  console.log(`Seeded ${providers.length} provider logins and ${employers.length} employer logins (unique IDs, password: demo1234)`);

  // ---------------- Trainees + full longitudinal data ----------------
  const NON_PLACEMENT_REASONS = [
    "Technical Skill Gap", "Communication Gap", "Lack of Local Opportunities", "Salary Mismatch",
    "Relocation/Mobility Constraint", "Lack of Experience", "Further Education", "Personal Reasons", "Other",
  ];
  const EMPLOYMENT_TYPES = ["Full-time", "Part-time", "Contract"];
  const JOB_TITLES = ["Junior Developer", "Data Analyst Trainee", "Electrician", "CNC Machine Operator", "Digital Marketing Executive", "Welder", "Healthcare Assistant", "Automotive Technician", "Trainee Engineer", "Support Executive"];

  const totalTrainees = 42;
  let trainees = [];

  for (let i = 0; i < totalTrainees; i++) {
    const gender = rand() > 0.5 ? "Male" : "Female";
    const firstName = gender === "Male" ? pick(FIRST_NAMES_M) : pick(FIRST_NAMES_F);
    const lastName = pick(LAST_NAMES);
    const district = pick(districts);
    const program = pick(programs);
    const provider = providers.find((p) => String(p._id) === String(program.providerId));
    const age = randInt(19, 45);
    const startDate = monthsAgo(randInt(20, 30));
    const completionDate = new Date(startDate);
    completionDate.setDate(completionDate.getDate() + program.durationWeeks * 7);
    const attendancePct = randInt(65, 99);
    const assessmentScore = randInt(50, 98);
    const certified = attendancePct > 70 && assessmentScore > 55;

    const traineeCode = `MH-TR-${String(100000 + i)}`;

    const trainee = await Trainee.create({
      traineeCode,
      name: `${firstName} ${lastName}`,
      age,
      gender,
      districtId: district._id,
      urbanRural: rand() < district.urbanRuralMix.urbanPct / 100 ? "Urban" : "Rural",
      educationLevel: pick(["10th Pass", "12th Pass", "Graduate", "ITI/Diploma", "Postgraduate"]),
      contactPhone: `9${randInt(100000000, 999999999)}`,
      contactStatus: rand() > 0.9 ? "Not Reachable" : "Reachable",
      trainingHistory: [
        {
          programId: program._id,
          providerId: provider._id,
          startDate,
          completionDate: certified ? completionDate : undefined,
          attendancePct,
          assessmentScore,
          certified,
          certificationDate: certified ? completionDate : undefined,
        },
      ],
      currentOutcomeStatus: certified ? "Certified - Awaiting Follow-up" : "In Training",
    });
    trainees.push(trainee);

    // Consent
    const consentStatus = rand() < 0.85 ? "Given" : rand() < 0.5 ? "Pending" : "Revoked";
    await Consent.create({
      traineeId: trainee._id,
      status: consentStatus,
      grantedAt: consentStatus === "Given" ? completionDate : undefined,
      revokedAt: consentStatus === "Revoked" ? daysAgo(randInt(1, 60)) : undefined,
    });

    // Skill assessment (only for certified trainees, tied to their course's required skills)
    if (certified) {
      await SkillAssessment.create({
        traineeId: trainee._id,
        programId: program._id,
        assessedAt: completionDate,
        skills: program.requiredSkills.map((s) => ({
          skill: s.skill,
          // current level trends below industry demand, more so for lower assessment scores
          currentLevel: Math.max(10, Math.round(s.industryDemand - randInt(5, 35) - (100 - assessmentScore) * 0.15)),
        })),
      });
    }

    if (!certified) continue; // non-certified trainees skip follow-up/outcome generation

    // ---- Follow-up checkpoints ----
    const checkpoints = [
      { key: "3_month", months: 3 },
      { key: "6_month", months: 6 },
      { key: "12_month", months: 12 },
      { key: "18_month", months: 18 },
      { key: "24_month", months: 24 },
    ];

    // Decide this trainee's overall outcome arc up front so it stays consistent.
    const outcomeRoll = rand();
    let arc = "employed_stable";
    if (outcomeRoll < 0.55) arc = "employed_stable";
    else if (outcomeRoll < 0.63) arc = "employed_switched";
    else if (outcomeRoll < 0.72) arc = "self_employed";
    else if (outcomeRoll < 0.8) arc = "apprenticeship";
    else if (outcomeRoll < 0.93) arc = "unemployed";
    else arc = "further_education";

    let currentOutcomeDoc = null;
    let currentSalary = randInt(12, 20) * 1000;
    let employerA = pick(employers);
    let employerB = pick(employers);
    const now = new Date();

    for (const cp of checkpoints) {
      const dueDate = new Date(completionDate);
      dueDate.setMonth(dueDate.getMonth() + cp.months);
      if (dueDate > now) break; // future checkpoint hasn't come due yet

      const isOverdue = rand() < 0.06;
      const isUnreachable = rand() < 0.05;

      if (isUnreachable) {
        await FollowUp.create({ traineeId: trainee._id, checkpoint: cp.key, dueDate, status: "Not Reachable" });
        continue;
      }
      if (isOverdue) {
        await FollowUp.create({ traineeId: trainee._id, checkpoint: cp.key, dueDate, status: "Overdue" });
        continue;
      }

      // Build the outcome for this checkpoint based on the trainee's arc
      let outcomeType, payload = {}, currentStatusLabel;

      if (arc === "employed_stable") {
        outcomeType = "employed";
        currentStatusLabel = "Employed";
        if (cp.key !== "3_month") currentSalary = Math.round(currentSalary * (1 + randInt(3, 15) / 100));
        payload = {
          employerId: employerA._id,
          jobTitle: pick(JOB_TITLES),
          employmentType: pick(EMPLOYMENT_TYPES),
          workLocation: district.name,
          joiningDate: cp.key === "3_month" ? completionDate : undefined,
          monthlySalary: currentSalary,
        };
      } else if (arc === "employed_switched") {
        outcomeType = "employed";
        currentStatusLabel = "Employed";
        const switched = cp.key === "12_month" || cp.key === "18_month";
        if (switched) employerA = employerB;
        currentSalary = Math.round(currentSalary * (1 + randInt(switched ? 15 : 3, switched ? 30 : 12) / 100));
        payload = {
          employerId: employerA._id,
          jobTitle: pick(JOB_TITLES),
          employmentType: pick(EMPLOYMENT_TYPES),
          workLocation: district.name,
          joiningDate: cp.key === "3_month" ? completionDate : undefined,
          monthlySalary: currentSalary,
        };
      } else if (arc === "self_employed") {
        outcomeType = "self_employed";
        currentStatusLabel = "Self-Employed";
        payload = {
          businessType: pick(["Tailoring Unit", "Mobile Repair Shop", "Small Retail Store", "Catering Service", "Electrical Contracting"]),
          monthlyIncome: randInt(10, 28) * 1000,
          businessDurationMonths: cp.months,
        };
      } else if (arc === "apprenticeship") {
        outcomeType = "apprenticeship";
        currentStatusLabel = "Apprenticeship";
        payload = {
          organization: employerA.name,
          stipend: randInt(6, 12) * 1000,
          durationMonths: cp.months,
        };
      } else if (arc === "unemployed") {
        outcomeType = "unemployed";
        currentStatusLabel = "Unemployed";
        payload = {
          reason: pick(NON_PLACEMENT_REASONS),
          lookingForEmployment: true,
          skillsNeeded: [pick(program.requiredSkills).skill],
        };
      } else {
        outcomeType = "further_education";
        currentStatusLabel = "Further Education";
        payload = {};
      }

      const followUp = await FollowUp.create({
        traineeId: trainee._id,
        checkpoint: cp.key,
        dueDate,
        status: "Completed",
        completedAt: dueDate,
        response: { currentStatus: currentStatusLabel, notes: "" },
      });

      // Close the previous "current" outcome spell before opening a new one.
      if (currentOutcomeDoc) {
        currentOutcomeDoc.isCurrent = false;
        currentOutcomeDoc.endDate = dueDate;
        await currentOutcomeDoc.save();
      }

      const outcomeDoc = { traineeId: trainee._id, followUpId: followUp._id, outcomeType, source: "trainee", isCurrent: true, createdAt: dueDate };

      if (outcomeType === "employed") {
        Object.assign(outcomeDoc, {
          employerId: payload.employerId,
          jobTitle: payload.jobTitle,
          employmentType: payload.employmentType,
          workLocation: payload.workLocation,
          joiningDate: payload.joiningDate,
          salaryHistory: [{ monthlySalary: payload.monthlySalary, recordedAt: dueDate }],
        });
        // Verification: most get requested, most of those get resolved
        const verificationRoll = rand();
        if (verificationRoll < 0.75) {
          const confirmed = rand() < 0.85;
          outcomeDoc.verification = {
            status: confirmed ? "verified" : "failed",
            requestedAt: dueDate,
            respondedAt: new Date(dueDate.getTime() + 3 * 24 * 60 * 60 * 1000),
            employerNotes: confirmed ? "Confirmed by HR" : "Records do not match",
          };
          outcomeDoc.confidence = confirmed ? "high" : "low";
        } else {
          outcomeDoc.verification = { status: "pending", requestedAt: dueDate };
          outcomeDoc.confidence = "medium";
        }
      } else if (outcomeType === "self_employed") {
        outcomeDoc.selfEmployment = payload;
        outcomeDoc.verification = { status: "not_applicable" };
        outcomeDoc.confidence = "medium";
      } else if (outcomeType === "apprenticeship") {
        outcomeDoc.apprenticeship = payload;
        outcomeDoc.verification = { status: "not_applicable" };
        outcomeDoc.confidence = "medium";
      } else if (outcomeType === "unemployed") {
        outcomeDoc.unemployment = payload;
        outcomeDoc.verification = { status: "not_applicable" };
        outcomeDoc.confidence = "high";
      } else {
        outcomeDoc.verification = { status: "not_applicable" };
        outcomeDoc.confidence = "medium";
      }

      currentOutcomeDoc = await EmploymentOutcome.create(outcomeDoc);
      followUp.resultingOutcomeId = currentOutcomeDoc._id;
      await followUp.save();

      await trainee.updateOne({ currentOutcomeStatus: currentStatusLabel });
    }

    // Add a couple of future pending checkpoints so the Follow-up
    // Management screen always has something actionable to show.
    const lastCheckpointIdx = checkpoints.findIndex((cp) => {
      const d = new Date(completionDate);
      d.setMonth(d.getMonth() + cp.months);
      return d > now;
    });
    if (lastCheckpointIdx !== -1) {
      const cp = checkpoints[lastCheckpointIdx];
      const dueDate = new Date(completionDate);
      dueDate.setMonth(dueDate.getMonth() + cp.months);
      await FollowUp.create({ traineeId: trainee._id, checkpoint: cp.key, dueDate, status: "Pending" });
    }
  }
  console.log(`Seeded ${trainees.length} trainees with training history, follow-ups, outcomes and skill assessments`);

  // ---------------- Dedicated "golden path" demo trainee ----------------
  // The 42 trainees above are randomly generated, so whichever one happens to
  // match a name search could be anywhere in the journey (still in training,
  // unemployed, wrong provider, wrong employer, etc). That made it impossible
  // to reliably demo follow-ups, wage progression or employer verification.
  // This trainee is built by hand instead, so the four demo logins always
  // line up with each other and with a complete story:
  //   trainee login  -> Priya Deshmukh (has one open follow-up to submit)
  //   provider login -> TechSkill Academy (trains Priya)
  //   employer login -> ABC Pvt Ltd (has a pending verification for Priya)
  const demoProgram = programs[1]; // Data Analytics, run by TechSkill Academy
  const demoProvider = providers[1]; // TechSkill Academy (matches provider demo login)
  const demoEmployer = employers[0]; // ABC Pvt Ltd (matches employer demo login)
  const demoDistrict = dByName["Mumbai"];

  const demoStartDate = monthsAgo(20);
  const demoCompletionDate = new Date(demoStartDate);
  demoCompletionDate.setDate(demoCompletionDate.getDate() + demoProgram.durationWeeks * 7);

  const priya = await Trainee.create({
    traineeCode: `MH-TR-${String(100000 + totalTrainees)}`,
    name: "Priya Deshmukh",
    age: 24,
    gender: "Female",
    districtId: demoDistrict._id,
    urbanRural: "Urban",
    educationLevel: "Graduate",
    contactPhone: `9${randInt(100000000, 999999999)}`,
    contactStatus: "Reachable",
    trainingHistory: [
      {
        programId: demoProgram._id,
        providerId: demoProvider._id,
        startDate: demoStartDate,
        completionDate: demoCompletionDate,
        attendancePct: 92,
        assessmentScore: 88,
        certified: true,
        certificationDate: demoCompletionDate,
      },
    ],
    currentOutcomeStatus: "Employed",
  });
  trainees.push(priya);

  await Consent.create({ traineeId: priya._id, status: "Given", grantedAt: demoCompletionDate });

  await SkillAssessment.create({
    traineeId: priya._id,
    programId: demoProgram._id,
    assessedAt: demoCompletionDate,
    skills: demoProgram.requiredSkills.map((s) => ({
      skill: s.skill,
      currentLevel: Math.max(10, s.industryDemand - randInt(10, 25)),
    })),
  });

  // Three completed follow-ups (3 / 6 / 12 month), all at ABC Pvt Ltd with a
  // rising salary each time, so the profile page has a real wage-progression
  // chart to show. The 3 and 6 month outcomes are already employer-verified;
  // the 12 month (most recent / current) one is left "pending" on purpose so
  // the employer demo login has an actual request to confirm.
  const demoCheckpoints = [
    { key: "3_month", months: 3, salary: 18000, verified: true },
    { key: "6_month", months: 6, salary: 21000, verified: true },
    { key: "12_month", months: 12, salary: 26000, verified: false },
  ];

  let demoPreviousOutcome = null;
  for (const cp of demoCheckpoints) {
    const dueDate = new Date(demoCompletionDate);
    dueDate.setMonth(dueDate.getMonth() + cp.months);

    const followUp = await FollowUp.create({
      traineeId: priya._id,
      checkpoint: cp.key,
      dueDate,
      status: "Completed",
      completedAt: dueDate,
      response: { currentStatus: "Employed", notes: "" },
    });

    // Close the previous employment spell before opening the next one, same
    // as the main loop does for job switches/salary updates above.
    if (demoPreviousOutcome) {
      demoPreviousOutcome.isCurrent = false;
      demoPreviousOutcome.endDate = dueDate;
      await demoPreviousOutcome.save();
    }

    const outcomeDoc = {
      traineeId: priya._id,
      followUpId: followUp._id,
      outcomeType: "employed",
      source: "trainee",
      isCurrent: true,
      createdAt: dueDate,
      employerId: demoEmployer._id,
      jobTitle: "Data Analyst Trainee",
      employmentType: "Full-time",
      workLocation: demoDistrict.name,
      joiningDate: cp.key === "3_month" ? demoCompletionDate : undefined,
      salaryHistory: [{ monthlySalary: cp.salary, recordedAt: dueDate }],
      verification: cp.verified
        ? {
            status: "verified",
            requestedAt: dueDate,
            respondedAt: new Date(dueDate.getTime() + 3 * 24 * 60 * 60 * 1000),
            employerNotes: "Confirmed by HR",
          }
        : { status: "pending", requestedAt: dueDate },
      confidence: cp.verified ? "high" : "medium",
    };

    demoPreviousOutcome = await EmploymentOutcome.create(outcomeDoc);
    followUp.resultingOutcomeId = demoPreviousOutcome._id;
    await followUp.save();
  }

  // Open 18-month follow-up so the trainee demo login has something to fill
  // in, and Follow-up Management always has an actionable row for Priya.
  const demoOpenDueDate = new Date(demoCompletionDate);
  demoOpenDueDate.setMonth(demoOpenDueDate.getMonth() + 18);
  await FollowUp.create({ traineeId: priya._id, checkpoint: "18_month", dueDate: demoOpenDueDate, status: "Pending" });

  console.log("Seeded dedicated demo trainee 'Priya Deshmukh' (TechSkill Academy / ABC Pvt Ltd) with a pending verification and an open follow-up");

  // ---------------- Trainee logins (every trainee gets a unique ID) ----------------
  // Every trainee's own traineeCode (already globally unique) doubles as
  // their login uniqueId, so admins never have to hand out a separate code.
  await Promise.all(
    trainees.map((t) =>
      User.create({
        name: t.name,
        uniqueId: t.traineeCode,
        passwordHash,
        role: "trainee",
        linkedId: t._id,
        linkedModel: "Trainee",
      })
    )
  );
  console.log(`Seeded ${trainees.length} trainee logins (unique ID = trainee code, password: demo1234)`);

  // ---------------- Audit trail seed events ----------------
  await AuditLog.insertMany([
    { actorRole: "government", actorLabel: "Admin", action: "Seeded initial demo dataset", entityType: "System" },
    { actorRole: "system", actorLabel: "System", action: "Recomputed skill-gap analytics", entityType: "SkillGap" },
  ]);

  // ---------------- Skill gap aggregates ----------------
  await skillGapService.recomputeSkillGaps();
  console.log("Computed skill-gap aggregates");

  console.log("\nSeed complete.");
  console.log("All demo accounts use password: demo1234");
  console.log("  Government (email)   : admin@skilltrack-demo.example");
  console.log(`  Provider (unique ID) : ${generateUniqueId("provider", 2)}  (TechSkill Academy)`);
  console.log(`  Trainee (unique ID)  : ${priya.traineeCode}  (Priya Deshmukh)`);
  console.log(`  Employer (unique ID) : ${generateUniqueId("employer", 1)}  (ABC Pvt Ltd)`);

  await mongoose.disconnect();
  process.exit(0);
}

run().catch((err) => {
  console.error("Seed failed:", err);
  process.exit(1);
});
