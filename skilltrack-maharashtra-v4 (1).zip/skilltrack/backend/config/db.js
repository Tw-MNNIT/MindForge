const mongoose = require("mongoose");

/**
 * Connects to MongoDB using the URI in the environment.
 * This is the ONLY place that knows how the app talks to Mongo -
 * repositories below never open their own connections, which keeps
 * the door open for swapping to PostgreSQL later without touching
 * controllers/services/frontend.
 */
async function connectDB() {
  const uri = process.env.MONGODB_URI;

  if (!uri) {
    console.error(
      "MONGODB_URI is not set. Copy backend/.env.example to backend/.env and set it."
    );
    process.exit(1);
  }

  try {
    mongoose.set("strictQuery", true);
    await mongoose.connect(uri);
    console.log(`MongoDB connected -> ${mongoose.connection.host}/${mongoose.connection.name}`);
  } catch (err) {
    console.error("MongoDB connection error:", err.message);
    process.exit(1);
  }
}

module.exports = connectDB;
