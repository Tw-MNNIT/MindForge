const Trainee = require("../models/Trainee");

/**
 * All raw Mongo access for Trainee lives here. If the project ever
 * migrates to PostgreSQL, only this file (and its siblings in
 * /repositories) need to be rewritten — services/controllers/frontend
 * stay untouched because they only ever call these functions.
 */
const traineeRepository = {
  async create(data) {
    return Trainee.create(data);
  },

  async findById(id) {
    return Trainee.findById(id)
      .populate("districtId")
      .populate("trainingHistory.programId")
      .populate("trainingHistory.providerId");
  },

  async findByCode(code) {
    return Trainee.findOne({ traineeCode: code });
  },

  async list({ search, districtId, providerId, courseId, gender, status, page = 1, limit = 20 }) {
    const query = {};
    if (districtId) query.districtId = districtId;
    if (gender) query.gender = gender;
    if (status) query.currentOutcomeStatus = status;
    if (providerId) query["trainingHistory.providerId"] = providerId;
    if (courseId) query["trainingHistory.programId"] = courseId;
    if (search) {
      query.$or = [
        { name: { $regex: search, $options: "i" } },
        { traineeCode: { $regex: search, $options: "i" } },
      ];
    }

    const skip = (Number(page) - 1) * Number(limit);
    const [items, total] = await Promise.all([
      Trainee.find(query)
        .populate("districtId")
        .populate("trainingHistory.programId")
        .populate("trainingHistory.providerId")
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(Number(limit)),
      Trainee.countDocuments(query),
    ]);

    return { items, total, page: Number(page), limit: Number(limit) };
  },

  async updateOutcomeStatus(id, status) {
    return Trainee.findByIdAndUpdate(id, { currentOutcomeStatus: status }, { new: true });
  },

  async countAll() {
    return Trainee.countDocuments();
  },

  async countByDistrict() {
    return Trainee.aggregate([{ $group: { _id: "$districtId", count: { $sum: 1 } } }]);
  },

  async countByField(field) {
    return Trainee.aggregate([{ $group: { _id: `$${field}`, count: { $sum: 1 } } }]);
  },

  async findAllRaw() {
    return Trainee.find({});
  },

  // Lightweight fetch (just what's needed for a credentials list) —
  // optionally scoped to one provider so a provider only sees/downloads
  // the login list for their own trainees.
  async listForCredentials(providerId) {
    const query = {};
    if (providerId) query["trainingHistory.providerId"] = providerId;
    return Trainee.find(query).select("name traineeCode").sort({ name: 1 }).lean();
  },
};

module.exports = traineeRepository;
