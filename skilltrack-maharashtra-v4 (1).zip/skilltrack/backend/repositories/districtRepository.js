const District = require("../models/District");

const districtRepository = {
  async create(data) {
    return District.create(data);
  },
  async findById(id) {
    return District.findById(id);
  },
  async list() {
    return District.find({}).sort({ name: 1 });
  },
};

module.exports = districtRepository;
