const User = require("../models/User");

const userRepository = {
  async create(data) {
    return User.create(data);
  },
  async findByEmail(email) {
    if (!email) return null;
    return User.findOne({ email: email.toLowerCase() });
  },
  async findByUniqueId(uniqueId) {
    if (!uniqueId) return null;
    return User.findOne({ uniqueId: uniqueId.toUpperCase() });
  },
  // Accepts either an email (government) or a uniqueId (provider/trainee/employer)
  async findByIdentifier(identifier) {
    if (!identifier) return null;
    const trimmed = identifier.trim();
    if (trimmed.includes("@")) return User.findOne({ email: trimmed.toLowerCase() });
    return User.findOne({ uniqueId: trimmed.toUpperCase() });
  },
  async findById(id) {
    return User.findById(id);
  },
  async countByRole(role) {
    return User.countDocuments({ role });
  },
  async list() {
    return User.find({}).select("-passwordHash");
  },
  async updateProfile(id, { name, themePreference }) {
    const update = {};
    if (name) update.name = name;
    if (themePreference) update.themePreference = themePreference;
    return User.findByIdAndUpdate(id, update, { new: true }).select("-passwordHash");
  },
};

module.exports = userRepository;
