const AuditLog = require("../models/AuditLog");

const auditLogRepository = {
  async create(data) {
    return AuditLog.create(data);
  },
  async list(limit = 50) {
    return AuditLog.find({}).sort({ createdAt: -1 }).limit(limit);
  },
};

module.exports = auditLogRepository;
