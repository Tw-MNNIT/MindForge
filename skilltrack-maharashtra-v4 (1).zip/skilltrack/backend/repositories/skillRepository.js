const SkillAssessment = require("../models/SkillAssessment");
const SkillGap = require("../models/SkillGap");

const skillRepository = {
  async createAssessment(data) {
    return SkillAssessment.create(data);
  },
  async findAssessmentsByProgram(programId) {
    return SkillAssessment.find({ programId });
  },
  async findAllAssessments() {
    return SkillAssessment.find({});
  },
  async upsertGap(filter, data) {
    return SkillGap.findOneAndUpdate(filter, data, { upsert: true, new: true });
  },
  async listGaps({ programId, districtId } = {}) {
    const query = {};
    if (programId) query.programId = programId;
    if (districtId) query.districtId = districtId;
    return SkillGap.find(query).populate("programId").sort({ gap: -1 });
  },
  async clearGaps() {
    return SkillGap.deleteMany({});
  },
};

module.exports = skillRepository;
