const Provider = require("../models/Provider");

const providerRepository = {
  async create(data) {
    return Provider.create(data);
  },
  async findById(id) {
    return Provider.findById(id).populate("districtId");
  },
  async list() {
    return Provider.find({}).populate("districtId").sort({ name: 1 });
  },
};

module.exports = providerRepository;
