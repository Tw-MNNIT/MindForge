const TrainingProgram = require("../models/TrainingProgram");

const programRepository = {
  async create(data) {
    return TrainingProgram.create(data);
  },
  async findById(id) {
    return TrainingProgram.findById(id).populate("providerId");
  },
  async list() {
    return TrainingProgram.find({}).populate("providerId").sort({ name: 1 });
  },
};

module.exports = programRepository;
