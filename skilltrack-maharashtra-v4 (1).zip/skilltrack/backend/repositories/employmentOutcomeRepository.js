const EmploymentOutcome = require("../models/EmploymentOutcome");

const employmentOutcomeRepository = {
  async create(data) {
    return EmploymentOutcome.create(data);
  },

  async findById(id) {
    return EmploymentOutcome.findById(id).populate("employerId").populate("traineeId");
  },

  async findByTrainee(traineeId) {
    return EmploymentOutcome.find({ traineeId })
      .populate("employerId")
      .sort({ createdAt: 1 });
  },

  async findCurrentByTrainee(traineeId) {
    return EmploymentOutcome.findOne({ traineeId, isCurrent: true }).sort({ createdAt: -1 });
  },

  async endPreviousCurrent(traineeId) {
    return EmploymentOutcome.updateMany(
      { traineeId, isCurrent: true },
      { isCurrent: false, endDate: new Date() }
    );
  },

  async addSalaryRecord(outcomeId, monthlySalary) {
    return EmploymentOutcome.findByIdAndUpdate(
      outcomeId,
      { $push: { salaryHistory: { monthlySalary, recordedAt: new Date() } } },
      { new: true }
    );
  },

  async updateVerification(outcomeId, verificationUpdate) {
    return EmploymentOutcome.findByIdAndUpdate(
      outcomeId,
      { $set: { verification: verificationUpdate } },
      { new: true }
    ).populate("employerId").populate("traineeId");
  },

  async findPendingVerifications(employerId) {
    const query = { "verification.status": "pending", outcomeType: "employed" };
    if (employerId) query.employerId = employerId;
    return EmploymentOutcome.find(query).populate("traineeId").populate("employerId").sort({ createdAt: -1 });
  },

  async findResolvedVerifications(employerId) {
    const query = { "verification.status": { $in: ["verified", "failed"] }, outcomeType: "employed" };
    if (employerId) query.employerId = employerId;
    return EmploymentOutcome.find(query)
      .populate("traineeId")
      .populate("employerId")
      .sort({ "verification.respondedAt": -1 });
  },

  async findAllRaw() {
    return EmploymentOutcome.find({});
  },

  async countByType() {
    return EmploymentOutcome.aggregate([
      { $match: { isCurrent: true } },
      { $group: { _id: "$outcomeType", count: { $sum: 1 } } },
    ]);
  },

  async countByVerificationStatus() {
    return EmploymentOutcome.aggregate([
      { $match: { outcomeType: "employed" } },
      { $group: { _id: "$verification.status", count: { $sum: 1 } } },
    ]);
  },
};

module.exports = employmentOutcomeRepository;
