const Employer = require("../models/Employer");

const employerRepository = {
  async create(data) {
    return Employer.create(data);
  },
  async findById(id) {
    return Employer.findById(id).populate("districtId");
  },
  async list() {
    return Employer.find({}).populate("districtId").sort({ name: 1 });
  },
};

module.exports = employerRepository;
