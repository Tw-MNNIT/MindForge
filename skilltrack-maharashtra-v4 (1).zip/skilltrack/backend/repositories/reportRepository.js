const Report = require("../models/Report");

const reportRepository = {
  async create(data) {
    return Report.create(data);
  },
  async findByTrainee(traineeId) {
    return Report.find({ traineeId }).sort({ createdAt: -1 });
  },
  async findLatestByTrainee(traineeId) {
    return Report.findOne({ traineeId }).sort({ createdAt: -1 });
  },
};

module.exports = reportRepository;
