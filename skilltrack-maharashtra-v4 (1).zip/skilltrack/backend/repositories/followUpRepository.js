const FollowUp = require("../models/FollowUp");

const followUpRepository = {
  async create(data) {
    return FollowUp.create(data);
  },

  async findById(id) {
    return FollowUp.findById(id).populate("traineeId");
  },

  async findByTrainee(traineeId) {
    return FollowUp.find({ traineeId }).sort({ dueDate: 1 });
  },

  async list({ status, checkpoint, traineeId, page = 1, limit = 20 }) {
    const query = {};
    if (status) query.status = status;
    if (checkpoint) query.checkpoint = checkpoint;
    if (traineeId) query.traineeId = traineeId;
    const skip = (Number(page) - 1) * Number(limit);
    const [items, total] = await Promise.all([
      FollowUp.find(query)
        .populate("traineeId")
        .sort({ dueDate: 1 })
        .skip(skip)
        .limit(Number(limit)),
      FollowUp.countDocuments(query),
    ]);
    return { items, total, page: Number(page), limit: Number(limit) };
  },

  async markReminderSent(id) {
    return FollowUp.findByIdAndUpdate(id, { reminderSentAt: new Date() }, { new: true });
  },

  async submitResponse(id, { currentStatus, notes, resultingOutcomeId }) {
    return FollowUp.findByIdAndUpdate(
      id,
      {
        status: "Completed",
        completedAt: new Date(),
        response: { currentStatus, notes },
        resultingOutcomeId,
      },
      { new: true }
    );
  },

  async countByStatus() {
    return FollowUp.aggregate([{ $group: { _id: "$status", count: { $sum: 1 } } }]);
  },
};

module.exports = followUpRepository;
