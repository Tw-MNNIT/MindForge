const Trainee = require("../models/Trainee");
const EmploymentOutcome = require("../models/EmploymentOutcome");
const FollowUp = require("../models/FollowUp");
const District = require("../models/District");
const Provider = require("../models/Provider");
const TrainingProgram = require("../models/TrainingProgram");

/**
 * Cross-collection aggregation queries for the analytics dashboards.
 * Isolated here (rather than scattered across controllers) so a future
 * PostgreSQL migration only needs equivalent SQL views/queries written
 * once, in one place.
 */
const analyticsRepository = {
  async totalTrainees() {
    return Trainee.countDocuments();
  },

  async totalCertified() {
    return Trainee.countDocuments({ "trainingHistory.certified": true });
  },

  async currentOutcomeCounts() {
    const rows = await Trainee.aggregate([
      { $group: { _id: "$currentOutcomeStatus", count: { $sum: 1 } } },
    ]);
    return rows.reduce((acc, r) => ({ ...acc, [r._id]: r.count }), {});
  },

  async verifiedPlacementCount() {
    return EmploymentOutcome.countDocuments({
      outcomeType: "employed",
      "verification.status": "verified",
    });
  },

  async averageCurrentSalary() {
    const rows = await EmploymentOutcome.aggregate([
      { $match: { outcomeType: "employed", isCurrent: true, salaryHistory: { $ne: [] } } },
      { $addFields: { latestSalary: { $arrayElemAt: ["$salaryHistory.monthlySalary", -1] } } },
      { $group: { _id: null, avgSalary: { $avg: "$latestSalary" } } },
    ]);
    return rows[0]?.avgSalary ? Math.round(rows[0].avgSalary) : 0;
  },

  async selfEmploymentCount() {
    return EmploymentOutcome.countDocuments({ outcomeType: "self_employed", isCurrent: true });
  },

  async followUpResponseRate() {
    const [total, completed] = await Promise.all([
      FollowUp.countDocuments(),
      FollowUp.countDocuments({ status: "Completed" }),
    ]);
    return total ? Math.round((completed / total) * 1000) / 10 : 0;
  },

  async retentionRate(months) {
    // "Retained" = still current AND joined at least `months` ago.
    const cutoff = new Date();
    cutoff.setMonth(cutoff.getMonth() - months);
    const [everEmployedAtCutoff, stillEmployedAtCutoff] = await Promise.all([
      EmploymentOutcome.countDocuments({ outcomeType: "employed", joiningDate: { $lte: cutoff } }),
      EmploymentOutcome.countDocuments({
        outcomeType: "employed",
        joiningDate: { $lte: cutoff },
        isCurrent: true,
      }),
    ]);
    return everEmployedAtCutoff
      ? Math.round((stillEmployedAtCutoff / everEmployedAtCutoff) * 1000) / 10
      : 0;
  },

  async nonPlacementReasons() {
    const rows = await EmploymentOutcome.aggregate([
      { $match: { outcomeType: "unemployed", isCurrent: true } },
      { $group: { _id: "$unemployment.reason", count: { $sum: 1 } } },
      { $sort: { count: -1 } },
    ]);
    return rows.map((r) => ({ reason: r._id || "Other", count: r.count }));
  },

  async employmentTrendByMonth(monthsBack = 12) {
    const since = new Date();
    since.setMonth(since.getMonth() - monthsBack);
    const rows = await EmploymentOutcome.aggregate([
      { $match: { createdAt: { $gte: since } } },
      {
        $group: {
          _id: { year: { $year: "$createdAt" }, month: { $month: "$createdAt" }, type: "$outcomeType" },
          count: { $sum: 1 },
        },
      },
      { $sort: { "_id.year": 1, "_id.month": 1 } },
    ]);
    return rows;
  },

  async districtPerformance() {
    const districts = await District.find({});
    const results = [];
    for (const d of districts) {
      const trainees = await Trainee.find({ districtId: d._id });
      const traineeIds = trainees.map((t) => t._id);
      const completed = trainees.filter((t) =>
        t.trainingHistory.some((th) => th.certified)
      ).length;
      const employedCount = await EmploymentOutcome.countDocuments({
        traineeId: { $in: traineeIds },
        outcomeType: { $in: ["employed", "self_employed", "apprenticeship"] },
        isCurrent: true,
      });
      const retained = await EmploymentOutcome.countDocuments({
        traineeId: { $in: traineeIds },
        outcomeType: "employed",
        isCurrent: true,
      });
      const salaryAgg = await EmploymentOutcome.aggregate([
        { $match: { traineeId: { $in: traineeIds }, outcomeType: "employed", isCurrent: true } },
        { $addFields: { latestSalary: { $arrayElemAt: ["$salaryHistory.monthlySalary", -1] } } },
        { $group: { _id: null, avg: { $avg: "$latestSalary" } } },
      ]);

      results.push({
        district: d.name,
        districtId: d._id,
        trainees: trainees.length,
        completed,
        placementRate: trainees.length ? Math.round((employedCount / trainees.length) * 1000) / 10 : 0,
        retentionRate: employedCount ? Math.round((retained / employedCount) * 1000) / 10 : 0,
        avgSalary: salaryAgg[0]?.avg ? Math.round(salaryAgg[0].avg) : 0,
      });
    }
    return results;
  },

  async providerPerformance() {
    const providers = await Provider.find({}).populate("districtId");
    const results = [];
    for (const p of providers) {
      const trainees = await Trainee.find({ "trainingHistory.providerId": p._id });
      const traineeIds = trainees.map((t) => t._id);
      const completed = trainees.filter((t) =>
        t.trainingHistory.some((th) => String(th.providerId) === String(p._id) && th.certified)
      ).length;
      const employedCount = await EmploymentOutcome.countDocuments({
        traineeId: { $in: traineeIds },
        outcomeType: { $in: ["employed", "self_employed", "apprenticeship"] },
        isCurrent: true,
      });
      const verifiedCount = await EmploymentOutcome.countDocuments({
        traineeId: { $in: traineeIds },
        outcomeType: "employed",
        "verification.status": "verified",
      });
      const employedTotal = await EmploymentOutcome.countDocuments({
        traineeId: { $in: traineeIds },
        outcomeType: "employed",
      });
      const salaryAgg = await EmploymentOutcome.aggregate([
        { $match: { traineeId: { $in: traineeIds }, outcomeType: "employed", isCurrent: true } },
        { $addFields: { latestSalary: { $arrayElemAt: ["$salaryHistory.monthlySalary", -1] } } },
        { $group: { _id: null, avg: { $avg: "$latestSalary" } } },
      ]);
      const followUpTotal = await FollowUp.countDocuments({ traineeId: { $in: traineeIds } });
      const followUpDone = await FollowUp.countDocuments({
        traineeId: { $in: traineeIds },
        status: "Completed",
      });

      results.push({
        provider: p.name,
        providerId: p._id,
        district: p.districtId?.name,
        trainees: trainees.length,
        completionRate: trainees.length ? Math.round((completed / trainees.length) * 1000) / 10 : 0,
        placementRate: trainees.length ? Math.round((employedCount / trainees.length) * 1000) / 10 : 0,
        avgSalary: salaryAgg[0]?.avg ? Math.round(salaryAgg[0].avg) : 0,
        verificationRate: employedTotal ? Math.round((verifiedCount / employedTotal) * 1000) / 10 : 0,
        followUpResponseRate: followUpTotal ? Math.round((followUpDone / followUpTotal) * 1000) / 10 : 0,
      });
    }
    return results;
  },

  async coursePerformance() {
    const programs = await TrainingProgram.find({}).populate("providerId");
    const results = [];
    for (const prog of programs) {
      const trainees = await Trainee.find({ "trainingHistory.programId": prog._id });
      const traineeIds = trainees.map((t) => t._id);
      const completed = trainees.filter((t) =>
        t.trainingHistory.some((th) => String(th.programId) === String(prog._id) && th.certified)
      ).length;
      const employedCount = await EmploymentOutcome.countDocuments({
        traineeId: { $in: traineeIds },
        outcomeType: { $in: ["employed", "self_employed", "apprenticeship"] },
        isCurrent: true,
      });
      const retained = await EmploymentOutcome.countDocuments({
        traineeId: { $in: traineeIds },
        outcomeType: "employed",
        isCurrent: true,
      });
      const salaryAgg = await EmploymentOutcome.aggregate([
        { $match: { traineeId: { $in: traineeIds }, outcomeType: "employed", isCurrent: true } },
        { $addFields: { latestSalary: { $arrayElemAt: ["$salaryHistory.monthlySalary", -1] } } },
        { $group: { _id: null, avg: { $avg: "$latestSalary" } } },
      ]);
      const dropout = trainees.length - completed;

      results.push({
        course: prog.name,
        programId: prog._id,
        provider: prog.providerId?.name,
        enrollment: trainees.length,
        completion: completed,
        placementRate: trainees.length ? Math.round((employedCount / trainees.length) * 1000) / 10 : 0,
        retentionRate: employedCount ? Math.round((retained / employedCount) * 1000) / 10 : 0,
        avgSalary: salaryAgg[0]?.avg ? Math.round(salaryAgg[0].avg) : 0,
        dropout,
      });
    }
    return results;
  },

  async demographics() {
    const byGender = await Trainee.aggregate([{ $group: { _id: "$gender", count: { $sum: 1 } } }]);
    const byEducation = await Trainee.aggregate([
      { $group: { _id: "$educationLevel", count: { $sum: 1 } } },
    ]);
    const byUrbanRural = await Trainee.aggregate([
      { $group: { _id: "$urbanRural", count: { $sum: 1 } } },
    ]);

    // Employment rate by age band
    const trainees = await Trainee.find({});
    const bands = [
      { label: "18-21", min: 18, max: 21 },
      { label: "22-25", min: 22, max: 25 },
      { label: "26-30", min: 26, max: 30 },
      { label: "31-40", min: 31, max: 40 },
      { label: "40+", min: 41, max: 200 },
    ];
    const ageBandStats = [];
    for (const band of bands) {
      const inBand = trainees.filter((t) => t.age >= band.min && t.age <= band.max);
      const ids = inBand.map((t) => t._id);
      const employed = await EmploymentOutcome.countDocuments({
        traineeId: { $in: ids },
        outcomeType: { $in: ["employed", "self_employed", "apprenticeship"] },
        isCurrent: true,
      });
      ageBandStats.push({
        band: band.label,
        trainees: inBand.length,
        employmentRate: inBand.length ? Math.round((employed / inBand.length) * 1000) / 10 : 0,
      });
    }

    return { byGender, byEducation, byUrbanRural, ageBandStats };
  },

  async outcomeDistribution() {
    const rows = await EmploymentOutcome.aggregate([
      { $match: { isCurrent: true } },
      { $group: { _id: "$outcomeType", count: { $sum: 1 } } },
    ]);
    return rows;
  },
};

module.exports = analyticsRepository;
