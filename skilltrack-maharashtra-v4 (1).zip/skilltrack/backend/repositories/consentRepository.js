const Consent = require("../models/Consent");

const consentRepository = {
  async create(data) {
    return Consent.create(data);
  },
  async findByTrainee(traineeId) {
    return Consent.findOne({ traineeId });
  },
  async updateStatus(traineeId, status) {
    const update = { status };
    if (status === "Given") update.grantedAt = new Date();
    if (status === "Revoked") update.revokedAt = new Date();
    return Consent.findOneAndUpdate({ traineeId }, update, { upsert: true, new: true });
  },
  async countByStatus() {
    return Consent.aggregate([{ $group: { _id: "$status", count: { $sum: 1 } } }]);
  },
};

module.exports = consentRepository;
