const mongoose = require("mongoose");

const EmployerSchema = new mongoose.Schema(
  {
    name: { type: String, required: true },
    sector: { type: String },
    districtId: { type: mongoose.Schema.Types.ObjectId, ref: "District" },
    contactEmail: { type: String },
    contactPhone: { type: String },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Employer", EmployerSchema);
