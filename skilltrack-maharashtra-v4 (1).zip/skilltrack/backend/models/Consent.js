const mongoose = require("mongoose");

const ConsentSchema = new mongoose.Schema(
  {
    traineeId: { type: mongoose.Schema.Types.ObjectId, ref: "Trainee", required: true, unique: true },
    status: {
      type: String,
      enum: ["Given", "Pending", "Revoked"],
      default: "Pending",
    },
    grantedAt: { type: Date },
    revokedAt: { type: Date },
    scope: {
      type: [String],
      default: ["employment_followup", "employer_verification", "analytics_aggregation"],
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Consent", ConsentSchema);
