const mongoose = require("mongoose");

const FollowUpSchema = new mongoose.Schema(
  {
    traineeId: { type: mongoose.Schema.Types.ObjectId, ref: "Trainee", required: true },
    checkpoint: {
      type: String,
      enum: ["3_month", "6_month", "12_month", "18_month", "24_month"],
      required: true,
    },
    dueDate: { type: Date, required: true },
    status: {
      type: String,
      enum: ["Pending", "Completed", "Overdue", "Not Reachable"],
      default: "Pending",
    },
    completedAt: { type: Date },
    reminderSentAt: { type: Date },
    // The short structured answers the trainee gave for this checkpoint,
    // kept here even after an EmploymentOutcome is created from it so the
    // raw follow-up response is auditable on its own.
    response: {
      currentStatus: {
        type: String,
        enum: ["Employed", "Self-Employed", "Apprenticeship", "Unemployed", "Further Education"],
      },
      notes: { type: String },
    },
    resultingOutcomeId: { type: mongoose.Schema.Types.ObjectId, ref: "EmploymentOutcome" },
  },
  { timestamps: true }
);

module.exports = mongoose.model("FollowUp", FollowUpSchema);
