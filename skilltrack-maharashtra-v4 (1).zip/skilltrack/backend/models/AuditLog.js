const mongoose = require("mongoose");

const AuditLogSchema = new mongoose.Schema(
  {
    actorRole: {
      type: String,
      enum: ["government", "provider", "trainee", "employer", "system"],
      required: true,
    },
    actorLabel: { type: String }, // e.g. "Admin", "ABC Pvt Ltd", "Trainee MH-TR-000123"
    action: { type: String, required: true }, // human-readable description
    entityType: { type: String }, // "Trainee" | "EmploymentOutcome" | "FollowUp" | ...
    entityId: { type: mongoose.Schema.Types.ObjectId },
  },
  { timestamps: true }
);

module.exports = mongoose.model("AuditLog", AuditLogSchema);
