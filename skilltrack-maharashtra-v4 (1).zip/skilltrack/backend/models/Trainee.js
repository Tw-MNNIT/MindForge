const mongoose = require("mongoose");

const TrainingHistorySchema = new mongoose.Schema(
  {
    programId: { type: mongoose.Schema.Types.ObjectId, ref: "TrainingProgram", required: true },
    providerId: { type: mongoose.Schema.Types.ObjectId, ref: "Provider", required: true },
    startDate: { type: Date, required: true },
    completionDate: { type: Date },
    attendancePct: { type: Number, min: 0, max: 100 },
    assessmentScore: { type: Number, min: 0, max: 100 },
    certified: { type: Boolean, default: false },
    certificationDate: { type: Date },
  },
  { _id: true }
);

const TraineeSchema = new mongoose.Schema(
  {
    traineeCode: { type: String, required: true, unique: true }, // e.g. MH-TR-000123
    name: { type: String, required: true },
    age: { type: Number },
    gender: { type: String, enum: ["Male", "Female", "Other"] },
    districtId: { type: mongoose.Schema.Types.ObjectId, ref: "District", required: true },
    urbanRural: { type: String, enum: ["Urban", "Rural"], default: "Urban" },
    educationLevel: {
      type: String,
      enum: ["Below 10th", "10th Pass", "12th Pass", "Graduate", "Postgraduate", "ITI/Diploma"],
    },
    contactPhone: { type: String },
    contactStatus: {
      type: String,
      enum: ["Reachable", "Not Reachable", "Unknown"],
      default: "Reachable",
    },
    trainingHistory: [TrainingHistorySchema],

    // Current summarized outcome status. This is a cache updated whenever a
    // new EmploymentOutcome is recorded — the *source of truth* for the
    // longitudinal timeline is still the EmploymentOutcome/FollowUp
    // collections, not this field.
    currentOutcomeStatus: {
      type: String,
      enum: [
        "In Training",
        "Certified - Awaiting Follow-up",
        "Employed",
        "Self-Employed",
        "Apprenticeship",
        "Unemployed",
        "Further Education",
        "Not Reachable",
      ],
      default: "In Training",
    },
  },
  { timestamps: true }
);

TraineeSchema.index({ name: "text", traineeCode: "text" });

module.exports = mongoose.model("Trainee", TraineeSchema);
