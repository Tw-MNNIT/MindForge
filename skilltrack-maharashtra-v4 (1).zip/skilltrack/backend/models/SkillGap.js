const mongoose = require("mongoose");

/**
 * Materialized/cached skill-gap aggregate per course, refreshed by
 * services/skillGapService.js from SkillAssessment + TrainingProgram data.
 * Kept as its own collection (rather than recomputing on every dashboard
 * load) purely for read performance on the analytics screens.
 */
const SkillGapSchema = new mongoose.Schema(
  {
    programId: { type: mongoose.Schema.Types.ObjectId, ref: "TrainingProgram", required: true },
    districtId: { type: mongoose.Schema.Types.ObjectId, ref: "District" },
    skill: { type: String, required: true },
    industryDemand: { type: Number, min: 0, max: 100, required: true },
    currentLevel: { type: Number, min: 0, max: 100, required: true },
    gap: { type: Number, min: 0, max: 100, required: true },
    sampleSize: { type: Number, default: 0 },
    computedAt: { type: Date, default: Date.now },
  },
  { timestamps: true }
);

module.exports = mongoose.model("SkillGap", SkillGapSchema);
