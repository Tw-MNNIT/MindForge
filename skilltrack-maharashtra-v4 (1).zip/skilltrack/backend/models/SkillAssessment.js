const mongoose = require("mongoose");

/**
 * Snapshot of a trainee's measured skill levels at/after certification.
 * Compared against TrainingProgram.requiredSkills (industry demand) to
 * produce the skill-gap analytics — this comparison is a deterministic
 * calculation for the prototype (see services/skillGapService.js), with
 * the door left open for the team's real ML model at POST /api/ml/skill-gap.
 */
const SkillAssessmentSchema = new mongoose.Schema(
  {
    traineeId: { type: mongoose.Schema.Types.ObjectId, ref: "Trainee", required: true },
    programId: { type: mongoose.Schema.Types.ObjectId, ref: "TrainingProgram", required: true },
    assessedAt: { type: Date, default: Date.now },
    skills: [
      {
        skill: { type: String, required: true },
        currentLevel: { type: Number, min: 0, max: 100, required: true },
      },
    ],
  },
  { timestamps: true }
);

module.exports = mongoose.model("SkillAssessment", SkillAssessmentSchema);
