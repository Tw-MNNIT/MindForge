const mongoose = require("mongoose");

/**
 * Auth user for all four roles.
 *
 * - government: logs in with email + password. Must register (with OTP
 *   email verification) before first login.
 * - provider / trainee / employer: log in with a `uniqueId` (issued when
 *   their profile is created — by the government admin for providers, by
 *   the seed/admin flow for trainees & employers) + password. No self
 *   signup for these three roles.
 */
const UserSchema = new mongoose.Schema(
  {
    name: { type: String, required: true },
    email: { type: String, unique: true, sparse: true, lowercase: true }, // government only
    uniqueId: { type: String, unique: true, sparse: true }, // provider/trainee/employer login id
    passwordHash: { type: String, required: true },
    role: {
      type: String,
      enum: ["government", "provider", "trainee", "employer"],
      required: true,
    },
    linkedId: { type: mongoose.Schema.Types.ObjectId, refPath: "linkedModel" },
    linkedModel: {
      type: String,
      enum: ["Provider", "Trainee", "Employer"],
    },

    // Government self-registration + OTP verification
    isVerified: { type: Boolean, default: true },
    otp: { type: String },
    otpExpiry: { type: Date },

    // Account settings
    themePreference: { type: String, enum: ["dark", "light"], default: "dark" },
  },
  { timestamps: true }
);

module.exports = mongoose.model("User", UserSchema);
