const mongoose = require("mongoose");

const TrainingProgramSchema = new mongoose.Schema(
  {
    name: { type: String, required: true }, // e.g. "Full Stack Development"
    sector: { type: String }, // IT, Manufacturing, Healthcare, etc.
    durationWeeks: { type: Number, default: 12 },
    providerId: { type: mongoose.Schema.Types.ObjectId, ref: "Provider", required: true },
    // Industry skill requirements used by the skill-gap comparison.
    // Each entry is a skill name -> required proficiency (0-100).
    requiredSkills: [
      {
        skill: { type: String, required: true },
        industryDemand: { type: Number, min: 0, max: 100, required: true },
      },
    ],
  },
  { timestamps: true }
);

module.exports = mongoose.model("TrainingProgram", TrainingProgramSchema);
