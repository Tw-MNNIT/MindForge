const mongoose = require("mongoose");

const ProviderSchema = new mongoose.Schema(
  {
    name: { type: String, required: true },
    districtId: { type: mongoose.Schema.Types.ObjectId, ref: "District" },
    empanelmentId: { type: String }, // fictional govt empanelment code
    contactEmail: { type: String },
    contactPhone: { type: String },
    active: { type: Boolean, default: true },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Provider", ProviderSchema);
