const mongoose = require("mongoose");

/**
 * One EmploymentOutcome document represents ONE engagement/spell in a
 * trainee's post-training life (a job, a business, an apprenticeship, or a
 * declared spell of unemployment). A trainee can have MANY of these over
 * time — job switches create a new document rather than overwriting the
 * old one, which is what lets us reconstruct the longitudinal timeline
 * and wage-progression chart described in the spec.
 */
const EmploymentOutcomeSchema = new mongoose.Schema(
  {
    traineeId: { type: mongoose.Schema.Types.ObjectId, ref: "Trainee", required: true },
    followUpId: { type: mongoose.Schema.Types.ObjectId, ref: "FollowUp" },

    outcomeType: {
      type: String,
      enum: ["employed", "self_employed", "apprenticeship", "unemployed", "further_education"],
      required: true,
    },

    // --- employed ---
    employerId: { type: mongoose.Schema.Types.ObjectId, ref: "Employer" },
    jobTitle: { type: String },
    employmentType: {
      type: String,
      enum: ["Full-time", "Part-time", "Contract", "Daily Wage"],
    },
    workLocation: { type: String },
    joiningDate: { type: Date },
    endDate: { type: Date }, // set when this spell ends (job switch / job loss)
    isCurrent: { type: Boolean, default: true },
    salaryHistory: [
      {
        recordedAt: { type: Date, default: Date.now },
        monthlySalary: { type: Number },
      },
    ],

    // --- self-employed ---
    selfEmployment: {
      businessType: { type: String },
      monthlyIncome: { type: Number },
      businessDurationMonths: { type: Number },
    },

    // --- apprenticeship ---
    apprenticeship: {
      organization: { type: String },
      stipend: { type: Number },
      durationMonths: { type: Number },
      convertedToEmployment: { type: Boolean, default: false },
    },

    // --- unemployed ---
    unemployment: {
      reason: {
        type: String,
        enum: [
          "Technical Skill Gap",
          "Communication Gap",
          "Lack of Local Opportunities",
          "Salary Mismatch",
          "Relocation/Mobility Constraint",
          "Lack of Experience",
          "Further Education",
          "Personal Reasons",
          "Other",
        ],
      },
      lookingForEmployment: { type: Boolean, default: true },
      skillsNeeded: [{ type: String }],
    },

    // Where did this report come from, and has it been checked?
    source: { type: String, enum: ["trainee", "employer", "provider"], default: "trainee" },
    verification: {
      status: {
        type: String,
        enum: ["not_applicable", "pending", "verified", "failed"],
        default: "pending",
      },
      requestedAt: { type: Date },
      respondedAt: { type: Date },
      employerNotes: { type: String },
    },
    // Derived confidence — trainee-only report vs employer-agreeing report.
    confidence: {
      type: String,
      enum: ["low", "medium", "high"],
      default: "medium",
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model("EmploymentOutcome", EmploymentOutcomeSchema);
