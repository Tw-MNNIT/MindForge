const mongoose = require("mongoose");

// A provider-authored report for one trainee, replacing the raw
// "assessment score" number with a readable write-up the trainee can view.
// Either aiContent (Gemini-drafted markdown) or fileUrl (Multer/Cloudinary
// upload) or both may be present.
const ReportSchema = new mongoose.Schema(
  {
    traineeId: { type: mongoose.Schema.Types.ObjectId, ref: "Trainee", required: true },
    providerId: { type: mongoose.Schema.Types.ObjectId, ref: "Provider", required: true },
    title: { type: String, default: "Training Report" },
    aiContent: { type: String }, // markdown text drafted by Gemini
    fileUrl: { type: String }, // Cloudinary secure URL, if a file was attached
    fileName: { type: String },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Report", ReportSchema);
