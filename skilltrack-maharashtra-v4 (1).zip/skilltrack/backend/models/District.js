const mongoose = require("mongoose");

const DistrictSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, unique: true },
    region: { type: String }, // e.g. "Western Maharashtra", "Vidarbha"
    urbanRuralMix: {
      urbanPct: { type: Number, default: 50 },
      ruralPct: { type: Number, default: 50 },
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model("District", DistrictSchema);
