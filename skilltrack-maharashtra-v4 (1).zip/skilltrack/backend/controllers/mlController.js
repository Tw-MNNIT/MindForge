const asyncHandler = require("../utils/asyncHandler");
const mlService = require("../services/mlService");

exports.skillGap = asyncHandler(async (req, res) => {
  res.json(await mlService.skillGap(req.body));
});

exports.nonPlacementReason = asyncHandler(async (req, res) => {
  res.json(await mlService.nonPlacementReason(req.body));
});

exports.outcomePrediction = asyncHandler(async (req, res) => {
  res.json(await mlService.outcomePrediction(req.body));
});

exports.attritionRisk = asyncHandler(async (req, res) => {
  res.json(await mlService.attritionRisk(req.body));
});

exports.anomalies = asyncHandler(async (req, res) => {
  res.json(await mlService.outcomeAnomalies());
});
