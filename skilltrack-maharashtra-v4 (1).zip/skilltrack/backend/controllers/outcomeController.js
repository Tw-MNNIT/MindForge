const asyncHandler = require("../utils/asyncHandler");
const outcomeService = require("../services/outcomeService");

exports.create = asyncHandler(async (req, res) => {
  const outcome = await outcomeService.reportOutcome(req.body);
  res.status(201).json(outcome);
});

exports.addSalary = asyncHandler(async (req, res) => {
  const { monthlySalary, actorLabel } = req.body;
  const outcome = await outcomeService.addSalaryRecord(req.params.id, monthlySalary, actorLabel);
  res.json(outcome);
});

exports.getByTrainee = asyncHandler(async (req, res) => {
  const outcomes = await outcomeService.getByTrainee(req.params.traineeId);
  res.json(outcomes);
});
