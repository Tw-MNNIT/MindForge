const asyncHandler = require("../utils/asyncHandler");
const analyticsService = require("../services/analyticsService");
const skillGapService = require("../services/skillGapService");

exports.overview = asyncHandler(async (req, res) => {
  res.json(await analyticsService.overview());
});

exports.trend = asyncHandler(async (req, res) => {
  res.json(await analyticsService.employmentOutcomeTrend());
});

exports.distribution = asyncHandler(async (req, res) => {
  res.json(await analyticsService.employmentStatusDistribution());
});

exports.districts = asyncHandler(async (req, res) => {
  res.json(await analyticsService.districts());
});

exports.providers = asyncHandler(async (req, res) => {
  res.json(await analyticsService.providers());
});

exports.courses = asyncHandler(async (req, res) => {
  res.json(await analyticsService.courses());
});

exports.demographics = asyncHandler(async (req, res) => {
  res.json(await analyticsService.demographics());
});

exports.nonPlacementReasons = asyncHandler(async (req, res) => {
  res.json(await analyticsService.nonPlacementReasons());
});

exports.consentSummary = asyncHandler(async (req, res) => {
  res.json(await analyticsService.consentSummary());
});

exports.skillGaps = asyncHandler(async (req, res) => {
  res.json(await skillGapService.getGaps(req.query));
});

exports.topSkillGaps = asyncHandler(async (req, res) => {
  res.json(await skillGapService.topGaps(Number(req.query.limit) || 5));
});

exports.recomputeSkillGaps = asyncHandler(async (req, res) => {
  res.json(await skillGapService.recomputeSkillGaps());
});
