const asyncHandler = require("../utils/asyncHandler");
const followUpService = require("../services/followUpService");

exports.list = asyncHandler(async (req, res) => {
  const result = await followUpService.list(req.query);
  res.json(result);
});

exports.summary = asyncHandler(async (req, res) => {
  const result = await followUpService.summary();
  res.json(result);
});

exports.sendReminder = asyncHandler(async (req, res) => {
  const followUp = await followUpService.sendReminder(req.params.id);
  res.json(followUp);
});

exports.submit = asyncHandler(async (req, res) => {
  const result = await followUpService.submitResponse(req.params.id, req.body);
  res.json(result);
});
