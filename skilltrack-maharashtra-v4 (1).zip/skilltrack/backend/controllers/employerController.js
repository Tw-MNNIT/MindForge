const asyncHandler = require("../utils/asyncHandler");
const employerRepository = require("../repositories/employerRepository");
const verificationService = require("../services/verificationService");

exports.list = asyncHandler(async (req, res) => {
  const employers = await employerRepository.list();
  res.json(employers);
});

exports.getById = asyncHandler(async (req, res) => {
  const employer = await employerRepository.findById(req.params.id);
  if (!employer) return res.status(404).json({ message: "Employer not found" });
  res.json(employer);
});

exports.pendingVerifications = asyncHandler(async (req, res) => {
  const result = await verificationService.listPending(req.query.employerId);
  res.json(result);
});

exports.resolvedVerifications = asyncHandler(async (req, res) => {
  const result = await verificationService.listResolved(req.query.employerId);
  res.json(result);
});

exports.respondToVerification = asyncHandler(async (req, res) => {
  const { decision, employerNotes, actorLabel } = req.body;
  const result = await verificationService.respond(req.params.outcomeId, {
    decision,
    employerNotes,
    actorLabel,
  });
  res.json(result);
});
