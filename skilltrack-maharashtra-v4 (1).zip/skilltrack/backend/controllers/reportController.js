const asyncHandler = require("../utils/asyncHandler");
const reportService = require("../services/reportService");

exports.list = asyncHandler(async (req, res) => {
  res.json(reportService.listReports());
});

exports.getData = asyncHandler(async (req, res) => {
  res.json(await reportService.getReportData(req.params.id));
});

exports.exportCSV = asyncHandler(async (req, res) => {
  const csv = await reportService.exportCSV(req.params.id);
  res.setHeader("Content-Type", "text/csv");
  res.setHeader("Content-Disposition", `attachment; filename="${req.params.id}.csv"`);
  res.send(csv);
});
