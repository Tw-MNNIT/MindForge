const asyncHandler = require("../utils/asyncHandler");
const traineeService = require("../services/traineeService");
const consentRepository = require("../repositories/consentRepository");

exports.list = asyncHandler(async (req, res) => {
  const result = await traineeService.list(req.query);
  res.json(result);
});

exports.create = asyncHandler(async (req, res) => {
  // Returns { trainee, credentials: { uniqueId, password } } so the caller
  // (admin/provider UI) can show the freshly issued login right away.
  const result = await traineeService.createTrainee(req.body);
  res.status(201).json(result);
});

// Consolidated login list (Name / Login ID / Password) for every trainee,
// optionally filtered to one provider's own trainees via ?providerId=.
exports.credentialsList = asyncHandler(async (req, res) => {
  const rows = await traineeService.getCredentialsList(req.query.providerId);
  res.json(rows);
});

exports.credentialsListPdf = asyncHandler(async (req, res) => {
  await traineeService.streamCredentialsListPdf(req.query.providerId, res);
});

exports.getProfile = asyncHandler(async (req, res) => {
  const profile = await traineeService.getFullProfile(req.params.id);
  if (!profile) return res.status(404).json({ message: "Trainee not found" });
  res.json(profile);
});

exports.updateConsent = asyncHandler(async (req, res) => {
  const { status } = req.body;
  const consent = await consentRepository.updateStatus(req.params.id, status);
  res.json(consent);
});
