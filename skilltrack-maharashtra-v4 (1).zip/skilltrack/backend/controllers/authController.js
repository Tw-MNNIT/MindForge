const asyncHandler = require("../utils/asyncHandler");
const authService = require("../services/authService");

exports.login = asyncHandler(async (req, res) => {
  const { identifier, email, uniqueId, password } = req.body;
  const loginId = identifier || email || uniqueId;
  const result = await authService.login(loginId, password);
  res.json(result);
});

exports.registerGovernment = asyncHandler(async (req, res) => {
  const result = await authService.registerGovernment(req.body);
  res.status(201).json(result);
});

exports.verifyOtp = asyncHandler(async (req, res) => {
  const { userId, otp } = req.body;
  const result = await authService.verifyOtp(userId, otp);
  res.json(result);
});

exports.resendOtp = asyncHandler(async (req, res) => {
  const { userId } = req.body;
  const result = await authService.resendOtp(userId);
  res.json(result);
});

exports.issueProviderCredentials = asyncHandler(async (req, res) => {
  const result = await authService.issueProviderCredentials(req.body);
  res.status(201).json(result);
});

exports.updateProfile = asyncHandler(async (req, res) => {
  const { userId, name, themePreference } = req.body;
  const user = await authService.updateProfile(userId, { name, themePreference });
  res.json(user);
});
