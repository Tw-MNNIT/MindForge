const asyncHandler = require("../utils/asyncHandler");
const providerRepository = require("../repositories/providerRepository");
const programRepository = require("../repositories/programRepository");
const districtRepository = require("../repositories/districtRepository");

exports.listProviders = asyncHandler(async (req, res) => {
  res.json(await providerRepository.list());
});

exports.listPrograms = asyncHandler(async (req, res) => {
  res.json(await programRepository.list());
});

exports.listDistricts = asyncHandler(async (req, res) => {
  res.json(await districtRepository.list());
});
