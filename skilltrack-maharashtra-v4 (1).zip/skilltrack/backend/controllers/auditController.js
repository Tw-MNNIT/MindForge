const asyncHandler = require("../utils/asyncHandler");
const auditService = require("../services/auditService");

exports.list = asyncHandler(async (req, res) => {
  res.json(await auditService.recent(Number(req.query.limit) || 50));
});
