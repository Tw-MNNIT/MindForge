const asyncHandler = require("../utils/asyncHandler");
const reportService = require("../services/reportService");

exports.generate = asyncHandler(async (req, res) => {
  const { traineeId, providerId } = req.body;
  const report = await reportService.generate({ traineeId, providerId });
  res.status(201).json(report);
});

exports.upload = asyncHandler(async (req, res) => {
  const { traineeId, providerId } = req.body;
  if (!req.file) return res.status(400).json({ message: "No file uploaded" });
  const report = await reportService.attachFile({
    traineeId,
    providerId,
    fileUrl: req.file.path,
    fileName: req.file.originalname,
  });
  res.status(201).json(report);
});

exports.getForTrainee = asyncHandler(async (req, res) => {
  const reports = await reportService.getForTrainee(req.params.traineeId);
  res.json(reports);
});
