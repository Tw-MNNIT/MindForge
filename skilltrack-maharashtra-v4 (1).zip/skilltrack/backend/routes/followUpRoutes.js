const express = require("express");
const router = express.Router();
const followUpController = require("../controllers/followUpController");

router.get("/", followUpController.list);
router.get("/summary", followUpController.summary);
router.put("/:id/remind", followUpController.sendReminder);
router.put("/:id/submit", followUpController.submit);

module.exports = router;
