const express = require("express");
const router = express.Router();
const outcomeController = require("../controllers/outcomeController");

router.post("/", outcomeController.create);
router.put("/:id/salary", outcomeController.addSalary);

module.exports = router;
