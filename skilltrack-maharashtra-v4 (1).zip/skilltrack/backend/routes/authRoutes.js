const express = require("express");
const router = express.Router();
const authController = require("../controllers/authController");

router.post("/login", authController.login);
router.post("/register", authController.registerGovernment); // government self-registration
router.post("/verify-otp", authController.verifyOtp);
router.post("/resend-otp", authController.resendOtp);
router.post("/providers/issue", authController.issueProviderCredentials); // admin-only, issues provider login
router.put("/profile", authController.updateProfile);

module.exports = router;
