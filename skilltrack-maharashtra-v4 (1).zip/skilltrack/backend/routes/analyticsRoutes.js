const express = require("express");
const router = express.Router();
const analyticsController = require("../controllers/analyticsController");

router.get("/overview", analyticsController.overview);
router.get("/trend", analyticsController.trend);
router.get("/distribution", analyticsController.distribution);
router.get("/districts", analyticsController.districts);
router.get("/providers", analyticsController.providers);
router.get("/courses", analyticsController.courses);
router.get("/demographics", analyticsController.demographics);
router.get("/non-placement-reasons", analyticsController.nonPlacementReasons);
router.get("/consent-summary", analyticsController.consentSummary);
router.get("/skill-gaps", analyticsController.skillGaps);
router.get("/skill-gaps/top", analyticsController.topSkillGaps);
router.post("/skill-gaps/recompute", analyticsController.recomputeSkillGaps);

module.exports = router;
