const express = require("express");
const router = express.Router();
const mlController = require("../controllers/mlController");

router.post("/skill-gap", mlController.skillGap);
router.post("/non-placement-reason", mlController.nonPlacementReason);
router.post("/outcome-prediction", mlController.outcomePrediction);
router.post("/attrition-risk", mlController.attritionRisk);
router.get("/anomalies", mlController.anomalies);

module.exports = router;
