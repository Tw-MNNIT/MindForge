const express = require("express");
const router = express.Router();
const reportController = require("../controllers/reportController");

router.get("/", reportController.list);
router.get("/:id", reportController.getData);
router.get("/:id/export.csv", reportController.exportCSV);

module.exports = router;
