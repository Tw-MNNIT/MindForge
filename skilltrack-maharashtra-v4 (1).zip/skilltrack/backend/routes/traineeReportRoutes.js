const express = require("express");
const router = express.Router();
const { upload } = require("../config/cloudinary");
const reportGenController = require("../controllers/reportGenController");

router.post("/generate", reportGenController.generate);
router.post("/upload", upload.single("file"), reportGenController.upload);
router.get("/trainee/:traineeId", reportGenController.getForTrainee);

module.exports = router;
