const express = require("express");
const router = express.Router();
const traineeController = require("../controllers/traineeController");
const outcomeController = require("../controllers/outcomeController");
const followUpController = require("../controllers/followUpController");

router.get("/", traineeController.list);
router.post("/", traineeController.create);
// NOTE: these two must stay above the "/:id" route below, or Express would
// treat "credentials" as an :id value.
router.get("/credentials", traineeController.credentialsList);
router.get("/credentials/pdf", traineeController.credentialsListPdf);
router.get("/:id", traineeController.getProfile);
router.put("/:id/consent", traineeController.updateConsent);
router.get("/:traineeId/outcomes", outcomeController.getByTrainee);
router.get("/:traineeId/followups", async (req, res, next) => {
  // Convenience alias so the frontend can fetch a trainee's follow-ups
  // without knowing the generic /followups?traineeId= query shape.
  req.query.traineeId = req.params.traineeId;
  next();
}, followUpController.list);

module.exports = router;
