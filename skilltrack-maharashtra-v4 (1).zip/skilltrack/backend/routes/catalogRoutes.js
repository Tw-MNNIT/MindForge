const express = require("express");
const router = express.Router();
const catalogController = require("../controllers/catalogController");

router.get("/providers", catalogController.listProviders);
router.get("/programs", catalogController.listPrograms);
router.get("/districts", catalogController.listDistricts);

module.exports = router;
