const express = require("express");
const router = express.Router();
const employerController = require("../controllers/employerController");

router.get("/", employerController.list);
router.get("/verifications/pending", employerController.pendingVerifications);
router.get("/verifications/resolved", employerController.resolvedVerifications);
router.put("/verifications/:outcomeId", employerController.respondToVerification);
router.get("/:id", employerController.getById);

module.exports = router;
