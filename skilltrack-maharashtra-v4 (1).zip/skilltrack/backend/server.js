require("dotenv").config();
const express = require("express");
const cors = require("cors");
const morgan = require("morgan");
const connectDB = require("./config/db");
const { notFound, errorHandler } = require("./middleware/errorHandler");

const authRoutes = require("./routes/authRoutes");
const traineeRoutes = require("./routes/traineeRoutes");
const outcomeRoutes = require("./routes/outcomeRoutes");
const followUpRoutes = require("./routes/followUpRoutes");
const employerRoutes = require("./routes/employerRoutes");
const catalogRoutes = require("./routes/catalogRoutes");
const analyticsRoutes = require("./routes/analyticsRoutes");
const reportRoutes = require("./routes/reportRoutes");
const mlRoutes = require("./routes/mlRoutes");
const auditRoutes = require("./routes/auditRoutes");
const traineeReportRoutes = require("./routes/traineeReportRoutes");

const app = express();

app.use(
  cors({
    origin: process.env.CORS_ORIGIN ? process.env.CORS_ORIGIN.split(",") : "*",
  })
);
app.use(express.json());
app.use(morgan("dev"));

app.get("/api/health", (req, res) => res.json({ status: "ok", service: "skilltrack-backend" }));

app.use("/api/auth", authRoutes);
app.use("/api/trainees", traineeRoutes);
app.use("/api/employment-outcomes", outcomeRoutes);
app.use("/api/followups", followUpRoutes);
app.use("/api/employers", employerRoutes);
app.use("/api/catalog", catalogRoutes);
app.use("/api/analytics", analyticsRoutes);
app.use("/api/reports", reportRoutes);
app.use("/api/ml", mlRoutes);
app.use("/api/audit-logs", auditRoutes);
app.use("/api/reports-ai", traineeReportRoutes);

app.use(notFound);
app.use(errorHandler);

const PORT = process.env.PORT || 5000;

connectDB().then(() => {
  app.listen(PORT, () => console.log(`SkillTrack API listening on port ${PORT}`));
});
